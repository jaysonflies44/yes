LIFELINE (offline life simulator)

1. Unzip this folder.
2. Open a terminal INSIDE lifeline-app (the folder containing package.json).
3. npm install
4. npm run dev
5. Open the shown http://localhost:5173 link in Chrome/Edge.

Everything in the game (degrees, schools, jobs, hobbies, sports, events) is hand-written base content.
There is no AI layer and no model to download.

Where to add content:
  src/engine/lexicon.js      fields of study + jobs (DOMAINS) and hobbies (ACTIVITY_LEX)
  src/engine/content.js      admission rules for each school type, job qualification routes, schools
  src/engine/events.js       classic life events + outings menu
  src/engine/events_more.js  more events (illness, kids asking parents, school, job offers)
  src/engine/health.js       illnesses and treatments
