/*
  LIFELINE: a life simulator, birth to old age.
  Every degree, school, job, hobby, sport and event is hand-written base content (src/engine/lexicon.js, content.js, events*.js)
  running on a fixed rules engine (skills, stats, requirements, consequences). There is no AI layer: the game is fully offline and deterministic in what exists.
  Type: Bricolage Grotesque (display) + DM Sans + DM Mono. Palette: midnight indigo ground, highlighter-lime lead.
  Signature: the LIFE RIBBON, one tick per year, lit in the colour of each life stage, with a giant age numeral.
*/
import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { Home as HomeI, User, GraduationCap, Briefcase, Users, Sparkles, Trophy, Wallet, HeartPulse, ScrollText, ChevronsRight, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Toaster } from "@/components/ui/sonner";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { G, useG, Portrait, Money } from "./ui/kit.jsx";
import { Create } from "./ui/Create.jsx";
import { EventModal, WarnModal, DeathModal } from "./ui/Modals.jsx";
import { HomePage } from "./ui/Home.jsx";
import { CharacterPage } from "./ui/Character.jsx";
import { EducationPage } from "./ui/Education.jsx";
import { CareerPage } from "./ui/Career.jsx";
import { PeoplePage } from "./ui/People.jsx";
import { ActivitiesPage } from "./ui/Activities.jsx";
import { SportsPage } from "./ui/Sports.jsx";
import { FinancePage } from "./ui/Finance.jsx";
import { HealthPage } from "./ui/Health.jsx";
import { HistoryPage } from "./ui/History.jsx";
import { db } from "./engine/db.js";
import { advanceYear, netWorth, migrateSave } from "./engine/sim.js";
import { buildBaseContent, ensureLocal } from "./engine/content.js";
import { buildIntentEvent } from "./engine/events.js";
import { createLife } from "./engine/char.js";
import { nameOf, countryOf, SPORTS } from "./engine/data.js";

const NAV = [
  ["home", "Home", HomeI], ["character", "Character", User], ["education", "Education", GraduationCap], ["career", "Career", Briefcase], ["people", "Relationships", Users],
  ["activities", "Activities", Sparkles], ["sports", "Sports", Trophy], ["finances", "Finances", Wallet], ["health", "Health", HeartPulse], ["history", "History", ScrollText],
];
const PAGES = { home: HomePage, character: CharacterPage, education: EducationPage, career: CareerPage, people: PeoplePage, activities: ActivitiesPage, sports: SportsPage, finances: FinancePage, health: HealthPage, history: HistoryPage };

export default function App() {
  const [s, setS] = useState(null);
  const sRef = useRef(null);
  const [ready, setReady] = useState(false);
  const [saves, setSaves] = useState([]);
  const [tab, setTab] = useState("home");
  const [focus, setFocus] = useState(null);
  const [busy, setBusy] = useState(false);
  const [warn, setWarn] = useState(null);
  const saveTimer = useRef(null);

  const refreshSaves = useCallback(async () => setSaves((await db.all("saves")).sort((a, b) => b.savedAt - a.savedAt)), []);
  useEffect(() => {
    (async () => {
      buildBaseContent(); await refreshSaves(); setReady(true);
    })();
  }, [refreshSaves]);

  const commit = useCallback((n) => {
    sRef.current = n; setS(n);
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => { await db.put("saves", { id: n.id, name: nameOf(n), age: n.age, country: countryOf(n.country).name, alive: n.alive, savedAt: Date.now(), data: n }); }, 500);
  }, []);
  const act = useCallback((fn) => { const n = structuredClone(sRef.current); const r = fn(n); commit(n); return r; }, [commit]);

  const start = async (d, preview) => {
    setBusy(true);
    const life = structuredClone(preview);
    life.name = { first: d.first, middle: d.middle, last: d.last }; life.personality = d.personality; life.birth = { ...life.birth, m: d.month, d: d.day };
    life.rels.forEach((r) => { if (r.role === "father" || r.role === "sibling") r.name.last = d.last; });
    life.nw = [{ age: 0, v: 0 }];
    ensureLocal(life); commit(life); setTab("home"); setBusy(false); await refreshSaves();
    toast("Born. Age up when you're ready.");
  };
  const load = (sv) => { const n = migrateSave(sv.data); ensureLocal(n); sRef.current = n; setS(n); setTab("home"); };
  const del = async (id) => { await db.del("saves", id); refreshSaves(); };
  const newLife = async () => { setS(null); sRef.current = null; await refreshSaves(); };

  const ageUp = async () => {
    const cur = sRef.current; if (busy || !cur?.alive) return;
    if (cur.pending.length) return setWarn({ title: "Events are waiting", message: "Resolve this year's events before you age up." });
    setBusy("age");
    const n = structuredClone(cur);
    advanceYear(n);
    n.nw = [...(n.nw || []), { age: n.age, v: netWorth(n) }];
    commit(n); setBusy(false); setTab("home");
  };

  const go = (t, f = null) => { setTab(t); setFocus(f); window.scrollTo({ top: 0, behavior: "smooth" }); };
  // "Do something this year": pick an idea from the menu, it turns into an event to resolve
  const submitPrompt = (id) => {
    const cur = sRef.current;
    if (cur.prompts <= 0) return setWarn({ title: "Out of ideas this year", message: "You get 5 outings per year. Age up to refresh them, or use the quick actions on Home." });
    const res = buildIntentEvent(id, cur);
    if (!res) return;
    if (res.warn) return setWarn(res.warn);
    act((n) => { n.prompts--; n.pending.unshift(res.event); });
  };

  const Page = PAGES[tab];
  const value = useMemo(() => ({ s, act, go, focus, clearFocus: () => setFocus(null), busy, submitPrompt, setWarn, toast, ageUp }), [s, focus, busy]);

  if (!ready) return <div className="grid min-h-screen place-items-center bg-background"><Loader2 className="size-8 animate-spin text-primary" /></div>;
  if (!s) return <><Create onStart={start} onLoad={load} saves={saves} onDelete={del} /><Toaster richColors /></>;

  return (
    <G.Provider value={value}>
      <div className="@container min-h-screen bg-background font-sans text-foreground">
        <div className="flex min-h-screen flex-col @3xl:flex-row">
          <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-border bg-card/60 p-4 @3xl:flex">
            <p className="px-3 pb-4 font-display text-2xl font-bold tracking-tight">life<span className="text-primary">line</span></p>
            <nav className="flex-1 space-y-1">
              {NAV.map(([id, label, Icon]) => (
                <button key={id} type="button" onClick={() => go(id)} className={cn("flex w-full items-center gap-3 rounded-lg px-3 py-3 text-base transition-colors", tab === id ? "bg-primary text-primary-foreground" : "text-foreground/75 hover:bg-foreground/10")}>
                  <Icon className="size-5" />{label}{id === "home" && s.pending.length > 0 && <span className="ml-auto rounded-full bg-bad px-2 text-sm text-white">{s.pending.length}</span>}
                </button>
              ))}
            </nav>
            <AgeButton />
            <button type="button" onClick={newLife} className="mt-3 text-sm text-muted-foreground hover:text-foreground">Menu / switch life</button>
          </aside>
          <main className="min-w-0 flex-1 pb-44 @3xl:pb-12">
            <TopBar />
            <div className="mx-auto max-w-4xl px-4 pt-4"><Page /></div>
          </main>
          <div className="fixed inset-x-0 bottom-0 z-30 @3xl:hidden">
            <div className="flex justify-center pb-2"><AgeButton floating /></div>
            <nav className="flex overflow-x-auto border-t border-border bg-background/95 px-1 backdrop-blur [scrollbar-width:none]">
              {NAV.map(([id, label, Icon]) => (
                <button key={id} type="button" onClick={() => go(id)} className={cn("relative flex min-w-[76px] flex-1 flex-col items-center gap-1 px-2 py-3 text-sm transition-colors", tab === id ? "text-primary" : "text-muted-foreground")}>
                  <Icon className="size-5" />{label.slice(0, 9)}
                  {tab === id && <span className="absolute inset-x-4 top-0 h-0.5 rounded-full bg-primary" />}
                  {id === "home" && s.pending.length > 0 && <span className="absolute right-3 top-2 size-2 rounded-full bg-bad" />}
                </button>
              ))}
            </nav>
          </div>
        </div>
        <EventModal key={s.id} />
        <WarnModal warn={warn} close={() => setWarn(null)} />
        <DeathModal onNew={newLife} />
        <Toaster richColors position="top-center" />
      </div>
    </G.Provider>
  );
}

function AgeButton({ floating }) {
  const { s, ageUp, busy } = useG();
  return (
    <Button type="button" onClick={ageUp} disabled={!!busy || !s.alive} className={cn("h-14 gap-2 rounded-full bg-primary px-6 text-lg font-bold text-primary-foreground shadow-[0_8px_30px_-6px_oklch(0.88_0.19_118/0.5)] hover:bg-primary/90", floating ? "min-w-[220px]" : "w-full")}>
      {busy === "age" ? <Loader2 className="size-5 animate-spin" /> : <ChevronsRight className="size-6" />}
      {busy === "age" ? "Living the year…" : `Age up to ${s.age + 1}`}
    </Button>
  );
}
function TopBar() {
  const { s } = useG();
  return (
    <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-border bg-background/90 px-4 py-3 backdrop-blur">
      <Portrait p={s} age={s.age} mood={s.stats.happiness} size={44} />
      <div className="min-w-0 flex-1"><p className="truncate font-display text-lg font-semibold leading-tight">{nameOf(s)}</p><p className="truncate text-sm text-muted-foreground">{s.age} yrs · {s.city}, {countryOf(s.country).name}</p></div>
      <div className="text-right"><Money usd={s.money.cash} className="text-base font-medium" /><p className="text-sm text-muted-foreground">{s.prompts} outings left</p></div>
    </header>
  );
}
