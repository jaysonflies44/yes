// In-memory content catalog. Everything in it is built from the hand-written base content (lexicon.js + content.js),
// so there is nothing to save or clear: it is rebuilt identically every time the game opens.
const items = new Map();
export const Catalog = {
  add(item) { items.set(item.id, item); return item; },
  has: (id) => items.has(id),
  get: (id) => items.get(id) || null,
  list: (type) => [...items.values()].filter((i) => i.type === type),
  byKey: (type, key) => [...items.values()].find((i) => i.type === type && i.key === key) || null,
  count: () => items.size,
  counts() { const o = {}; items.forEach((i) => { o[i.type] = (o[i.type] || 0) + 1; }); return o; },
};
