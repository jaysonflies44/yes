import { countryOf, makeName, PERSONALITY, STAT_IDS, GROWTH, eyeColor, hairColor, ZODIAC, SPORTS } from "./data.js";
import { DOMAINS } from "./lexicon.js";
import { pick, int, chance, gauss, clamp, uid, wpick } from "./rng.js";

export const ACADEMIC = ["literature", "mathematics", "science", "languages", "logic", "communication", "creativity"];
const ALL_APT = [...ACADEMIC, "art", "music", "business", "programming", "cooking", "leadership", "gaming"];

export function randomGenes(gender, country) {
  const male = gender === "male";
  const c = countryOf(country);
  const eyeP = ["B", "B", "B", "B", "G", "U"]; const hairP = ["K", "K", "N", "N", "L", "R"];
  const regional = ["DE", "GB", "FR", "AU", "CA", "US", "ES"].includes(country);
  const ep = regional ? ["B", "B", "G", "U", "U", "G"] : eyeP; const hp = regional ? ["N", "N", "L", "K", "R", "N"] : hairP;
  const apt = {}; ALL_APT.forEach((k) => (apt[k] = clamp(gauss(1, 0.2), 0.6, 1.5)));
  return {
    height: Math.round(gauss(male ? 176 : 163, male ? 7 : 6.5)), eye: [pick(ep), pick(ep)], hair: [pick(hp), pick(hp)], skin: int(10, 90), curl: int(0, 100),
    athletic: int(15, 90), intellect: Math.round(clamp(gauss(55, 18), 10, 95)), creative: Math.round(clamp(gauss(50, 20), 5, 95)), social: int(15, 90), longevity: Math.round(clamp(gauss(55, 18), 10, 95)),
    temper: int(15, 85), looks: Math.round(clamp(gauss(52, 18), 8, 95)), apt,
  };
}
const mixQ = (a, b, sd = 9) => Math.round(clamp((a + b) / 2 * 0.88 + 6 + gauss(0, sd), 5, 98));
export function inheritGenes(f, m, gender) {
  const male = gender === "male";
  const mid = (f.height + m.height) / 2 + (male ? 6.5 : -6.5) * 0.9;
  const gene = (p) => [pick(p.eye)]; 
  const apt = {};
  Object.keys(f.apt).forEach((k) => (apt[k] = clamp(((f.apt[k] + m.apt[k]) / 2) * 0.7 + 0.3 + gauss(0, 0.15), 0.55, 1.55)));
  const mut = (x, pool) => (chance(0.03) ? pick(pool) : x);
  return {
    height: Math.round(mid + gauss(0, 4.2)), eye: [mut(pick(f.eye), ["B", "G", "U"]), mut(pick(m.eye), ["B", "G", "U"])], hair: [mut(pick(f.hair), ["K", "N", "L", "R"]), mut(pick(m.hair), ["K", "N", "L", "R"])],
    skin: Math.round(clamp((f.skin + m.skin) / 2 + gauss(0, 6), 3, 97)), curl: Math.round(clamp((f.curl + m.curl) / 2 + gauss(0, 14), 0, 100)),
    athletic: mixQ(f.athletic, m.athletic), intellect: mixQ(f.intellect, m.intellect), creative: mixQ(f.creative, m.creative), social: mixQ(f.social, m.social),
    longevity: mixQ(f.longevity, m.longevity, 7), temper: mixQ(f.temper, m.temper), looks: mixQ(f.looks, m.looks, 10), apt,
  };
}
export const heightAt = (genes, age, nutrition = 1) => {
  const f = age >= 17 ? 1 : (GROWTH[Math.max(0, Math.floor(age))] + (GROWTH[Math.min(17, Math.ceil(age + 0.0001))] - GROWTH[Math.max(0, Math.floor(age))]) * (age % 1));
  return Math.round(genes.height * f * (0.985 + 0.015 * nutrition));
};
export function appearance(s) {
  const g = s.genes; const eye = eyeColor(g.eye); let hair = hairColor(g.hair);
  const grey = s.age >= 52 ? (s.age >= 68 ? "white" : "grey-streaked") : null;
  const texture = g.curl > 66 ? "curly" : g.curl > 33 ? "wavy" : "straight";
  const tone = g.skin < 25 ? "fair" : g.skin < 50 ? "light" : g.skin < 75 ? "olive / tan" : "deep";
  return { eye, hair: grey ? `${grey} (${hair})` : hair, texture, tone, height: heightAt(g, s.age), build: s.stats.fitness > 70 ? "athletic" : s.stats.fitness > 40 ? "average" : "soft" };
}
export const mortality = (age) => (age < 1 ? 0.004 : age < 15 ? 0.0004 : 0.0006 + 0.0004 * Math.exp((age - 30) / 10.5));

export function randomPersonality(base) {
  const p = {};
  PERSONALITY.forEach((t) => (p[t.id] = Math.round(clamp(gauss(base?.[t.id] ?? 50, base ? 14 : 18), 5, 95))));
  return p;
}
const GOALS = {
  young: ["Get into a good school", "Win the school championship", "Become the best at gaming", "Make lots of friends"],
  adult: ["Get promoted", "Save for a house", "Travel the world", "Start a family", "Finish a degree", "Run a marathon", "Open a small business", "Learn a new language", "Write a novel"],
  elder: ["Retire comfortably", "Spend time with the family", "Tend the garden", "See the grandchildren grow", "Take one last big trip"],
};
const goalFor = (age) => pick(age < 18 ? GOALS.young : age < 60 ? GOALS.adult : GOALS.elder);
const OCC_BY_TIER = [["retail", "delivery", "agriculture", "carpentry", "warehouse"], ["electrician", "culinary", "hospitality", "retail", "teaching", "nursing"], ["teaching", "cs", "business", "nursing", "marketing", "engineering"], ["medicine", "law", "finance", "engineering", "architecture"], ["business", "finance", "medicine", "law"]];
export function occupationFor(age, tier = 2, jobless = 0.08) {
  if (age < 3) return "Baby"; if (age < 6) return "Pre-schooler"; if (age < 18) return "Student"; if (age < 22 && chance(0.55)) return "University student";
  if (age >= 65 && chance(0.8)) return "Retired";
  if (chance(jobless)) return "Between jobs";
  const key = pick(OCC_BY_TIER[tier]); const d = DOMAINS.find((x) => x.key === key);
  return d.ladder[age < 28 ? 0 : age < 42 ? 1 : age < 56 ? 2 : 1];
}
const ROLE_AFF = { mother: [70, 10], father: [65, 12], sibling: [55, 15], friend: [55, 12], classmate: [38, 12], partner: [62, 12], spouse: [75, 8], coworker: [38, 10], child: [85, 8], ex: [20, 10] };
export function makeNpc(role, o = {}) {
  const country = o.country || "US";
  const gender = o.gender || pick(["male", "female"]);
  const name = o.name && typeof o.name === "string" ? { first: o.name, middle: "", last: o.last || pick(countryOf(country).names.l) } : makeName(country, gender, o.last);
  const age = o.age ?? 30;
  const pers = randomPersonality(o.basePers);
  const [m, sd] = ROLE_AFF[role] || [45, 12];
  const compat = Math.round(clamp(100 - (o.playerPers ? PERSONALITY.reduce((a, t) => a + Math.abs(pers[t.id] - o.playerPers[t.id]), 0) / 5 * 1.8 : 40) + gauss(0, 8), 10, 98));
  return {
    id: uid("n_"), role, name, gender, age, alive: true, country, personality: pers, genes: o.genes || randomGenes(gender, country), occupation: o.occupation || occupationFor(age, o.tier ?? 2),
    goal: goalFor(age), affection: Math.round(clamp(gauss(m, sd), 5, 98)), trust: Math.round(clamp(gauss(m - 5, sd), 5, 98)), respect: Math.round(clamp(gauss(m - 8, sd), 5, 98)), compat, status: "active", met: o.met ?? 0, notes: [], tier: o.tier ?? 2,
  };
}
export const npcLabel = (r) => ({ mother: "Mother", father: "Father", sibling: r.gender === "female" ? "Sister" : "Brother", friend: "Friend", classmate: "Classmate", partner: "Partner", spouse: r.gender === "female" ? "Wife" : "Husband", coworker: "Coworker", child: r.gender === "female" ? "Daughter" : "Son", ex: "Ex" })[r.role] || r.role;

export function randomDraft(country) {
  const c = country || pick(["US", "GB", "CA", "DE", "FR", "JP", "KR", "BR", "IN", "NG", "MX", "AU", "ES", "PH", "ET", "KE"]);
  const gender = pick(["male", "female"]); const cc = countryOf(c);
  const nm = makeName(c, gender);
  return { ...nm, gender, country: c, city: pick(cc.cities), month: int(1, 12), day: int(1, 28), personality: randomPersonality(), orientation: wpick([{ v: "straight", w: 85 }, { v: "gay", w: 8 }, { v: "bi", w: 7 }]).v };
}

export function createLife(d) {
  const c = countryOf(d.country);
  const father = makeNpc("father", { age: int(24, 44), gender: "male", country: d.country, last: d.last, tier: 2 });
  const mother = makeNpc("mother", { age: int(22, 41), gender: "female", country: d.country, tier: 2 });
  const tier = wpick([{ t: 0, w: 20 }, { t: 1, w: 35 }, { t: 2, w: 28 }, { t: 3, w: 13 }, { t: 4, w: 4 }], (x) => x.w).t;
  [father, mother].forEach((p) => { p.tier = tier; p.occupation = occupationFor(p.age, tier, 0.04); p.affection = int(62, 90); p.trust = int(55, 85); p.respect = int(55, 85); p.met = 0; });
  const genes = inheritGenes(father.genes, mother.genes, d.gender);
  const sibs = [];
  const nsib = wpick([{ n: 0, w: 30 }, { n: 1, w: 38 }, { n: 2, w: 22 }, { n: 3, w: 10 }], (x) => x.w).n;
  for (let i = 0; i < nsib; i++) {
    const g = pick(["male", "female"]);
    const sg = inheritGenes(father.genes, mother.genes, g);
    const sb = makeNpc("sibling", { age: Math.max(0, int(-8, 8)), gender: g, country: d.country, last: father.name.last, genes: sg, tier, met: 0, basePers: father.personality });
    sb.occupation = sb.age < 6 ? "Pre-schooler" : "Student"; sb.age = Math.max(0, int(0, 12)); sibs.push(sb);
  }
  const year = new Date().getFullYear();
  const s = {
    v: 2, id: uid("life_"), createdAt: Date.now(), year, age: 0, alive: true, cause: null, retired: false,
    name: { first: d.first, middle: d.middle, last: d.last }, gender: d.gender, orientation: d.orientation || "straight", birth: { y: year, m: d.month, d: d.day, zodiac: ZODIAC(d.month, d.day) },
    country: d.country, city: d.city, hometown: d.city, healthSystem: c.health, genes, personality: d.personality,
    stats: { happiness: 78, health: 82 + Math.round((genes.longevity - 50) / 10), smarts: 12 + Math.round(genes.intellect * 0.2), looks: Math.round(30 + genes.looks * 0.45), fitness: 38 + Math.round(genes.athletic * 0.1), reputation: 50, stress: 10 },
    skills: {}, edu: { level: 0, done: [], certs: [], current: null, schoolGpa: 3, inSchool: false, applied: {} },
    job: null, jobHistory: [], expByField: {}, money: { cash: 0, debt: 0 }, housing: { id: "parents", rentUSD: 0, value: 0, loan: 0 }, assets: [], business: null,
    family: { tier, support: [0, 0.1, 0.3, 0.7, 1][tier] }, rels: [father, mother, ...sibs], sport: { team: null, history: [], awards: [], careerEarn: 0 }, activities: [], conditions: [],
    lifestyle: { diet: 1, exercise: 1, sleep: 1 }, memory: { key: [], flags: {}, followups: [], seen: {}, titles: [], had: {} },
    year0: {}, prompts: 5, quick: {}, feed: [], pending: [], log: [], mode: "normal", stats0: {}, prison: 0, peakSalary: 0, lifetimeEarn: 0,
  };
  s.log.push({ age: 0, year, text: `Born in ${d.city}, ${c.name}, to ${father.name.first} ${father.name.last} and ${mother.name.first}.`, tone: "info" });
  s.feed.push({ text: `You were born in ${d.city}. Welcome to the world.`, tone: "info" });
  return s;
}
