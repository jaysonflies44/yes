// Builds the full game catalog from the base content library: programmes, jobs, activities, schools, scholarships and sports teams.
// All of it is deterministic: the same game always has the same degrees, the same jobs and the same qualification rules.
import { DOMAINS, DOMAIN_BY_KEY, ACTIVITY_LEX, hasDegree } from "./lexicon.js";
import { SPORTS, SPORT_TIERS, countryOf, EDU_LEVELS } from "./data.js";
import { hash } from "./rng.js";
import { Catalog } from "./catalog.js";
import { fieldLabel, joinList } from "./rules.js";

export const SCHOOL_KINDS = [
  { id: "community", label: "Community college", short: "Community", blurb: "Open to high-school graduates. Associate degrees and certificates." },
  { id: "trade", label: "Trade & vocational school", short: "Trade school", blurb: "Hands-on diplomas and licences, from age 16." },
  { id: "university", label: "University", short: "University", blurb: "Bachelor degrees. Needs a high-school diploma and a solid GPA." },
  { id: "grad", label: "Graduate school", short: "Graduate", blurb: "Master's and PhD programmes. Needs a bachelor degree in an accepted field." },
  { id: "medical", label: "Medical school", short: "Medical", blurb: "Becomes a doctor. Needs a science bachelor, a high GPA and strong Smarts." },
  { id: "dental", label: "Dental school", short: "Dental", blurb: "Becomes a dentist. Needs a science bachelor and a high GPA." },
  { id: "law", label: "Law school", short: "Law", blurb: "Becomes a lawyer. Needs any bachelor degree and a good GPA." },
  { id: "nursing", label: "Nursing school", short: "Nursing", blurb: "Becomes a registered nurse. Needs a high-school diploma and science skills." },
  { id: "pharmacy", label: "Pharmacy school", short: "Pharmacy", blurb: "Becomes a pharmacist. Needs a chemistry or biology bachelor." },
  { id: "vet", label: "Veterinary school", short: "Veterinary", blurb: "Becomes a vet. Needs a biology bachelor." },
  { id: "online", label: "Online academy", short: "Online", blurb: "Flexible and cheap. Certificates, associate degrees and some bachelors." },
];
export const schoolKind = (id) => SCHOOL_KINDS.find((k) => k.id === id);
const KIND_NAME = { cert: "Certificate", voc: "Diploma", assoc: "Associate degree", bach: "Bachelor", master: "Master", phd: "Doctorate", pro: "Professional doctorate", pgcert: "Postgraduate certificate" };
export const KIND = KIND_NAME;

// ---------------- admission rules (the "qualification" of each school type) ----------------
const ACAD = ["literature", "mathematics", "logic", "science", "languages", "communication"];
const PORTFOLIO = ["music", "art", "photography", "dance", "writing", "chess"];
const HARD = new Set(["engineering", "civileng", "mecheng", "eleceng", "chemeng", "aeroeng", "cs", "ai", "datasci", "physics", "mathematics", "chemistry", "biology", "biomedsci", "architecture", "economics", "finance", "physio", "radiography", "psychology"]);
function foundation(d, factor = 0.45, portfolio = true) {
  const out = {};
  for (const [k, v] of Object.entries(d.skills)) {
    if (ACAD.includes(k)) out[k] = Math.min(4, Math.max(1, Math.ceil(v * factor)));
    else if (portfolio && PORTFOLIO.includes(k)) out[k] = Math.min(2, Math.max(1, Math.round(v * 0.4)));
  }
  return out;
}
const teach = (d, add = 0, factor = 1) => Object.fromEntries(Object.entries(d.skills).map(([k, v]) => [k, Math.min(9, Math.round((v * factor + add) * 2) / 2)]));
const BD_ABBR = { "Bachelor of Science": "BSc", "Bachelor of Arts": "BA", "Bachelor of Engineering": "BEng", "Bachelor of Business Administration": "BBA", "Bachelor of Fine Arts": "BFA", "Bachelor of Education": "BEd", "Bachelor of Music": "BMus", "Bachelor of Architecture": "BArch" };
const MD_OF = { BSc: "MSc", BA: "MA", BEng: "MEng", BBA: "MSc", BFA: "MFA", BEd: "MEd", BMus: "MMus", BArch: "MArch" };
const TUITION = { cert: 2000, voc: 7000, assoc: 6000, bach: 22000, master: 26000, phd: 9000, pgcert: 9000 };
const PRO_TUITION = { medical: 55000, dental: 60000, law: 42000, pharmacy: 38000, vet: 48000 };
const PRICE = { ai: 1.3, engineering: 1.2, aviation: 2.5, architecture: 1.15, cs: 1.1 };

function mk(d, kind, o) {
  const id = `edu:${d.key}:${o.sub || kind}`;
  return {
    id, type: "education", key: `${d.key}|${o.sub || kind}`, name: o.name, field: d.key, fieldName: d.name, kind, level: o.level, years: o.years, school: o.school,
    ageRule: o.ageRule || "uni", minAge: o.minAge || 0, desc: o.desc, adm: o.adm, subjects: d.subjects, tuitionUSD: Math.round((o.tuition ?? TUITION[kind]) * (PRICE[d.key] || 1)),
    gradReq: { minGpa: o.minGpa ?? 2, projects: ["bach", "master", "phd", "pro"].includes(kind) }, careers: d.ladder.slice(0, 3), grants: o.grants || [], teaches: o.teaches || {},
  };
}
function feederList(d, kind) {
  if (d.feeds === "any") return null;
  return d.feeds || d.deg.filter((k) => DOMAIN_BY_KEY[k] && (hasDegree(DOMAIN_BY_KEY[k]) || DOMAIN_BY_KEY[k].path === "pro"));
}

export function buildPrograms() {
  const out = [];
  for (const d of DOMAINS) {
    const lic = d.licence ? [d.licence] : [];
    const hard = HARD.has(d.key);
    if (d.path === "pro") {
      const price = PRO_TUITION[d.school];
      const adm = { edu: 4, gpa: d.gpa, stats: d.stats || {}, skills: foundation(d, 0.6, false) };
      if (d.prereq === "any") adm.anyBachelor = true; else adm.degrees = d.prereq;
      out.push(mk(d, "pro", { level: 6, years: d.years, school: d.school, name: d.pname, desc: `${d.pname}: the professional programme that leads to practising as ${d.ladder[1].toLowerCase().startsWith("a") ? "an" : "a"} ${d.ladder[1].toLowerCase()}. Intense, expensive and competitive.`, adm, tuition: price, minGpa: 2.7, grants: lic, teaches: teach(d) }));
    }
    if (hasDegree(d) && (d.path === "degree" || d.path === "mixed" || d.path === "talent")) {
      const bd = d.bd || "Bachelor of Science"; const ab = BD_ABBR[bd] || "BSc";
      const base = hard ? 2.8 : 2.4;
      out.push(mk(d, "bach", { level: 4, years: d.years || 4, school: d.school === "nursing" ? "nursing" : "university", name: `${d.name} (${ab})`, grants: lic, teaches: teach(d),
        desc: `${bd} in ${d.name}. Covers ${d.subjects.slice(0, 3).join(", ")} and more.`, adm: { edu: 2, gpa: base, skills: foundation(d), minAge: 0 }, minGpa: 2 }));
      if (d.school === "nursing") { /* nursing is taught at nursing schools only */ }
      if (d.master) {
        const feeders = feederList(d, "master");
        const adm = { edu: 4, gpa: 2.8 }; if (feeders) adm.degrees = feeders; else adm.anyBachelor = true;
        out.push(mk(d, "master", { level: 5, years: 2, school: "grad", name: `${d.name} (${d.md === "Master of Business Administration" ? "MBA" : MD_OF[ab] || "MSc"})`, teaches: teach(d, 1), grants: lic,
          desc: `Advanced study in ${d.name}: ${d.subjects.slice(-3).join(", ")}.`, adm, minGpa: 2.5 }));
      }
      if (d.phd) {
        const feeders = feederList(d, "phd");
        const adm = { edu: 5, gpa: 3.2 }; if (feeders) adm.degrees = feeders; else adm.anyBachelor = true;
        out.push(mk(d, "phd", { level: 6, years: 4, school: "grad", name: `${d.name} (PhD)`, teaches: teach(d, 2), grants: lic, desc: `Doctoral research in ${d.name}. Original work and a dissertation.`, adm, minGpa: 3 }));
      }
    }
    if (d.assoc) {
      out.push(mk(d, "assoc", { level: 3, years: 2, school: "community", name: `${d.name} (Associate degree)`, teaches: teach(d, 0, 0.6), grants: d.cert && !d.certProg ? [d.cert] : [], minAge: 0,
        desc: `A two-year associate degree in ${d.name} at a community college. Credits can lead on to a bachelor.`, adm: { edu: 2, gpa: 1.8 } }));
    }
    const certName = d.cert;
    if (d.path === "trade") {
      const vn = d.vocName || `${d.name} Diploma`;
      out.push(mk(d, "voc", { level: 3, years: 2, school: "trade", name: vn, teaches: teach(d, 0, 0.8), grants: certName ? [certName] : [], minAge: 0,
        desc: `Hands-on training in ${d.name.toLowerCase()}: ${d.subjects.slice(0, 3).join(", ")}. Includes workshop placement.`, adm: { edu: 1, gpa: 0, skills: {} }, minGpa: 1.5 }));
      if (certName) out.push(mk(d, "cert", { level: 3, years: 1, school: "trade", name: certName, ageRule: "work", minAge: d.minAge || 0, teaches: teach(d, 0, 0.55), grants: [certName],
        desc: `Short qualification: ${certName}. Quickest legal route into ${d.name.toLowerCase()}.`, adm: { edu: 1, gpa: 0 }, minGpa: 1.5 }));
    } else if (d.certProg && certName) {
      out.push(mk(d, "cert", { level: 3, years: 1, school: "community", name: certName, ageRule: "work", minAge: d.minAge || 0, teaches: teach(d, 0, 0.55), grants: [certName],
        desc: `${certName}: a one-year course in ${d.name.toLowerCase()} at a community college or online.`, adm: { edu: 1, gpa: 0 }, minGpa: 1.5 }));
    }
    if (d.voc && d.school === "nursing") {
      out.push(mk(d, "voc", { sub: "lpn", level: 3, years: 2, school: "community", name: d.voc, teaches: teach(d, 0, 0.7), grants: lic, desc: `${d.voc}: two years of clinical training at a community college. Enough to work as a nursing assistant.`, adm: { edu: 2, gpa: 2.0, skills: { science: 2 } }, minGpa: 2 }));
    }
    if (d.pgcert) {
      out.push(mk(d, "pgcert", { level: 3, years: 1, school: "grad", name: d.pgcert.name, grants: [d.pgcert.grants], teaches: teach(d, 0, 0.6), minAge: 0,
        desc: `${d.pgcert.name}: one year that turns any bachelor degree into a ${d.pgcert.grants.toLowerCase()}. Needed to teach a subject you studied.`, adm: { edu: 4, anyBachelor: true, gpa: 2.5 }, minGpa: 2 }));
    }
  }
  return out;
}

// ---------------- jobs ----------------
const hasProgram = (k) => { const d = DOMAIN_BY_KEY[k]; return d && (d.path === "pro" || hasDegree(d)); };
const lvlOf = (d) => (d.path === "pro" ? 6 : 4);
const degreeNames = (keys) => joinList(keys.map(fieldLabel));
const half = (skills, f = 0.5, cap = 3) => Object.fromEntries(Object.entries(skills).map(([s, v]) => [s, Math.max(1, Math.min(cap, Math.round(v * f)))]));
const fracSkills = (skills, f) => Object.fromEntries(Object.entries(skills).map(([s, v]) => [s, Math.max(1, Math.floor(v * f))]));
const HOURS = { medicine: 55, law: 50, finance: 48, retail: 36, streamer: 30, writer: 28, music: 32, military: 48, culinary: 48, cs: 42, delivery: 45, nursing: 44, firefighting: 48 };

export function buildCareer(d) {
  const name = d.job || d.ladder[1];
  const paths = [];
  const lic = d.licence;
  const accepted = d.deg.filter(hasProgram);
  const skills = d.skills;
  const dsk = fracSkills(skills, 0.7);
  const start = d.startRung ?? 1;
  if (accepted.length && d.path !== "pro") {
    paths.push({ label: `Bachelor in ${degreeNames(accepted)}`, rung: start, req: { edu: 4, degrees: accepted, skills: dsk, ...(lic && accepted.every((k) => k === d.key || DOMAIN_BY_KEY[k]?.licence === lic) ? { certs: [lic] } : {}) } });
  } else if (d.path === "pro") {
    paths.push({ label: DOMAIN_BY_KEY[d.key].pname, rung: start, req: { edu: 6, degrees: [d.key], skills: dsk, certs: lic ? [lic] : [] } });
  }
  if (d.altDeg) {
    paths.push({ label: `Bachelor in ${degreeNames(d.altDeg)} + ${d.pgcert.grants}`, rung: 1, req: { edu: 4, degrees: d.altDeg, certs: [d.pgcert.grants], skills: half(skills, 0.5, 3) } });
  }
  if (d.voc && d.school === "nursing") paths.push({ label: `${d.voc}`, rung: 0, req: { edu: 3, degrees: [d.key], certs: lic ? [lic] : [], skills: half(skills, 0.5, 2) } });
  if (d.assoc) paths.push({ label: `Associate degree in ${d.name}`, rung: d.path === "mixed" ? 1 : 0, req: { edu: 3, degrees: [d.key], skills: half(skills, 0.4, 2) } });
  if (d.cert && (d.certProg || d.path === "trade")) {
    const cr = d.certRung ?? (d.path === "trade" || d.path === "mixed" ? 1 : 0);
    paths.push({ label: d.cert, rung: cr, req: { edu: d.path === "trade" ? 1 : 2, certs: [d.cert], skills: half(skills, 0.4, 2) } });
  }
  if (d.path === "trade") {
    paths.push({ label: `${d.vocName || d.name + " Diploma"}`, rung: 1, req: { edu: 3, degrees: [d.key], skills: half(skills, 0.4, 2) } });
    paths.push({ label: "Apprenticeship intake", rung: 0, req: { edu: 1, skills: {} } });
  }
  if (d.path === "mixed") {
    paths.push({ label: "5 years of relevant experience", rung: 1, req: { edu: 2, exp: { field: d.key, years: 5 }, skills: half(skills, 0.5, 3) } });
    paths.push({ label: "Entry-level hire", rung: 0, req: { edu: 2, skills: half(skills, 0.35, 2) } });
  }
  if (d.entry && (d.path === "degree" || d.path === "pro")) paths.push({ label: "Entry-level hire (no degree)", rung: 0, req: { edu: 2, skills: half(skills, 0.35, 2) } });
  if (d.path === "pro" && d.cert) paths.push({ label: d.cert, rung: d.certRung ?? 0, req: { edu: 2, certs: [d.cert], skills: half(skills, 0.35, 2) } });
  if (d.path === "open") paths.push({ label: "No formal qualification needed", rung: 0, req: { edu: 0, skills: half(skills, 0.35, 2) } });
  if (d.path === "open" && d.cert) paths.push({ label: d.cert, rung: d.certRung ?? 1, req: { edu: 0, certs: [d.cert], skills: {} } });
  if (d.path === "talent") {
    paths.push({ label: "Proven talent", rung: 0, req: { edu: 0, skills: Object.fromEntries(Object.entries(skills).map(([s, v]) => [s, Math.max(2, v - 2)])) } });
    if (accepted.length) { /* degree route already pushed above */ }
    if (d.cert && d.certProg) { /* diploma route pushed above */ }
  }
  const minAge = d.minAge || (d.path === "degree" || d.path === "pro" ? 18 : 16);
  const base = d.salary; const mults = [0.62, 1, 1.7, 3];
  const ladder = d.ladder.map((t, i) => ({
    title: t, salaryUSD: Math.round((base * mults[i]) / 100) * 100, reqYears: [0, 2, 5, 9][i], reqPerf: [0, 50, 62, 72][i],
    reqSkills: Object.fromEntries(Object.entries(skills).map(([s, v]) => [s, Math.min(9, Math.max(1, Math.round(v * 0.7 + i * 1.1 - 0.7)))])),
  }));
  const routeText = paths.map((p) => p.label);
  return {
    id: `job:${d.key}`, type: "career", key: d.key, name, field: d.key, fieldName: d.name,
    desc: `${name}: ${d.subjects.slice(0, 2).join(" and ").toLowerCase()} in day-to-day work, with a clear path from ${d.ladder[0]} to ${d.ladder[3]}.`,
    salaryRange: [Math.round(base * 0.62), Math.round(base * 1.3)], ageRule: "work", minAge, pathways: paths, requirements: { minAge, skills, certs: [] },
    hours: d.hours || HOURS[d.key] || 40, licence: lic || null, ladder, routes: routeText, path: d.path,
  };
}

// ---------------- activities ----------------
export function buildActivity(a) {
  const reqs = { minAge: a.minAge, skills: a.skillReq || {}, stats: {} };
  if (a.maxAge) reqs.maxAge = a.maxAge;
  return { id: `act:${a.key}`, type: "activity", key: a.key, name: a.name, kind: a.kind, desc: `${a.name}: a regular commitment that builds ${Object.keys(a.gains).length ? Object.keys(a.gains).join(", ") : "wellbeing"}.`, requirements: reqs, costUSD: a.cost, gains: a.gains, stats: a.stats, hours: 4 };
}

// ---------------- schools (per country) ----------------
const INST = [
  { n: (c) => `University of ${c[0]}`, kind: "university", rep: 80, tm: 1.35, off: 0.3 },
  { n: (c) => `${c[1]} Institute of Technology`, kind: "university", rep: 68, tm: 1.0, off: 0.1 },
  { n: (c) => `${c[2]} Regional University`, kind: "university", rep: 52, tm: 0.8, off: -0.2 },
  { n: (c) => `${c[0]} Community College`, kind: "community", rep: 45, tm: 0.5, off: -0.4 },
  { n: (c) => `${c[1]} Community College`, kind: "community", rep: 42, tm: 0.45, off: -0.4 },
  { n: (c) => `${c[0]} Trade & Vocational School`, kind: "trade", rep: 52, tm: 0.45, off: -0.3 },
  { n: (c) => `${c[2]} Technical Institute`, kind: "trade", rep: 48, tm: 0.4, off: -0.3 },
  { n: (c) => `${c[0]} Graduate School`, kind: "grad", rep: 78, tm: 1.3, off: 0.2 },
  { n: (c) => `${c[1]} Graduate Institute`, kind: "grad", rep: 62, tm: 0.9, off: 0 },
  { n: (c) => `${c[0]} School of Medicine`, kind: "medical", rep: 86, tm: 1.35, off: 0.25 },
  { n: (c) => `${c[1]} Medical College`, kind: "medical", rep: 68, tm: 0.95, off: 0 },
  { n: (c) => `${c[0]} School of Dentistry`, kind: "dental", rep: 82, tm: 1.3, off: 0.2 },
  { n: (c) => `${c[1]} Dental College`, kind: "dental", rep: 64, tm: 0.9, off: 0 },
  { n: (c) => `${c[0]} Law School`, kind: "law", rep: 82, tm: 1.3, off: 0.25 },
  { n: (c) => `${c[1]} School of Law`, kind: "law", rep: 60, tm: 0.85, off: 0 },
  { n: (c) => `${c[0]} School of Nursing`, kind: "nursing", rep: 72, tm: 1.0, off: 0.1 },
  { n: (c) => `${c[1]} Nursing College`, kind: "nursing", rep: 55, tm: 0.7, off: -0.1 },
  { n: (c) => `${c[0]} College of Pharmacy`, kind: "pharmacy", rep: 70, tm: 1.0, off: 0.1 },
  { n: (c) => `${c[0]} Veterinary School`, kind: "vet", rep: 72, tm: 1.0, off: 0.1 },
  { n: () => `Open Online Academy`, kind: "online", rep: 50, tm: 0.35, off: -0.5 },
];
export function institutionsFor(country) {
  const c = countryOf(country);
  const cities = [...c.cities]; while (cities.length < 3) cities.push(cities[0]);
  return Catalog.list("institution").filter((i) => i.country === country).length ? Catalog.list("institution").filter((i) => i.country === country) : INST.map((t, idx) => Catalog.add({ id: `inst:${country}:${idx}`, type: "institution", key: `${country}|${idx}`, name: t.n(cities), kind: t.kind, city: cities[idx % 3], country, rep: t.rep, tuitionMult: t.tm, gpaOff: t.off }));
}
// Which schools teach a given programme
export const schoolsFor = (country, edu) => institutionsFor(country).filter((i) => i.kind === edu.school || (i.kind === "online" && (edu.school === "community" || (edu.school === "university" && ["mixed", "talent"].includes(DOMAIN_BY_KEY[edu.field]?.path) && edu.kind === "bach"))));

export function scholarshipsFor(inst, edu) {
  if (edu.level < 3) return [];
  return ["merit", "athletic", "need"].map((kind) => {
    const key = `${inst.id}|${edu.id}|${kind}`; const ex = Catalog.byKey("scholarship", key); if (ex) return ex;
    const cov = kind === "merit" ? 0.5 : kind === "athletic" ? 0.6 : 0.4;
    const reqs = kind === "merit" ? { gpa: Math.min(4, (edu.adm?.gpa || 2.5) + 0.7), gpaLevel: edu.level <= 4 ? 2 : 4 } : kind === "athletic" ? { skills: {}, stats: { fitness: 60 } } : {};
    return Catalog.add({ id: `sch:${hash(key)}`, type: "scholarship", key, name: `${inst.name} ${kind === "merit" ? "Merit Award" : kind === "athletic" ? "Athletic Scholarship" : "Opportunity Grant"}`, kind, coverage: cov + (kind === "merit" ? 0.1 : 0), requirements: reqs, keepGpa: 2.8, instId: inst.id, eduId: edu.id });
  });
}

// ---------------- sports (per country + city) ----------------
const MASCOTS = ["Hawks", "Rovers", "Titans", "Comets", "Wolves", "Falcons", "Storm", "Rangers"];
export function sportsFor(country, city) {
  const c = countryOf(country);
  if (Catalog.list("sport").some((o) => o.country === country && o.city === city)) return Catalog.list("sport").filter((o) => o.country === country && o.city === city);
  const out = [];
  for (const sp of SPORTS) for (let tier = 1; tier <= 5; tier++) {
    const pop = c.sports[SPORTS.indexOf(sp)] || 5; const T = SPORT_TIERS[tier - 1];
    const mascot = MASCOTS[parseInt(hash(city + sp.id), 36) % MASCOTS.length];
    const names = [`${city} ${["High", "Middle", "Junior"][tier % 3]} School ${sp.name} Team`, `${city} ${sp.name} Academy`, `${city} ${mascot} ${sp.name} Club`, `${c.name} ${sp.name} Pro League`, `${c.name} National ${sp.name} Squad`];
    const sk = [1, 3, 5, 7, 9][tier - 1] + (tier >= 3 && pop < 5 ? 1 : 0), fit = [25, 40, 50, 60, 75][tier - 1];
    out.push(Catalog.add({
      id: `sp:${country}:${city}:${sp.id}:${tier}`, type: "sport", key: `${sp.id}|${tier}|${country}|${city}`, name: names[tier - 1], sport: sp.id, tier, tierName: T.name, country, city,
      requirements: { minAge: tier === 1 ? Math.max(sp.minAge, 7) : tier === 2 ? 10 : tier === 3 ? 16 : tier === 4 ? 18 : 20, maxAge: tier === 1 ? 18 : tier === 2 ? 22 : tier === 3 ? 40 : tier === 4 ? 38 : 36, skills: { [sp.id]: Math.min(9, sk) }, stats: { fitness: fit } },
      salaryUSD: Math.round(T.pay * sp.pro * (0.4 + pop / 10)), popularity: pop, desc: `${T.name} ${sp.name.toLowerCase()} in ${tier >= 4 ? c.name : city}. Seasonal competition with awards and recruitment.`,
    }));
  }
  return out;
}

// ---------------- boot ----------------
let built = false;
export function buildBaseContent() {
  if (built) return Catalog.count();
  built = true;
  buildPrograms().forEach((e) => Catalog.add(e));
  DOMAINS.filter((d) => !d.nojob).forEach((d) => Catalog.add(buildCareer(d)));
  ACTIVITY_LEX.forEach((a) => Catalog.add(buildActivity(a)));
  return Catalog.count();
}
// Everything that depends on where the character lives
export function ensureLocal(state) { institutionsFor(state.country); sportsFor(state.country, state.city); }
