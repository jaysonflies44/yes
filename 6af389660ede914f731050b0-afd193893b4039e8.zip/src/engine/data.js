import { pick, int, clamp } from "./rng.js";

export const STATS = [
  { id: "happiness", name: "Happiness", good: true },
  { id: "health", name: "Health", good: true },
  { id: "smarts", name: "Smarts", good: true },
  { id: "looks", name: "Looks", good: true },
  { id: "fitness", name: "Fitness", good: true },
  { id: "reputation", name: "Reputation", good: true },
  { id: "stress", name: "Stress", good: false },
];
export const STAT_IDS = STATS.map((s) => s.id);

export const SKILL_CATS = ["academic", "social", "creative", "technical", "sport", "life"];
const S = (id, name, cat) => ({ id, name, cat, base: true });
export const BASE_SKILLS = [
  S("literature", "Literature", "academic"), S("mathematics", "Mathematics", "academic"),
  S("logic", "Logic", "academic"), S("science", "Science", "academic"), S("languages", "Languages", "academic"),
  S("communication", "Communication", "social"), S("leadership", "Leadership", "social"), S("business", "Business", "social"),
  S("creativity", "Creativity", "creative"), S("art", "Art", "creative"), S("music", "Music", "creative"), S("cooking", "Cooking", "life"),
  S("programming", "Programming", "technical"), S("gaming", "Gaming", "technical"),
  S("basketball", "Basketball", "sport"), S("football", "Football", "sport"), S("baseball", "Baseball", "sport"),
  S("volleyball", "Volleyball", "sport"), S("tennis", "Tennis", "sport"), S("swimming", "Swimming", "sport"),
  S("athletics", "Athletics", "sport"), S("boxing", "Boxing", "sport"),
  S("medicine", "Medicine", "technical"), S("law", "Law", "academic"), S("engineering", "Engineering", "technical"), S("finance", "Finance", "academic"),
  S("aviation", "Aviation", "technical"), S("trades", "Skilled Trades", "technical"), S("agriculture", "Agriculture", "life"), S("teaching", "Teaching", "social"),
  S("fashion", "Fashion", "creative"), S("security", "Security & Defense", "technical"), S("photography", "Photography", "creative"), S("dance", "Dance", "creative"),
  S("chess", "Chess", "academic"), S("writing", "Creative Writing", "creative"), S("woodworking", "Woodworking", "life"),
];

export const PERSONALITY = [
  { id: "openness", name: "Openness" }, { id: "conscientiousness", name: "Discipline" },
  { id: "extraversion", name: "Extraversion" }, { id: "agreeableness", name: "Kindness" }, { id: "neuroticism", name: "Anxiety" },
];

export const EDU_LEVELS = ["None", "Primary school", "High school", "Vocational / Diploma", "Bachelor", "Master", "Doctorate"];
export const EDU_WORD = ["", "Primary school", "High school diploma", "Diploma or certificate", "Bachelor degree", "Master degree", "Doctorate"];

export const SPORTS = [
  { id: "basketball", name: "Basketball", minAge: 6, pro: 1.0, team: true },
  { id: "football", name: "Football", minAge: 6, pro: 1.1, team: true },
  { id: "baseball", name: "Baseball", minAge: 6, pro: 0.9, team: true },
  { id: "volleyball", name: "Volleyball", minAge: 8, pro: 0.5, team: true },
  { id: "tennis", name: "Tennis", minAge: 6, pro: 0.8, team: false },
  { id: "swimming", name: "Swimming", minAge: 5, pro: 0.4, team: false },
  { id: "athletics", name: "Athletics", minAge: 7, pro: 0.4, team: false },
  { id: "boxing", name: "Boxing", minAge: 12, pro: 0.7, team: false },
];
export const SPORT_TIERS = [
  { lvl: 1, name: "School team", pay: 0 }, { lvl: 2, name: "Club academy", pay: 0 },
  { lvl: 3, name: "Semi-pro league", pay: 18000 }, { lvl: 4, name: "Professional", pay: 120000 }, { lvl: 5, name: "National / elite", pay: 450000 },
];

const CT = (code, name, cur, sym, rate, wage, col, tui, ss, se, work, drive, drink, retire, health, tax, order, cities, m, f, l, sp) => ({
  code, name, cur, sym, rate, wage, col, tui, schoolStart: ss, secEnd: se, workAge: work, driveAge: drive, drinkAge: drink,
  retire, health, tax, order, cities: cities.split(","), names: { m: m.split(" "), f: f.split(" "), l: l.split(" ") },
  sports: sp.split("").map(Number),
});
// sports order: basketball football baseball volleyball tennis swimming athletics boxing
export const COUNTRIES = [
  CT("US", "United States", "USD", "$", 1, 1, 1, 1, 5, 18, 15, 16, 21, 67, "private", .22, "w", "New York,Los Angeles,Chicago,Houston,Atlanta,Seattle", "James Michael Liam Noah Ethan Daniel Mateo Tyrell", "Emma Olivia Sophia Ava Mia Harper Isabella Maya", "Smith Johnson Williams Brown Garcia Miller Davis Carter", "96845655"),
  CT("GB", "United Kingdom", "GBP", "£", .79, .8, .95, .6, 5, 18, 16, 17, 18, 67, "universal", .25, "w", "London,Manchester,Birmingham,Glasgow,Leeds,Bristol", "Oliver George Harry Jack Alfie Archie Callum Tom", "Olivia Amelia Isla Poppy Grace Freya Ella Ruby", "Taylor Evans Thomas Roberts Walker Wright Hughes Clarke", "36421465"),
  CT("CA", "Canada", "CAD", "C$", 1.36, .85, .95, .5, 5, 18, 15, 16, 19, 65, "universal", .25, "w", "Toronto,Vancouver,Montreal,Calgary,Ottawa", "Liam Noah Lucas Ethan Benjamin Jacob Felix Owen", "Emma Olivia Charlotte Chloe Zoe Sophie Ava Lily", "Tremblay Roy Gagnon Wilson MacDonald Singh Chen Campbell", "74554644"),
  CT("DE", "Germany", "EUR", "€", .92, .9, .9, .05, 6, 19, 15, 18, 16, 67, "universal", .32, "w", "Berlin,Munich,Hamburg,Cologne,Frankfurt", "Lukas Leon Jonas Felix Paul Maximilian Finn Elias", "Emma Mia Hannah Sophia Lina Lea Clara Emilia", "Müller Schmidt Schneider Fischer Weber Meyer Wagner Becker", "55356455"),
  CT("FR", "France", "EUR", "€", .92, .8, .9, .1, 6, 18, 16, 18, 18, 64, "universal", .33, "w", "Paris,Lyon,Marseille,Toulouse,Nice", "Gabriel Louis Jules Hugo Arthur Léo Nathan Adam", "Emma Jade Louise Alice Chloé Inès Léa Manon", "Martin Bernard Dubois Moreau Laurent Simon Michel Lefebvre", "55346555"),
  CT("JP", "Japan", "JPY", "¥", 150, .7, .85, .5, 6, 18, 16, 18, 20, 65, "universal", .22, "e", "Tokyo,Osaka,Kyoto,Nagoya,Fukuoka,Sapporo", "Haruto Yuto Sota Ren Kaito Daiki Takumi Riku", "Yui Hina Sakura Aoi Mio Rin Koharu Akari", "Sato Suzuki Takahashi Tanaka Watanabe Ito Yamamoto Nakamura", "47965566"),
  CT("KR", "South Korea", "KRW", "₩", 1330, .7, .85, .5, 6, 18, 15, 18, 19, 63, "universal", .2, "e", "Seoul,Busan,Incheon,Daegu,Daejeon", "Minjun Seojun Doyun Jihoon Hyunwoo Joon Taeyang Jiho", "Seoyeon Jiwoo Haeun Soyul Yuna Minseo Chaewon Hayoon", "Kim Lee Park Choi Jung Kang Cho Yoon", "46846574"),
  CT("BR", "Brazil", "BRL", "R$", 5, .3, .45, .2, 6, 17, 14, 18, 18, 65, "mixed", .18, "w", "São Paulo,Rio de Janeiro,Brasília,Salvador,Curitiba", "Miguel Arthur Heitor Davi Gabriel Pedro Lucas Rafael", "Helena Alice Laura Maria Valentina Sophia Isabella Júlia", "Silva Santos Oliveira Souza Pereira Costa Rodrigues Almeida", "49358566"),
  CT("IN", "India", "INR", "₹", 83, .18, .3, .1, 6, 17, 14, 18, 21, 60, "mixed", .12, "w", "Mumbai,Delhi,Bengaluru,Chennai,Kolkata,Hyderabad", "Aarav Vihaan Arjun Rohan Ishaan Kabir Aditya Rahul", "Aadhya Diya Ananya Saanvi Meera Priya Kavya Isha", "Sharma Patel Singh Kumar Gupta Reddy Iyer Khan", "37152566"),
  CT("NG", "Nigeria", "NGN", "₦", 1500, .12, .3, .08, 6, 17, 16, 18, 18, 60, "private", .1, "w", "Lagos,Abuja,Kano,Ibadan,Port Harcourt", "Chinedu Emeka Tunde Ifeanyi Segun Obinna Kelechi Ade", "Chioma Ngozi Amara Folake Blessing Ife Zainab Adaeze", "Okafor Adeyemi Balogun Eze Okonkwo Bello Nwosu Ogunleye", "46156559"),
  CT("MX", "Mexico", "MXN", "Mex$", 17, .3, .45, .2, 6, 18, 15, 18, 18, 65, "mixed", .16, "w", "Mexico City,Guadalajara,Monterrey,Puebla,Cancún", "Santiago Mateo Sebastián Leonardo Diego Emiliano Angel Luis", "Sofía Valentina Camila Regina Ximena Renata María Fernanda", "Hernández García Martínez López González Pérez Ramírez Flores", "49655555"),
  CT("AU", "Australia", "AUD", "A$", 1.5, .95, 1, .7, 5, 17, 15, 17, 18, 67, "universal", .26, "w", "Sydney,Melbourne,Brisbane,Perth,Adelaide", "Oliver Jack William Noah Henry Lachlan Hudson Cooper", "Charlotte Olivia Mia Isla Matilda Ruby Willow Zara", "Smith Jones Williams Brown Wilson Taylor Anderson Nguyen", "65356866"),
  CT("ES", "Spain", "EUR", "€", .92, .6, .7, .15, 6, 18, 16, 18, 18, 66, "universal", .27, "w", "Madrid,Barcelona,Valencia,Seville,Bilbao", "Hugo Martín Lucas Mateo Pablo Álvaro Daniel Javier", "Lucía Sofía Martina Paula Julia Carmen Valeria Alba", "García Rodríguez González Fernández López Martínez Sánchez Romero", "76435555"),
  CT("PH", "Philippines", "PHP", "₱", 56, .15, .35, .1, 6, 17, 15, 17, 18, 60, "private", .12, "w", "Manila,Cebu,Davao,Quezon City", "Juan Jose Miguel Angelo Paolo Carlo Rafael Joshua", "Maria Angel Sofia Althea Bianca Isabel Kristine Nicole", "Santos Reyes Cruz Bautista Garcia Mendoza Torres Aquino", "98253357"),
  CT("ET", "Ethiopia", "ETB", "Br", 120, .08, .25, .02, 6, 18, 16, 18, 18, 60, "private", .1, "w", "Addis Ababa,Dire Dawa,Hawassa,Bahir Dar,Mekelle", "Abebe Dawit Yonas Samuel Kidus Bereket Henok Natnael", "Hana Selam Meron Tigist Liya Betty Rahel Eden", "Tesfaye Bekele Girma Assefa Alemu Haile Tadesse Wolde", "35255985"),
  CT("KE", "Kenya", "KES", "KSh", 130, .12, .3, .05, 6, 18, 16, 18, 18, 60, "private", .12, "w", "Nairobi,Mombasa,Kisumu,Nakuru,Eldoret", "Brian Kevin Otieno Kamau Mwangi Juma Collins Dennis", "Faith Mercy Wanjiru Akinyi Njeri Grace Joy Achieng", "Kamau Otieno Mwangi Odhiambo Wanjala Njoroge Kiplagat Mutua", "34255957"),
];
export const countryOf = (code) => COUNTRIES.find((c) => c.code === code) || COUNTRIES[0];

export const fmtMoney = (usd, code = "US", opts = {}) => {
  const c = countryOf(code);
  const v = usd * c.rate;
  const neg = v < 0;
  const a = Math.abs(v);
  let s;
  if (opts.compact && a >= 1e6) s = (a / 1e6).toFixed(1) + "M";
  else if (opts.compact && a >= 1e4) s = Math.round(a / 1e3) + "k";
  else s = Math.round(a).toLocaleString("en-US");
  return (neg ? "-" : "") + c.sym + s;
};

export const fullName = (n, order = "w") => {
  const mid = n.middle ? n.middle + " " : "";
  return order === "e" ? `${n.last} ${n.first}` : `${n.first} ${mid}${n.last}`.replace("  ", " ");
};
export const nameOf = (p, code) => fullName(p.name, countryOf(code || p.country).order);
export const shortName = (p) => p.name.first;

export const makeName = (country, gender, lastOverride) => {
  const c = countryOf(country);
  const g = gender === "female" ? "f" : "m";
  return { first: pick(c.names[g]), middle: chance(0.5) ? pick(c.names[g]) : "", last: lastOverride || pick(c.names.l) };
};
function chance(p) { return Math.random() < p; }

export const LIFE_STAGE = (age) => age < 1 ? "Newborn" : age < 3 ? "Infant" : age < 6 ? "Toddler" : age < 13 ? "Child" : age < 18 ? "Teen" : age < 30 ? "Young adult" : age < 45 ? "Adult" : age < 65 ? "Midlife" : "Senior";
export const STAGE_HUE = (age) => age < 6 ? 85 : age < 13 ? 165 : age < 18 ? 230 : age < 30 ? 118 : age < 45 ? 60 : age < 65 ? 320 : 280;

export const HOUSING = [
  { id: "parents", name: "Family home", rent: 0, buy: 0 },
  { id: "shared", name: "Shared flat", rent: 5400, buy: 0, minAge: 17 },
  { id: "apartment", name: "Own apartment", rent: 11000, buy: 0, minAge: 18 },
  { id: "condo", name: "Condo (buy)", rent: 0, buy: 140000, minAge: 21 },
  { id: "house", name: "House (buy)", rent: 0, buy: 320000, minAge: 21 },
];

export const EYES = { B: "brown", G: "green", U: "blue" };
export const HAIRS = { K: "black", N: "brown", L: "blonde", R: "red" };
export const EYE_DOM = ["B", "G", "U"];
export const HAIR_DOM = ["K", "N", "L", "R"];
export const eyeColor = (a) => EYES[EYE_DOM[Math.min(EYE_DOM.indexOf(a[0]), EYE_DOM.indexOf(a[1]))]];
export const hairColor = (a) => HAIRS[HAIR_DOM[Math.min(HAIR_DOM.indexOf(a[0]), HAIR_DOM.indexOf(a[1]))]];
export const GROWTH = [.3, .42, .5, .55, .6, .64, .68, .72, .75, .78, .81, .84, .87, .91, .95, .98, .995, 1];
export const statLvl = (v) => Math.floor(v / 10);
export const skillLvl = (v) => Math.floor(v || 0);
export const ZODIAC = (m, d) => { const z = ["Capricorn","Aquarius","Pisces","Aries","Taurus","Gemini","Cancer","Leo","Virgo","Libra","Scorpio","Sagittarius","Capricorn"]; const cut = [20,19,21,20,21,21,23,23,23,23,22,22]; return z[d < cut[m - 1] ? m - 1 : m]; };
export { clamp, int };
