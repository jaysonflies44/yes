// IndexedDB wrapper with in-memory fallback. Stores: saves, catalog, cache, skills, meta
const NAME = "lifeline-sim", VER = 1, STORES = ["saves", "catalog", "cache", "skills", "meta"];
let dbp = null;
const mem = Object.fromEntries(STORES.map((s) => [s, new Map()]));
const keyOf = (s) => (s === "cache" ? "key" : "id");
function open() {
  if (dbp) return dbp;
  dbp = new Promise((res) => {
    try {
      if (!globalThis.indexedDB) return res(null);
      const r = indexedDB.open(NAME, VER);
      r.onupgradeneeded = () => { const d = r.result; STORES.forEach((s) => { if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { keyPath: keyOf(s) }); }); };
      r.onsuccess = () => res(r.result);
      r.onerror = () => res(null);
      r.onblocked = () => res(null);
    } catch { res(null); }
  });
  return dbp;
}
const tx = (d, s, mode, fn) => new Promise((res, rej) => { const t = d.transaction(s, mode); const st = t.objectStore(s); const rq = fn(st); t.oncomplete = () => res(rq?.result); t.onerror = () => rej(t.error); });
export const db = {
  async put(s, v) { const d = await open(); mem[s].set(v[keyOf(s)], v); if (d) { try { await tx(d, s, "readwrite", (st) => st.put(JSON.parse(JSON.stringify(v)))); } catch {} } return v; },
  async get(s, k) { const d = await open(); if (d) { try { return (await tx(d, s, "readonly", (st) => st.get(k))) ?? null; } catch {} } return mem[s].get(k) ?? null; },
  async all(s) { const d = await open(); if (d) { try { return (await tx(d, s, "readonly", (st) => st.getAll())) || []; } catch {} } return [...mem[s].values()]; },
  async del(s, k) { const d = await open(); mem[s].delete(k); if (d) { try { await tx(d, s, "readwrite", (st) => st.delete(k)); } catch {} } },
  async clear(s) { const d = await open(); mem[s].clear(); if (d) { try { await tx(d, s, "readwrite", (st) => st.clear()); } catch {} } },
  async persistent() { return !!(await open()); },
};
