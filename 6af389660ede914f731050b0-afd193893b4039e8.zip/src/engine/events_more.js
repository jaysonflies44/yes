// More life events: illness, money for kids (ask your parents), jobs, school and university milestones, adult and senior life.
import { countryOf } from "./data.js";
import { pick, int, chance } from "./rng.js";
import { o, ch, col, U, M, pers, npcOf, nm, hasFlag, CITY, hooks } from "./evkit.js";
import { illnessFor } from "./health.js";

const kid = (s) => s.age < 18 && s.housing.id === "parents";
const secEnd = (s) => countryOf(s.country).secEnd;
const par = (s) => nm(npcOf(s, ["mother", "father"]), "your parents");

const SICK_TEXT = {
  baby: (n) => `You can't stop crying and you feel hot. ${n} rushes you to bed and checks on you every few minutes.`,
  child: (n, ill) => `You wake up feeling terrible: ${ill.desc.toLowerCase()} ${n} wants to know what to do.`,
  teen: (n, ill) => `Something's wrong. ${ill.desc} You could see a doctor or just tough it out.`,
  adult: (n, ill) => `${ill.desc} It's getting in the way of your life.`,
};
export const MORE_TEMPLATES = [
  // ================= HEALTH: illness and injury (special doctor window) =================
  { id: "sick", ages: [0, 100], cd: 2, w: (s) => 1.1 + (s.stats.health < 60 ? 1.8 : 0) + (s.age < 8 ? 1 : 0) + (s.age > 60 ? 1.2 : 0),
    when: (s) => s.conditions.filter((c) => !c.chronic).length < 2,
    make: (s) => {
      const ill = illnessFor(s); if (!ill) return null;
      const p = nm(npcOf(s, ["mother", "father"]), "Mom");
      const t = (s.age < 3 ? SICK_TEXT.baby : s.age < 13 ? SICK_TEXT.child : s.age < 18 ? SICK_TEXT.teen : SICK_TEXT.adult)(p, ill);
      return { title: ill.kind === "injury" ? `Injured: ${ill.name}` : `You're sick: ${ill.name}`, text: t, ui: "doctor", ill: ill.id, choices: [] };
    } },

  // ================= EARLY CHILDHOOD =================
  { id: "toy_want", ages: [3, 9], w: 4, cd: 2, make: (s) => ({ title: "I want that toy!", text: `You spot the toy everyone is talking about in a shop window in ${CITY(s)}. You tug on ${par(s)}'s sleeve.`, choices: [
    ch("Ask your parents to buy it", [o(0.7, "They smile and buy it. You play with it all week.", { h: 8, sk: { creativity: 0.1 } }), o(0.3, "Your parents laugh and say maybe for your birthday.", { h: -1 })], { cost: U(s, 40) }),
    ch("Throw a tantrum", [o(0.2, "It works! You get the toy and a lecture.", { h: 4, rel: [["parent", -3, -2]] }), o(0.8, "Time-out. No toy, no dessert.", { h: -4, rel: [["parent", -2]] })]),
    ch("Forget about it", [o(1, "You find a cardboard box and it becomes a spaceship.", { h: 3, sk: { creativity: 0.3 } })])] }) },
  { id: "birthday_party", ages: [4, 12], w: 3, cd: 2, make: (s) => ({ title: "Birthday party plans", text: "Your birthday is coming. Your friends keep asking what you're doing.", choices: [
    ch("Ask for a big party", [o(0.75, "Cake, balloons and a bouncy castle. Everyone has a blast.", { h: 9, rp: 2, newNpc: { role: "friend", ageRel: 0 } }), o(0.25, "It rains and the castle deflates, but you laugh anyway.", { h: 5 })], { cost: U(s, 150) }),
    ch("Small family dinner", [o(1, "Your favourite meal and a handmade card.", { h: 5, rel: [["parent", 4, 3]] })])] }) },
  { id: "learn_bike", ages: [4, 9], w: 3, make: (s) => ({ title: "Training wheels off", text: `${par(s)} says you're ready to ride without training wheels.`, choices: [
    ch("Give it a go", [o(0.65, "Wobble, wobble... you're riding! You feel on top of the world.", { h: 8, ft: 2, sk: { athletics: 0.2 } }), o(0.35, "You scrape your knee but you get up and try again.", { h: 2, hp: -1, ft: 1 })]),
    ch("Ask for a new bike first", [o(0.7, "Your parents buy you a shiny bike.", { h: 8, ft: 2 }), o(0.3, "Not this year, your parents say. You borrow a cousin's.", { h: 2, ft: 1 })], { cost: U(s, 150) })] }) },
  { id: "lost_tooth", ages: [5, 8], w: 4, make: (s) => ({ title: "A wobbly tooth", text: "Your front tooth finally comes out while you're eating an apple.", auto: true, choices: [ch("Put it under the pillow", [o(0.9, "The tooth fairy leaves a few coins.", { h: 5, m: U(s, 3) }), o(0.1, "The fairy forgot. Your parents look embarrassed the next morning.", { h: 1 })])] }) },
  { id: "glasses", ages: [5, 15], w: 2.5, cd: 5, make: (s) => ({ title: "Squinting at the board", text: "Your teacher noticed you squint at the board. A note goes home: you may need glasses.", choices: [
    ch("Get an eye test and glasses", [o(1, "Suddenly the world is sharp. You can read the board from the back row.", { sm: 1, h: 3, lk: -1, flag: "glasses" })], { cost: U(s, s.healthSystem === "universal" ? 40 : 180), essential: true }),
    ch("Ignore it", [o(1, "Headaches and bad grades follow.", { sm: -1, h: -2, hp: -1 })])] }) },
  { id: "braces", ages: [10, 15], w: 2.5, cd: 8, when: (s) => !hasFlag(s, "had_braces"), make: (s) => ({ title: "The orthodontist's verdict", text: "Your dentist says your teeth will need braces to fix the bite. It's a long and expensive treatment.", choices: [
    ch("Get the braces", [o(1, "Two years of metal and wax, then a perfect smile.", { lk: 4, h: 2, flag: "had_braces" })], { cost: U(s, 2500) }),
    ch("Skip it", [o(1, "Your teeth stay a little crooked. You learn to love your smile anyway.", { lk: -1, flag: "had_braces" })])] }) },
  { id: "summer_camp", ages: [7, 14], w: 3, cd: 2, make: (s) => ({ title: "Summer camp", text: `Your friends are heading to summer camp near ${CITY(s)}. Canoes, campfires, and no homework.`, choices: [
    ch("Go to camp", [o(0.8, "Two weeks of lake swims and ghost stories. You come home tanned and happy.", { h: 8, ft: 2, newNpc: { role: "friend", ageRel: 0 }, sk: { leadership: 0.2 } }), o(0.2, "Homesick for three days, then you love it.", { h: 4, ft: 1 })], { cost: U(s, 400) }),
    ch("Stay home for the summer", [o(1, "Lazy mornings and neighbourhood games.", { h: 3 })])] }) },
  { id: "lemonade", ages: [7, 12], w: 2.5, cd: 4, make: (s) => ({ title: "Lemonade stand", text: "It's a hot day. You and a friend set up a wobbly table in front of the house.", choices: [
    ch("Sell lemonade", [o(0.7, "Neighbours queue up! You split a pile of coins.", { m: U(s, 20), h: 6, sk: { business: 0.3 } }), o(0.3, "Only your grandparents show up, but they tip well.", { m: U(s, 6), h: 3 })]),
    ch("Drink it all yourself", [o(1, "Sticky and happy.", { h: 3 })])] }) },
  { id: "chores_allowance", ages: [7, 14], w: 3, cd: 3, make: (s) => ({ title: "Chores for pocket money", text: `${par(s)} offers you pocket money if you help around the house.`, choices: [
    ch("Do the chores", [o(1, "You wash dishes and mow lawns. Your parents are proud.", { m: U(s, 25), rel: [["parent", 3, 3, 3]], sk: { leadership: 0.1 } })]),
    ch("Not interested", [o(1, "You'd rather play.", { h: 2 })])] }) },
  { id: "sports_gear", ages: [7, 16], w: 3, cd: 3, when: (s) => !!s.sport.team || s.activities.some((a) => a.name), make: (s) => ({ title: "New gear", text: "Your old equipment is falling apart, and everyone else has the new kit.", choices: [
    ch("Ask your parents for new gear", [o(0.75, "Fresh kit and a new spring in your step.", { ft: 2, h: 5 }), o(0.25, "They fix up the old kit instead.", { h: 1 })], { cost: U(s, 120) }),
    ch("Make do", [o(1, "Duct tape holds a surprising amount together.", { st: 1 })])] }) },
  { id: "kid_phone", ages: [10, 16], w: 3, cd: 4, when: (s) => !hasFlag(s, "has_phone"), make: (s) => ({ title: "Everyone has a phone", text: `All your friends have one. You ask ${par(s)} for your own phone.`, choices: [
    ch("Ask your parents to buy one", [o(0.8, "Your parents hand over a phone with a long list of rules.", { h: 8, rp: 1, flag: "has_phone" }), o(0.2, "A hand-me-down phone with a cracked screen. Better than nothing.", { h: 4, flag: "has_phone" })], { cost: U(s, 400) }),
    ch("Wait until you're older", [o(1, "You borrow your friends' phones for now.", { h: -2 })])] }) },
  { id: "teen_concert", ages: [13, 18], w: 3, cd: 3, make: (s) => ({ title: "Concert tickets", text: "Your favourite artist is playing in town. Your whole friend group is going.", choices: [
    ch("Buy a ticket", [o(0.8, "Screaming every lyric with your friends. Unforgettable.", { h: 10, st: -6, rel: [["friend", 5, 3]] }), o(0.2, "Your seats are terrible but the energy is unreal.", { h: 6 })], { cost: U(s, 90) }),
    ch("Skip it", [o(1, "You watch the clips online the next morning.", { h: -2 })])] }) },
  { id: "sneakers", ages: [10, 17], w: 2.5, cd: 3, make: (s) => ({ title: "Those sneakers", text: "The sneakers everyone wants just dropped. They're not cheap.", choices: [
    ch("Ask your parents for them", [o(0.7, "Your parents give in. You feel like a million bucks.", { h: 7, lk: 1, rp: 1 }), o(0.3, "Your parents suggest you wait for a sale.", { h: -1 })], { cost: U(s, 130) }),
    ch("Save up for them", [o(1, "It takes a while, but they're yours in the end.", { h: 4, sk: { business: 0.1 } })])] }) },

  // ================= SCHOOL MILESTONES =================
  { id: "first_day", ages: [3, 7], must: true, when: (s) => s.age === countryOf(s.country).schoolStart, make: (s) => ({ title: "First day of school", text: `Backpack on, shoes tied. ${par(s)} walks you to the school gates in ${CITY(s)}.`, auto: true, choices: [ch("Go inside", [o(0.7, "You make a friend before lunch.", { h: 6, newNpc: { role: "classmate", ageRel: 0 } }), o(0.3, "A few tears at the door, then you have fun.", { h: 3 })])] }) },
  { id: "graduation", ages: [14, 20], must: true, when: (s) => s.age === secEnd(s) && s.edu.level >= 2, make: (s) => ({ title: "Graduation day", text: `You walk across the stage with a ${s.edu.schoolGpa.toFixed(1)} GPA. Cap in the air, family in the front row.`, auto: true, choices: [ch("Celebrate", [o(1, "A day you will remember forever.", { h: 10, rp: 2, rel: [["parent", 5, 3, 4]], mem: "Graduated high school." })])] }) },
  { id: "uni_decision", ages: [14, 24], must: true, when: (s) => s.age >= secEnd(s) && s.edu.level >= 2 && !s.edu.current && s.edu.done.every((d) => d.level < 4),
    make: (s) => ({ title: "What comes after school?", text: `You've graduated. Do you want to apply to university, a community college or a trade school? Each has its own entry requirements. You can always reapply later from the Education tab.`, ui: "university", kinds: ["university", "community", "trade", "nursing", "online"], choices: [] }) },
  { id: "grad_decision", ages: [21, 40], cd: 6, w: 2, when: (s) => !s.edu.current && s.edu.done.some((d) => d.level >= 4) && s.edu.level < 6, make: (s) => ({ title: "Back to school?", text: `Your bachelor degree opens more doors. Graduate school, medical school, law school or a dental programme could change your career, if you qualify.`, ui: "university", kinds: ["grad", "medical", "dental", "law", "nursing", "pharmacy", "vet"], choices: [] }) },
  { id: "counselor", ages: [15, 18], w: 4, cd: 3, make: (s) => ({ title: "Career counsellor", text: "A counsellor asks what you want to do after school. You've been dodging the question.", choices: [
    ch("Ask about university", [o(1, "She explains the options: universities, graduate programmes and professional schools. After graduation you can apply from the Education tab.", { sm: 1, st: -1 })]),
    ch("Ask about trades and jobs", [o(1, "You see paths without a degree. Open the Career tab to see which jobs you already qualify for.", { sm: 1, st: -1 })]),
    ch("Shrug", [o(1, "She sighs and hands you a pamphlet.", { st: 2 })])] }) },
  { id: "entrance_exam", ages: [16, 19], w: 3, cd: 3, when: (s) => !s.edu.current && s.edu.level < 4, make: (s) => ({ title: "Entrance exam prep", text: "Entrance exams are coming up. Every school has its own cut-off.", choices: [
    ch("Hire a tutor", [o(0.8, "Your practice scores jump.", { sm: 2, gpa: 0.1, sk: { mathematics: 0.2, literature: 0.2 }, st: 3 }), o(0.2, "The tutor is bad. Money down the drain.", { st: 4 })], { cost: U(s, 300) }),
    ch("Study alone every night", [o(0.7, "Slow and steady works.", { sm: 1, gpa: 0.08, st: 6 }), o(0.3, "You burn out before the exam.", { st: 10, h: -3 })]),
    ch("Wing it", [o(1, "You scrape through on charm.", { st: -2, gpa: -0.05 })])] }) },

  // ================= JOBS (special job-offer window) =================
  { id: "first_job_offer", ages: [14, 17], w: 4, cd: 2, when: (s) => !s.job && s.age >= countryOf(s.country).workAge, make: (s) => {
    const off = hooks.makeJobOffer(s, { partTime: true }); if (!off) return null;
    return { title: "A part-time job offer", text: `A business in ${CITY(s)} wants to hire you after school and on weekends. The pay is small but real.`, ui: "job_offer", offer: off, choices: [] };
  } },
  { id: "job_offer", ages: [18, 62], w: (s) => (s.job ? 2.2 : 4), cd: 3, when: (s) => !s.retired && !s.edu.current, make: (s) => {
    const off = hooks.makeJobOffer(s, { better: !!s.job, partTime: s.age < 18 ? true : false }); if (!off) return null;
    return { title: s.job ? "A recruiter's message" : "A job offer", text: s.job ? `A recruiter from ${off.company} has noticed your work. They would like to offer you a role as ${off.title}.` : `${off.company} has an opening that matches your qualifications and wants you to join as ${off.title}.`, ui: "job_offer", offer: off, choices: [] };
  } },
  { id: "burnout", ages: [24, 62], w: 2, cd: 5, when: (s) => !!s.job && s.stats.stress > 60, make: (s) => ({ title: "Running on empty", text: `Months of long days at ${s.job.company || s.job.name} have left you exhausted.`, choices: [
    ch("Take a week off", [o(0.8, "You come back sharper.", { st: -14, h: 5, perf: 3 }), o(0.2, "The pile of work waiting is brutal.", { st: -6, perf: -2 })]),
    ch("Power through", [o(0.5, "You hit your targets, but it costs you.", { perf: 5, st: 8, hp: -3 }), o(0.5, "Mistakes creep in.", { perf: -6, st: 10, hp: -3 })]),
    ch("Book a weekend retreat", [o(1, "Fresh air, no phone, new perspective.", { st: -18, h: 8 })], { cost: U(s, 450) })] }) },

  // ================= ADULT LIFE =================
  { id: "car_accident", ages: [18, 80], w: 1.5, cd: 6, when: (s) => hasFlag(s, "has_licence") || hasFlag(s, "owns_car"), make: (s) => ({ title: "Fender bender", text: "Someone clips your car at a junction. Nobody's hurt, but the bumper is crumpled.", choices: [
    ch("Pay for proper repairs", [o(1, "The car looks new again.", { st: 2 })], { cost: U(s, 900) }),
    ch("Patch it yourself", [o(0.5, "Good enough.", { st: 3 }), o(0.5, "It rattles and costs you more later.", { st: 5, m: -U(s, 200) })]),
    ch("Argue about fault", [o(0.4, "Their insurance pays.", { h: 3 }), o(0.6, "You lose a week and your patience.", { st: 8, h: -3 })])] }) },
  { id: "tax_letter", ages: [25, 75], w: 1.5, cd: 6, when: (s) => !!s.job || s.money.cash > 5000, make: (s) => ({ title: "A letter from the tax office", text: "They want to double-check last year's return.", choices: [
    ch("Hire an accountant", [o(1, "The accountant sorts it out in an afternoon.", { st: -2 })], { cost: U(s, 300) }),
    ch("Handle it yourself", [o(0.6, "Boring, but fine.", { st: 3, sk: { finance: 0.2 } }), o(0.4, "You missed a form and pay a penalty.", { st: 7, m: -U(s, 250) })])] }) },
  { id: "home_repair", ages: [28, 85], w: 2, cd: 4, when: (s) => ["condo", "house"].includes(s.housing.id), make: (s) => ({ title: "The roof is leaking", text: "A brown stain spreads across the ceiling after the storm.", choices: [
    ch("Call a professional", [o(1, "Fixed properly. The house is dry again.", { st: -1 })], { cost: U(s, 1800) }),
    ch("Patch it with a bucket and hope", [o(0.4, "It holds for now.", { st: 3 }), o(0.6, "More damage, bigger bill later.", { st: 8, h: -3, m: -U(s, 900) })])] }) },
  { id: "marathon", ages: [18, 55], w: 2, cd: 6, make: (s) => ({ title: "Sign up for a marathon?", text: "A friend is training for the city marathon and asks if you want to join.", choices: [
    ch("Train and run it", [o(0.7, "You cross the finish line in tears. Best feeling ever.", { ft: 7, h: 10, st: -4, sk: { athletics: 0.5 } }), o(0.3, "You pull a muscle at kilometre 30 but finish.", { ft: 4, h: 5, hp: -3 })], { cost: U(s, 60) }),
    ch("Cheer from the sidelines", [o(1, "You hold the signs and hand out water.", { h: 4, rel: [["friend", 4, 3]] })])] }) },
  { id: "volunteer_call", ages: [16, 80], w: 2, cd: 4, make: (s) => ({ title: "Neighbours need help", text: `A flood has hit part of ${CITY(s)}. Volunteers are filling sandbags.`, choices: [
    ch("Help out for the weekend", [o(1, "Muddy, tired, proud.", { rp: 4, h: 6, ft: 2, sk: { leadership: 0.2 } })]),
    ch("Donate supplies instead", [o(1, "You drop off water and blankets.", { rp: 2, h: 3 })], { cost: U(s, 60) }),
    ch("Stay out of it", [o(1, "You watch the news with a pinch of guilt.", { h: -2 })])] }) },
  { id: "retirement_plan", ages: [58, 67], w: 4, cd: 5, make: (s) => ({ title: "Planning for retirement", text: "A financial adviser sits you down and goes through the numbers.", choices: [
    ch("Pay for a full plan", [o(1, "Clear numbers and a calmer mind.", { st: -8, h: 4, sk: { finance: 0.3 } })], { cost: U(s, 400) }),
    ch("Read up on it yourself", [o(1, "Slow but free. You feel a little more prepared.", { st: -3, sk: { finance: 0.2 } })]),
    ch("Worry about it later", [o(1, "Later always arrives.", { st: 3 })])] }) },
  { id: "senior_trip", ages: [60, 90], w: 3, cd: 4, make: (s) => ({ title: "A once-in-a-lifetime trip", text: "Your old friends are planning a group trip: sunshine, slow mornings, and long dinners.", choices: [
    ch("Join the trip", [o(0.85, "Laughter, sunsets and photos you'll treasure.", { h: 10, st: -8, rel: [["friend", 6, 4]] }), o(0.15, "A cold comes with you, but the memories are worth it.", { h: 6, hp: -2 })], { cost: U(s, 1800) }),
    ch("Stay home", [o(1, "A quiet week in the garden.", { h: 1, st: -2 })])] }) },
  { id: "memory_lapse", ages: [70, 100], w: 2, cd: 4, make: (s) => ({ title: "Where did I put my keys?", text: "A few small slips lately. Your family is quietly worried.", choices: [
    ch("See a doctor about it", [o(0.8, "Reassuring news and a few tips to stay sharp.", { st: -5, hp: 1 }), o(0.2, "The doctor suggests regular check-ups.", { st: 3, cond: ["Mild memory loss", 1, true] })], { cost: U(s, s.healthSystem === "universal" ? 40 : 200), essential: true }),
    ch("Brush it off", [o(1, "Probably just age.", { st: 2 })])] }) },
];
