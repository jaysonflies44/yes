import { countryOf, fmtMoney, SPORTS } from "./data.js";
import { pick, int, chance, wpick, uid, cap } from "./rng.js";

// ---------- shorthand builders ----------
export const SMAP = { h: "happiness", hp: "health", sm: "smarts", lk: "looks", ft: "fitness", rp: "reputation", st: "stress" };
export const fx = (o = {}) => {
  const c = {}; const stats = {};
  for (const [k, v] of Object.entries(o)) {
    if (SMAP[k]) stats[SMAP[k]] = v;
    else if (k === "sk") c.skills = v;
    else if (k === "m") c.money = v;
    else if (k === "rel") c.rel = v.map(([target, affection = 0, trust = 0, respect = 0]) => ({ target, affection, trust, respect }));
    else if (k === "flag") c.flags = Object.fromEntries([].concat(v).map((f) => [f, true]));
    else if (k === "unflag") c.flags = { ...(c.flags || {}), ...Object.fromEntries([].concat(v).map((f) => [f, false])) };
    else if (k === "fu") c.followup = { id: v[0], inYears: v[1] };
    else if (k === "cond") c.condition = { name: v[0], sev: v[1] || 1, chronic: !!v[2] };
    else if (k === "mem") c.memory = v;
    else c[k] = v;
  }
  if (Object.keys(stats).length) c.stats = stats;
  return c;
};
export const o = (w, text, spec) => ({ weight: w, text, consequences: fx(spec) });
export const ch = (label, outcomes, extra = {}) => ({ label, outcomes, ...extra });
export const col = (s) => countryOf(s.country).col;
export const U = (s, usd) => Math.max(1, Math.round((usd * col(s)) / 5) * 5 || 1);
export const M = (s, usd) => fmtMoney(usd, s.country);
export const pers = (s, k) => s.personality[k] / 100;
export const npcOf = (s, roles) => { const l = s.rels.filter((r) => r.alive && roles.includes(r.role) && r.status !== "estranged"); return l.length ? pick(l) : null; };
export const nm = (n, d = "someone") => (n ? n.name.first : d);
export const hasFlag = (s, f) => s.memory.flags[f] != null;
export const CITY = (s) => s.city;


// Late-bound functions that live in sim.js (avoids a circular import).
export const hooks = {};
