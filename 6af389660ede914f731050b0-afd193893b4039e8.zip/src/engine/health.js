// Illnesses, injuries and how they are treated. Used by sick-events, the Health tab and the yearly health roll.
import { countryOf } from "./data.js";
import { pick, chance, clamp, wpick } from "./rng.js";

// cure = how likely a proper treatment is to clear it. chronic illnesses are managed, not cured.
const I = (id, name, ages, w, sev, o = {}) => ({ id, name, ages, w, sev, chronic: false, cure: 0.85, kind: "illness", ...o });
export const ILLNESSES = [
  I("cold", "Common cold", [0, 100], 7, 1, { desc: "Runny nose, cough, a few miserable days.", cure: 0.95 }),
  I("flu", "Influenza", [0, 100], 4, 1, { desc: "High fever, aches and exhaustion.", cure: 0.9 }),
  I("stomach", "Stomach bug", [0, 100], 4, 1, { desc: "Cramps and sickness. Nothing stays down.", cure: 0.95 }),
  I("ear", "Ear infection", [0, 11], 5, 1, { desc: "A painful, throbbing ear. Common in small kids.", cure: 0.92 }),
  I("chickenpox", "Chickenpox", [2, 10], 4, 1, { desc: "Itchy spots everywhere. Contagious.", cure: 0.95, once: true }),
  I("strep", "Strep throat", [3, 17], 3, 1, { desc: "A raging sore throat and fever. Needs antibiotics.", cure: 0.9 }),
  I("rsv", "Bronchiolitis", [0, 3], 3, 2, { desc: "A serious chest infection in babies and toddlers.", cure: 0.88 }),
  I("measles", "Measles", [1, 14], 1.2, 2, { desc: "Rash, fever and eye pain. Rare where vaccination is common.", cure: 0.85, once: true }),
  I("asthma", "Asthma", [3, 60], 1.6, 1, { desc: "Wheezing and tight breathing. Managed with an inhaler.", chronic: true, once: true }),
  I("foodallergy", "Food allergy", [1, 40], 1.4, 1, { desc: "Your body reacts badly to certain foods.", chronic: true, once: true }),
  I("fracture", "Broken arm", [4, 16], 2.4, 2, { desc: "A fall on the playground. A cast and six weeks off sport.", kind: "injury", cure: 0.92 }),
  I("sprain", "Sprained ankle", [8, 70], 2.4, 1, { desc: "Twisted it badly. Swollen and sore.", kind: "injury", cure: 0.95 }),
  I("concussion", "Concussion", [6, 60], 1.2, 2, { desc: "A knock to the head. Headaches and dizziness.", kind: "injury", cure: 0.85 }),
  I("mono", "Mononucleosis", [14, 25], 1.6, 2, { desc: "Weeks of extreme tiredness and a sore throat.", cure: 0.8 }),
  I("appendicitis", "Appendicitis", [6, 45], 0.9, 3, { desc: "Sharp stomach pain. Needs urgent hospital treatment.", cure: 0.95, hospital: true }),
  I("pneumonia", "Pneumonia", [0, 100], 1.6, 2, { desc: "A serious lung infection.", cure: 0.82 }),
  I("backpain", "Back pain", [22, 85], 2.6, 1, { desc: "A nagging ache that makes everything harder.", cure: 0.8 }),
  I("migraine", "Migraine disorder", [14, 70], 1.6, 1, { desc: "Crushing headaches with light sensitivity.", chronic: true, once: true }),
  I("anxiety", "Anxiety disorder", [11, 85], 1.8, 1, { desc: "Constant worry and a racing heart.", chronic: true, once: true, mental: true }),
  I("depression", "Depression", [13, 90], 1.4, 2, { desc: "A heavy low mood that will not lift.", chronic: true, once: true, mental: true }),
  I("hyper", "Hypertension", [38, 100], 2, 1, { desc: "High blood pressure. Quietly raises heart risk.", chronic: true, once: true }),
  I("diabetes", "Type 2 diabetes", [35, 100], 1.6, 2, { desc: "Blood sugar is out of balance. Needs lifelong management.", chronic: true, once: true }),
  I("arthritis", "Arthritis", [48, 100], 2, 1, { desc: "Stiff, painful joints.", chronic: true, once: true }),
  I("hipfracture", "Hip fracture", [68, 100], 1.6, 3, { desc: "A fall at home. Surgery and a long recovery.", kind: "injury", cure: 0.75, hospital: true }),
  I("heart", "Heart condition", [50, 100], 1, 3, { desc: "Chest pain and breathlessness. Serious.", chronic: true, once: true, hospital: true }),
  I("cancer", "Early-stage cancer", [40, 100], 0.7, 3, { desc: "Caught early, but it needs specialist treatment now.", cure: 0.6, hospital: true }),
];
export const ILLNESS_BY_ID = Object.fromEntries(ILLNESSES.map((i) => [i.id, i]));
export const illnessOf = (cond) => ILLNESS_BY_ID[cond.ill] || ILLNESSES.find((i) => i.name === cond.name) || null;

// Pick an illness that makes sense for this person's age and does not repeat what they already have or had.
export function illnessFor(s) {
  const had = s.memory.had || (s.memory.had = {});
  const pool = ILLNESSES.filter((i) => s.age >= i.ages[0] && s.age <= i.ages[1] && !s.conditions.some((c) => c.name === i.name) && !(i.once && had[i.id]));
  if (!pool.length) return null;
  const frailty = 1 + Math.max(0, 55 - s.stats.health) / 40;
  return wpick(pool, (i) => i.w * (i.sev >= 2 ? frailty : 1));
}

// ---------- treatment ----------
const TIER = { universal: { otc: 8, doctor: 30, specialist: 150 }, mixed: { otc: 12, doctor: 120, specialist: 900 }, private: { otc: 15, doctor: 220, specialist: 1800 } };
const POWER = { rest: 0.4, otc: 0.6, doctor: 0.88, specialist: 0.99 };
export function treatmentOptions(s, cond) {
  const ill = illnessOf(cond) || { cure: 0.85, chronic: cond.chronic };
  const col = countryOf(s.country).col; const t = TIER[s.healthSystem] || TIER.private; const sevM = 1 + (cond.sev - 1) * 0.35;
  const opts = [];
  const sevPen = cond.sev === 3 ? 0.55 : cond.sev === 2 ? 0.85 : 1;
  const cure = (power, hospitalNeeded) => {
    if (cond.chronic) return null;
    let p = (ill.cure ?? 0.85) * power;
    if (cond.sev === 3 && power < 0.95) p *= sevPen;
    if (ill.hospital && power < 0.95) p *= 0.6;
    if (s.age < 12) p += 0.05;
    return clamp(p, 0.05, 0.99);
  };
  opts.push({ id: "rest", label: ill.kind === "injury" ? "Rest and ice it" : "Rest at home", desc: "Free. Let your body deal with it.", cost: 0, chance: cure(POWER.rest), essential: false });
  if (cond.sev <= 1) opts.push({ id: "otc", label: "Over-the-counter medicine", desc: "Cheap relief from the pharmacy.", cost: Math.round(t.otc * col), chance: cure(POWER.otc), essential: false });
  opts.push({ id: "doctor", label: "Consult a doctor", desc: cond.chronic ? "A prescription and a care plan to keep it under control." : "A proper diagnosis and the right treatment.", cost: Math.round(t.doctor * col * sevM), chance: cure(POWER.doctor), essential: true });
  if (cond.sev >= 2 || ill.hospital) opts.push({ id: "specialist", label: ill.hospital ? "Hospital / surgery" : "See a specialist", desc: "The best care money can buy.", cost: Math.round(t.specialist * col * sevM), chance: cure(POWER.specialist), essential: true });
  return opts;
}
// Applies a chosen treatment. `pay` is sim.payFor, passed in so health.js stays free of circular imports.
export function treatCondition(s, cond, optId, pay, add) {
  const opt = treatmentOptions(s, cond).find((o) => o.id === optId);
  if (!opt) return { error: "No such treatment." };
  const paid = pay(s, opt.cost, { essential: opt.essential });
  if (!paid.ok) return { error: paid.refused ? "parents" : "afford", need: opt.cost, opt };
  const by = paid.by === "parents" ? " Your parents took care of the bill." : "";
  const lines = opt.cost && paid.by === "self" ? [{ text: `-${opt.cost}`, tone: "bad", money: opt.cost }] : [];
  let text; let cured = false;
  if (cond.chronic) {
    if (optId === "rest" || optId === "otc") { s.stats.health = clamp(s.stats.health + (optId === "otc" ? 1 : 0), 0, 100); text = optId === "otc" ? "The medicine eases the symptoms for a while, but it doesn't fix the cause." : "You push through. It stays with you."; }
    else { cond.managed = true; if (optId === "specialist" && cond.sev > 1 && chance(0.5)) { cond.sev -= 1; text = `The specialist adjusts your treatment plan. ${cond.name} is now milder.`; } else text = `You leave with a care plan for ${cond.name}. Managed well, it will bother you far less.`; s.stats.health = clamp(s.stats.health + 3, 0, 100); }
  } else if (chance(opt.chance)) {
    cured = true; s.conditions = s.conditions.filter((c) => c !== cond && c.name !== cond.name);
    s.stats.health = clamp(s.stats.health + 4, 0, 100);
    text = optId === "rest" ? `You rest, and ${cond.name.toLowerCase()} clears up on its own.` : `The treatment works. ${cond.name} is gone.`;
    lines.push({ text: `Recovered: ${cond.name}`, tone: "good" });
  } else {
    s.stats.health = clamp(s.stats.health - (optId === "rest" && cond.sev >= 3 ? 8 : 2), 0, 100);
    if (optId === "rest" && cond.sev >= 2 && chance(0.25)) { cond.sev = Math.min(3, cond.sev + 1); text = `Without proper care, ${cond.name.toLowerCase()} gets worse.`; lines.push({ text: "Condition worsened", tone: "bad" }); }
    else text = `It hasn't cleared yet. ${opt.id === "doctor" || opt.id === "specialist" ? "The doctor wants to see you again if it lingers." : "Maybe try a proper treatment."}`;
  }
  return { ok: true, text: text + by, lines, cured, paid, opt };
}
