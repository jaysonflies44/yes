// Base content library. Every field of study / line of work in the game is defined here by hand.
// A "domain" is one field: it yields its degree programmes (education), its job (career) and its qualification routes.
//
//   path:   degree  = a degree is the normal way in         mixed = degree OR certificate OR experience
//           trade   = vocational diploma / apprenticeship   open  = no formal education needed
//           talent  = proven talent or a diploma            pro   = professional school (medical, dental, law ...)
//   deg:    the degrees (domain keys) that actually qualify you for this job. NOT "anything vaguely related".
//   feeds:  the degrees accepted for admission to this field's Master/PhD ("any" = any bachelor).
//   school: which kind of school teaches the main programme.

const D = (key, name, path, skills, subjects, ladder, salary, o = {}) => ({
  key, name, path, skills, subjects: subjects.split("|"), ladder: ladder.split("|"), salary, deg: [key], school: path === "trade" ? "trade" : "university", ...o,
});

// ---- degree groups used for professional-school admission ----
export const PREMED = ["biology", "chemistry", "biomedsci", "physics", "nursing", "pharmacy", "psychology", "publichealth", "physio"];
export const PREDENT = ["biology", "chemistry", "biomedsci", "physics", "nursing"];
export const PREPHARM = ["chemistry", "biology", "biomedsci", "pharmacy", "nursing"];
export const PREVET = ["biology", "biomedsci", "chemistry", "environment"];
export const TEACH_SUBJECTS = ["english", "mathematics", "biology", "chemistry", "physics", "history", "languages", "music", "design", "geography"];

export const DOMAINS = [
  // ================= HEALTH =================
  D("medicine", "Medicine", "pro", { science: 6, logic: 5, communication: 4, medicine: 4 }, "Anatomy|Physiology|Pharmacology|Clinical Rotations|Pathology", "Resident Doctor|Physician|Consultant|Chief of Medicine", 190000,
    { school: "medical", years: 4, prereq: PREMED, gpa: 3.3, stats: { smarts: 55 }, licence: "Medical Licence", startRung: 0, pname: "Doctor of Medicine (MD)", hours: 55 }),
  D("dentistry", "Dentistry", "pro", { science: 6, medicine: 3, art: 2 }, "Oral Anatomy|Dental Materials|Periodontics|Radiology|Clinical Dentistry", "Dental Assistant|Dentist|Senior Dentist|Clinic Owner", 150000,
    { school: "dental", years: 4, prereq: PREDENT, gpa: 3.2, stats: { smarts: 50 }, licence: "Dental Licence", startRung: 1, pname: "Doctor of Dental Surgery (DDS)", cert: "Dental Assistant Certificate", certRung: 0, certProg: true }),
  D("pharmacy", "Pharmacy", "pro", { science: 6, mathematics: 3, medicine: 2 }, "Pharmacology|Medicinal Chemistry|Drug Safety|Dispensing|Toxicology", "Pharmacy Technician|Pharmacist|Senior Pharmacist|Chief Pharmacist", 110000,
    { school: "pharmacy", years: 4, prereq: PREPHARM, gpa: 3.0, licence: "Pharmacy Licence", startRung: 1, pname: "Doctor of Pharmacy (PharmD)", cert: "Pharmacy Technician Certificate", certRung: 0, certProg: true }),
  D("vet", "Veterinary Medicine", "pro", { science: 6, medicine: 2, communication: 3 }, "Animal Anatomy|Pathology|Surgery|Large Animals|Companion Animals", "Vet Assistant|Veterinarian|Senior Vet|Clinic Director", 95000,
    { school: "vet", years: 4, prereq: PREVET, gpa: 3.1, licence: "Veterinary Licence", startRung: 1, pname: "Doctor of Veterinary Medicine (DVM)", cert: "Veterinary Assistant Certificate", certRung: 0, certProg: true }),
  D("nursing", "Nursing", "degree", { science: 4, communication: 4, medicine: 2 }, "Patient Care|Anatomy|Pharmacology|Clinical Practice|Health Ethics", "Nursing Assistant|Registered Nurse|Senior Nurse|Head of Nursing", 72000,
    { school: "nursing", years: 3, bd: "Bachelor of Science", licence: "Nursing Licence", cert: "Nursing Assistant Certificate", certRung: 0, voc: "Practical Nursing Diploma", vocRung: 0, master: true, entry: true, feeds: "any" }),
  D("physio", "Physiotherapy", "degree", { science: 5, medicine: 2, communication: 3 }, "Anatomy|Biomechanics|Rehabilitation|Exercise Therapy|Clinical Placements", "Rehab Assistant|Physiotherapist|Senior Physiotherapist|Head of Rehabilitation", 76000,
    { years: 3, bd: "Bachelor of Science", licence: "Physiotherapy Licence", master: true, entry: true }),
  D("radiography", "Radiography", "degree", { science: 5, logic: 3, medicine: 2 }, "Imaging Physics|Anatomy|Radiation Safety|Patient Care|Diagnostic Imaging", "Imaging Assistant|Radiographer|Senior Radiographer|Head of Imaging", 70000,
    { years: 3, bd: "Bachelor of Science", licence: "Radiography Licence", entry: true }),
  D("biomedsci", "Biomedical Science", "degree", { science: 6, logic: 3, mathematics: 2 }, "Cell Biology|Immunology|Genetics|Microbiology|Lab Techniques", "Lab Assistant|Biomedical Scientist|Senior Scientist|Laboratory Director", 62000,
    { deg: ["biomedsci", "biology", "chemistry"], master: true, phd: true, entry: true }),
  D("publichealth", "Public Health", "degree", { science: 4, communication: 4, mathematics: 3 }, "Epidemiology|Biostatistics|Health Policy|Community Health|Environmental Health", "Health Programme Assistant|Public Health Officer|Senior Epidemiologist|Director of Public Health", 64000,
    { deg: ["publichealth", "biomedsci", "biology", "nursing"], master: true, phd: true, feeds: "any" }),
  D("paramedic", "Paramedic Science", "trade", { science: 3, communication: 3, medicine: 2 }, "Emergency Care|Trauma Response|Pharmacology|Patient Transport|Clinical Practice", "EMT Trainee|Paramedic|Critical Care Paramedic|Chief Paramedic", 52000,
    { cert: "EMT Certification", vocName: "Paramedic Science Diploma", minAge: 18 }),
  D("caregiver", "Care Work", "open", { communication: 2 }, "Personal Care|Dementia Care|First Aid|Safeguarding|Nutrition", "Care Assistant|Senior Carer|Care Coordinator|Care Home Manager", 28000,
    { cert: "First Aid & Care Certificate", certProg: true, certRung: 1, minAge: 16 }),
  D("psychology", "Psychology", "degree", { science: 3, communication: 4, logic: 3 }, "Cognitive Psychology|Developmental Psychology|Research Methods|Counselling|Neuroscience", "Psychology Aide|Counsellor|Clinical Psychologist|Clinic Director", 78000,
    { bd: "Bachelor of Science", master: true, phd: true, entry: true, feeds: "any" }),
  D("socialwork", "Social Work", "degree", { communication: 4, leadership: 2 }, "Casework|Family Systems|Community Practice|Social Policy|Ethics", "Support Worker|Social Worker|Senior Social Worker|Agency Director", 46000,
    { deg: ["socialwork", "psychology", "sociology"], bd: "Bachelor of Arts", master: true, entry: true, feeds: "any" }),

  // ================= SCIENCE =================
  D("biology", "Biology", "degree", { science: 6, mathematics: 3, logic: 3 }, "Cell Biology|Genetics|Ecology|Evolution|Lab Methods", "Lab Technician|Biologist|Senior Research Scientist|Research Director", 62000,
    { deg: ["biology", "biomedsci", "environment"], bd: "Bachelor of Science", master: true, phd: true, entry: true }),
  D("chemistry", "Chemistry", "degree", { science: 6, mathematics: 4, logic: 3 }, "Organic Chemistry|Inorganic Chemistry|Analytical Methods|Physical Chemistry|Lab Safety", "Lab Technician|Chemist|Senior Chemist|Head of R&D", 66000,
    { deg: ["chemistry", "chemeng", "biomedsci"], master: true, phd: true, entry: true }),
  D("physics", "Physics", "degree", { science: 6, mathematics: 6, logic: 4 }, "Mechanics|Electromagnetism|Quantum Physics|Thermodynamics|Astrophysics", "Lab Technician|Physicist|Senior Physicist|Research Director", 74000,
    { deg: ["physics", "mathematics"], master: true, phd: true, entry: true }),
  D("mathematics", "Mathematics", "degree", { mathematics: 6, logic: 4 }, "Calculus|Linear Algebra|Probability|Number Theory|Statistics", "Junior Analyst|Statistician|Senior Analyst|Chief Quantitative Officer", 70000,
    { deg: ["mathematics", "datasci", "physics"], master: true, phd: true, entry: true, job: "Statistician" }),
  D("environment", "Environmental Science", "degree", { science: 5, mathematics: 3, communication: 3 }, "Ecology|Climate Science|Environmental Policy|GIS Mapping|Conservation", "Field Assistant|Environmental Scientist|Senior Scientist|Director of Sustainability", 62000,
    { deg: ["environment", "biology", "chemistry"], bd: "Bachelor of Science", master: true, phd: true, entry: true }),
  D("agriculture", "Agriculture", "trade", { agriculture: 3, science: 2, business: 2 }, "Soil Science|Crop Systems|Livestock|Farm Business|Sustainability", "Farm Hand|Farm Manager|Agronomist|Estate Owner", 38000,
    { cert: "Agricultural Certificate", vocName: "Agricultural Diploma", minAge: 16 }),

  // ================= TECHNOLOGY =================
  D("cs", "Computer Science", "mixed", { programming: 5, logic: 4, mathematics: 3 }, "Algorithms|Operating Systems|Databases|Software Engineering|Networks", "Junior Developer|Software Engineer|Senior Engineer|Engineering Director", 85000,
    { deg: ["cs", "softwareeng", "infotech", "datasci", "ai"], cert: "Coding Bootcamp Certificate", certProg: true, master: true, phd: true, job: "Software Engineer" }),
  D("softwareeng", "Software Engineering", "degree", { programming: 5, logic: 4, mathematics: 2 }, "Software Design|Testing|Agile Delivery|Web Systems|Cloud Computing", "Junior Developer|Software Engineer|Senior Engineer|Engineering Director", 85000,
    { deg: ["softwareeng", "cs"], master: true, nojob: true }),
  D("infotech", "Information Technology", "mixed", { programming: 2, logic: 3, communication: 2 }, "Networking|Systems Administration|Cloud Basics|Help Desk Practice|Information Security", "Help Desk Technician|Systems Administrator|IT Manager|Chief Information Officer", 68000,
    { deg: ["infotech", "cs", "cyber", "softwareeng"], cert: "IT Support Certificate", certProg: true, assoc: true, master: true }),
  D("datasci", "Data Science", "mixed", { programming: 4, mathematics: 5, logic: 4 }, "Machine Learning|Statistics|Data Engineering|Visualisation|Ethics of Data", "Data Analyst|Data Scientist|Senior Data Scientist|Head of Data", 90000,
    { deg: ["datasci", "mathematics", "cs", "ai"], cert: "Data Analytics Certificate", certProg: true, master: true, phd: true, job: "Data Scientist" }),
  D("ai", "Artificial Intelligence", "degree", { programming: 5, mathematics: 5, logic: 5 }, "Neural Networks|Robotics|Optimisation|Natural Language Processing|Computer Vision", "ML Technician|ML Engineer|Senior Researcher|Chief AI Scientist", 115000,
    { deg: ["ai", "cs", "datasci"], master: true, phd: true, job: "Machine Learning Engineer" }),
  D("cyber", "Cybersecurity", "mixed", { programming: 4, logic: 5, mathematics: 3 }, "Cryptography|Network Defense|Digital Forensics|Penetration Testing|Risk Management", "Security Analyst|Security Engineer|Security Architect|CISO", 95000,
    { deg: ["cyber", "cs", "infotech", "softwareeng"], cert: "Security+ Certification", certProg: true, master: true }),
  D("gamedev", "Game Development", "mixed", { programming: 4, creativity: 4, gaming: 3 }, "Game Engines|Level Design|Narrative Design|3D Modelling|Game AI", "QA Tester|Game Developer|Lead Designer|Studio Director", 72000,
    { deg: ["gamedev", "cs", "softwareeng"], cert: "Game Dev Portfolio Course", certProg: true, bd: "Bachelor of Science" }),

  // ================= ENGINEERING & BUILT ENVIRONMENT =================
  D("engineering", "General Engineering", "degree", { mathematics: 5, science: 5, logic: 4, engineering: 3 }, "Statics|Circuits|Thermodynamics|Materials|Design Projects", "Junior Engineer|Project Engineer|Senior Engineer|Chief Engineer", 88000,
    { deg: ["engineering", "civileng", "mecheng", "eleceng", "chemeng", "aeroeng"], bd: "Bachelor of Engineering", master: true, phd: true, job: "Project Engineer" }),
  D("civileng", "Civil Engineering", "degree", { mathematics: 5, science: 4, logic: 4, engineering: 3 }, "Structures|Soil Mechanics|Hydraulics|Transport Design|Construction Methods", "Junior Engineer|Civil Engineer|Senior Civil Engineer|Chief Engineer", 84000,
    { deg: ["civileng", "engineering"], bd: "Bachelor of Engineering", master: true, phd: true, licence: "Professional Engineer Licence", licenceRung: 2 }),
  D("mecheng", "Mechanical Engineering", "degree", { mathematics: 5, science: 4, logic: 4, engineering: 3 }, "Dynamics|Thermodynamics|Fluid Mechanics|Machine Design|Manufacturing", "Junior Engineer|Mechanical Engineer|Senior Mechanical Engineer|Chief Engineer", 88000,
    { deg: ["mecheng", "engineering", "aeroeng"], bd: "Bachelor of Engineering", master: true, phd: true }),
  D("eleceng", "Electrical Engineering", "degree", { mathematics: 6, science: 4, logic: 4, engineering: 3 }, "Circuits|Signals|Power Systems|Electronics|Control Systems", "Junior Engineer|Electrical Engineer|Senior Electrical Engineer|Chief Engineer", 92000,
    { deg: ["eleceng", "engineering"], bd: "Bachelor of Engineering", master: true, phd: true }),
  D("chemeng", "Chemical Engineering", "degree", { mathematics: 5, science: 5, logic: 4, engineering: 3 }, "Process Design|Reaction Engineering|Mass Transfer|Plant Safety|Materials", "Process Technician|Chemical Engineer|Senior Process Engineer|Plant Director", 94000,
    { deg: ["chemeng", "engineering", "chemistry"], bd: "Bachelor of Engineering", master: true, phd: true }),
  D("aeroeng", "Aerospace Engineering", "degree", { mathematics: 6, science: 5, logic: 4, engineering: 3 }, "Aerodynamics|Propulsion|Flight Mechanics|Structures|Avionics", "Junior Engineer|Aerospace Engineer|Senior Aerospace Engineer|Chief Designer", 98000,
    { deg: ["aeroeng", "mecheng"], bd: "Bachelor of Engineering", master: true, phd: true }),
  D("architecture", "Architecture", "degree", { creativity: 5, mathematics: 3, art: 3 }, "Design Studio|Structures|Architectural History|CAD|Sustainability", "Architectural Assistant|Architect|Senior Architect|Principal Architect", 82000,
    { years: 5, bd: "Bachelor of Architecture", master: true, licence: "Architect Licence", licenceRung: 1, entry: true }),
  D("construction", "Construction Management", "mixed", { leadership: 3, business: 3, trades: 2 }, "Site Management|Building Law|Cost Estimating|Health & Safety|Project Planning", "Site Assistant|Site Manager|Project Manager|Construction Director", 78000,
    { deg: ["construction", "civileng", "architecture", "engineering"], cert: "Construction Safety Certificate", certProg: true }),

  // ================= SKILLED TRADES =================
  D("electrician", "Electrician", "trade", { trades: 4, logic: 2 }, "Wiring|Circuit Theory|Electrical Code|Safety|Troubleshooting", "Apprentice Electrician|Electrician|Master Electrician|Electrical Contractor", 58000, { cert: "Electrician Licence", minAge: 17 }),
  D("plumbing", "Plumbing", "trade", { trades: 4, logic: 2 }, "Pipework|Heating Systems|Drainage|Safety|Troubleshooting", "Apprentice Plumber|Plumber|Master Plumber|Plumbing Contractor", 56000, { cert: "Plumbing Licence", minAge: 17 }),
  D("carpentry", "Carpentry", "trade", { trades: 3, woodworking: 3, creativity: 2 }, "Joinery|Framing|Blueprint Reading|Tools & Materials|Finishing", "Apprentice Carpenter|Carpenter|Master Carpenter|Building Contractor", 50000, { cert: "Carpentry Certificate", minAge: 16 }),
  D("welding", "Welding & Fabrication", "trade", { trades: 4, logic: 2 }, "Arc Welding|Metal Fabrication|Blueprint Reading|Safety|Inspection", "Welding Apprentice|Welder|Certified Welder|Fabrication Supervisor", 52000, { cert: "Welding Certification", minAge: 17 }),
  D("automech", "Automotive Technology", "trade", { trades: 3, science: 2, logic: 2 }, "Engines|Brakes & Suspension|Diagnostics|Electrical Systems|Workshop Safety", "Trainee Mechanic|Auto Mechanic|Master Technician|Garage Owner", 48000, { cert: "Automotive Technician Certificate", minAge: 16, job: "Auto Mechanic" }),
  D("hvac", "HVAC & Refrigeration", "trade", { trades: 4, science: 2 }, "Heating|Ventilation|Refrigeration|Controls|Safety", "HVAC Apprentice|HVAC Technician|Senior Technician|HVAC Contractor", 54000, { cert: "HVAC Certification", minAge: 17 }),
  D("cosmetology", "Hair & Beauty", "trade", { creativity: 3, communication: 3 }, "Cutting & Styling|Colour Theory|Skin Care|Salon Business|Hygiene", "Salon Assistant|Hairstylist|Senior Stylist|Salon Owner", 34000, { cert: "Cosmetology Licence", minAge: 16 }),
  D("culinary", "Culinary Arts", "trade", { cooking: 5, creativity: 3 }, "Knife Skills|Pastry|Menu Planning|Food Safety|Kitchen Management", "Kitchen Hand|Line Cook|Sous Chef|Head Chef", 42000, { cert: "Food Safety Certificate", minAge: 16, job: "Chef" }),
  D("aviation", "Aviation", "trade", { mathematics: 4, science: 3, logic: 4, aviation: 3 }, "Flight Theory|Navigation|Meteorology|Aircraft Systems|Crew Resource Mgmt", "Cadet Pilot|First Officer|Captain|Chief Pilot", 105000, { cert: "Commercial Pilot Licence", vocName: "Professional Pilot Diploma", minAge: 18, job: "Airline Pilot" }),
  D("firefighting", "Firefighting", "trade", { security: 2, communication: 2 }, "Fire Behaviour|Rescue Techniques|Hazmat|First Response|Fitness Training", "Recruit Firefighter|Firefighter|Fire Lieutenant|Fire Chief", 54000, { cert: "Fire Academy Certificate", minAge: 18 }),

  // ================= PUBLIC SERVICE =================
  D("policing", "Police & Law Enforcement", "mixed", { communication: 3, logic: 3, security: 2 }, "Procedure|Community Policing|Investigation|Criminal Law|Defensive Tactics", "Police Recruit|Police Officer|Detective|Chief of Police", 56000,
    { deg: ["criminology", "legalstudies", "psychology", "sociology"], cert: "Police Academy Certificate", certProg: true, minAge: 18, job: "Police Officer" }),
  D("criminology", "Criminology", "degree", { logic: 3, communication: 3, literature: 2 }, "Theories of Crime|Forensic Science|Criminal Justice|Research Methods|Penology", "Research Assistant|Crime Analyst|Senior Analyst|Director of Criminal Intelligence", 56000,
    { deg: ["criminology", "sociology", "psychology", "legalstudies"], bd: "Bachelor of Arts", master: true, entry: true }),
  D("securityguard", "Security Services", "open", { communication: 1 }, "Patrol Practice|Access Control|Conflict De-escalation|First Aid|Reporting", "Security Guard|Senior Guard|Security Supervisor|Head of Security", 30000, { minAge: 18 }),
  D("military", "Military Service", "open", { leadership: 2, security: 1 }, "Drill|Tactics|Logistics|Leadership|Survival", "Private|Sergeant|Captain|Colonel", 44000, { minAge: 18 }),
  D("politics", "Political Science", "degree", { literature: 4, communication: 5, leadership: 4 }, "Political Theory|Comparative Politics|Policy Analysis|Diplomacy|Public Administration", "Staffer|Policy Advisor|Government Official|Minister", 65000,
    { deg: ["politics", "history", "economics", "law", "sociology"], bd: "Bachelor of Arts", master: true, phd: true, feeds: "any", entry: true }),

  // ================= LAW =================
  D("law", "Law", "pro", { literature: 5, logic: 5, communication: 5, law: 3 }, "Contract Law|Criminal Law|Constitutional Law|Legal Writing|Professional Ethics", "Law Clerk|Associate Lawyer|Senior Counsel|Partner", 120000,
    { school: "law", years: 3, prereq: "any", gpa: 3.0, stats: { smarts: 45 }, licence: "Bar Admission", startRung: 1, pname: "Juris Doctor (JD)", job: "Lawyer", hours: 50 }),
  D("legalstudies", "Legal Studies", "mixed", { literature: 3, logic: 3, communication: 3 }, "Legal Research|Contract Basics|Court Procedure|Legal Writing|Ethics", "Legal Assistant|Paralegal|Senior Paralegal|Head of Legal Operations", 52000,
    { deg: ["legalstudies", "law", "criminology"], bd: "Bachelor of Arts", cert: "Paralegal Certificate", certProg: true, assoc: true, master: true, job: "Paralegal" }),

  // ================= BUSINESS & FINANCE =================
  D("business", "Business Administration", "mixed", { business: 4, communication: 4, leadership: 3 }, "Management|Operations|Organisational Behaviour|Strategy|Business Law", "Business Assistant|Manager|Senior Manager|Executive Director", 75000,
    { deg: ["business", "accounting", "finance", "economics", "marketing", "hr", "supplychain"], bd: "Bachelor of Business Administration", md: "Master of Business Administration", cert: "Business Management Certificate", certProg: true, assoc: true, master: true, feeds: "any", job: "Business Manager" }),
  D("accounting", "Accounting", "mixed", { mathematics: 4, business: 3, finance: 2 }, "Financial Accounting|Management Accounting|Auditing|Taxation|Business Law", "Bookkeeper|Accountant|Senior Accountant|Chief Financial Officer", 76000,
    { deg: ["accounting", "finance", "economics"], bd: "Bachelor of Business Administration", cert: "Bookkeeping Certificate", certProg: true, certRung: 0, assoc: true, master: true }),
  D("finance", "Finance", "degree", { mathematics: 5, business: 3, finance: 3 }, "Corporate Finance|Investments|Markets|Risk Management|Financial Modelling", "Junior Analyst|Financial Analyst|Senior Analyst|Chief Investment Officer", 92000,
    { deg: ["finance", "economics", "accounting", "mathematics"], bd: "Bachelor of Business Administration", master: true, entry: true, job: "Financial Analyst" }),
  D("economics", "Economics", "degree", { mathematics: 5, logic: 4, literature: 2 }, "Microeconomics|Macroeconomics|Econometrics|Public Policy|Game Theory", "Research Assistant|Economist|Senior Economist|Chief Economist", 80000,
    { deg: ["economics", "mathematics", "finance"], bd: "Bachelor of Science", master: true, phd: true }),
  D("marketing", "Marketing", "mixed", { communication: 4, creativity: 4, business: 3 }, "Consumer Behaviour|Brand Strategy|Digital Marketing|Market Research|Copywriting", "Marketing Assistant|Marketing Specialist|Brand Manager|Chief Marketing Officer", 60000,
    { deg: ["marketing", "business"], bd: "Bachelor of Business Administration", cert: "Digital Marketing Certificate", certProg: true, master: true, job: "Marketing Specialist" }),
  D("hr", "Human Resources", "mixed", { communication: 4, leadership: 2, business: 2 }, "Employment Law|Recruitment|Training & Development|Compensation|Organisational Psychology", "HR Assistant|HR Specialist|HR Manager|Chief People Officer", 62000,
    { deg: ["hr", "business", "psychology"], bd: "Bachelor of Business Administration", cert: "HR Practitioner Certificate", certProg: true, master: true }),
  D("supplychain", "Supply Chain & Logistics", "mixed", { business: 3, logic: 3, mathematics: 2 }, "Procurement|Warehousing|Transport Planning|Inventory Control|Operations Research", "Logistics Coordinator|Supply Chain Analyst|Logistics Manager|VP of Operations", 66000,
    { deg: ["supplychain", "business", "engineering"], bd: "Bachelor of Business Administration", cert: "Logistics Certificate", certProg: true, master: true }),
  D("realestate", "Real Estate", "mixed", { communication: 4, business: 3 }, "Property Law|Valuation|Sales|Finance|Negotiation", "Leasing Agent|Realtor|Senior Broker|Agency Owner", 62000,
    { deg: ["realestate", "business"], bd: "Bachelor of Business Administration", cert: "Real Estate Licence", certProg: true }),
  D("sales", "Sales", "open", { communication: 3, business: 1 }, "Prospecting|Negotiation|Product Knowledge|Account Management|Closing", "Sales Associate|Account Executive|Sales Manager|VP of Sales", 44000, { minAge: 17 }),
  D("admin", "Office Administration", "mixed", { communication: 2, business: 1 }, "Office Software|Scheduling|Bookkeeping Basics|Business Writing|Customer Handling", "Receptionist|Office Administrator|Office Manager|Operations Director", 36000,
    { deg: ["business", "admin"], cert: "Office Administration Certificate", certProg: true, assoc: true, minAge: 17, nodegree: true }),

  // ================= EDUCATION, HUMANITIES, MEDIA =================
  D("teaching", "Education", "degree", { communication: 4, leadership: 2, teaching: 3 }, "Pedagogy|Child Development|Curriculum Design|Classroom Management|Assessment", "Teaching Assistant|Teacher|Senior Teacher|Principal", 52000,
    { bd: "Bachelor of Education", licence: "Teaching Licence", master: true, entry: true, feeds: "any", pgcert: { name: "Teacher Certification", grants: "Teaching Licence" }, altDeg: TEACH_SUBJECTS, job: "Teacher" }),
  D("english", "English", "degree", { literature: 5, communication: 3 }, "Literary Theory|Modern Fiction|Rhetoric|Academic Writing|Poetry", "Editorial Assistant|Editor|Senior Editor|Editorial Director", 42000,
    { deg: ["english", "journalism", "languages"], bd: "Bachelor of Arts", master: true, phd: true, job: "Editor" }),
  D("history", "History & Archaeology", "degree", { literature: 4, logic: 3, communication: 3 }, "Ancient History|Modern History|Archaeology|Research Methods|Historiography", "Archive Assistant|Historian|Senior Historian|Museum Director", 45000,
    { deg: ["history", "philosophy", "politics"], bd: "Bachelor of Arts", master: true, phd: true, entry: true }),
  D("geography", "Geography", "degree", { science: 3, mathematics: 3, communication: 3 }, "Physical Geography|Human Geography|GIS Mapping|Cartography|Urban Planning", "Mapping Technician|Geographer|Senior GIS Analyst|Head of Spatial Planning", 58000,
    { deg: ["geography", "environment"], bd: "Bachelor of Science", master: true, phd: true, entry: true }),
  D("philosophy", "Philosophy", "degree", { logic: 5, literature: 4, communication: 3 }, "Ethics|Logic|Metaphysics|Political Philosophy|Philosophy of Mind", "Research Assistant|Ethics Consultant|Senior Researcher|Professor", 48000,
    { deg: ["philosophy"], bd: "Bachelor of Arts", master: true, phd: true, feeds: "any", nojob: true }),
  D("sociology", "Sociology", "degree", { communication: 4, logic: 3, literature: 3 }, "Social Theory|Research Methods|Inequality|Family & Community|Criminology Basics", "Research Assistant|Social Researcher|Senior Researcher|Director of Research", 52000,
    { deg: ["sociology", "psychology", "socialwork", "politics"], bd: "Bachelor of Arts", master: true, phd: true, entry: true }),
  D("languages", "Languages & Translation", "mixed", { languages: 6, literature: 3, communication: 3 }, "Grammar|Translation Theory|Interpretation|Cultural Studies|Literature", "Junior Translator|Translator|Senior Interpreter|Head of Language Services", 46000,
    { deg: ["languages", "english"], bd: "Bachelor of Arts", cert: "Language Proficiency Certificate", certProg: true, master: true, job: "Translator" }),
  D("journalism", "Journalism", "degree", { literature: 4, communication: 5, logic: 2 }, "Reporting|Media Law|Investigative Methods|Broadcasting|Ethics", "Junior Reporter|Reporter|Senior Correspondent|Editor-in-Chief", 48000,
    { deg: ["journalism", "english", "politics", "film"], bd: "Bachelor of Arts", master: true, entry: true }),
  D("writer", "Writing", "talent", { literature: 6, creativity: 5, writing: 3 }, "Narrative Craft|Voice|Editing|Publishing|Genre Studies", "Freelance Writer|Published Author|Bestselling Author|Literary Icon", 36000,
    { deg: ["english", "journalism", "writer"], bd: "Bachelor of Fine Arts", master: true, school: "university", job: "Author" }),

  // ================= ARTS =================
  D("design", "Art & Design", "mixed", { art: 5, creativity: 5 }, "Drawing|Colour Theory|Typography|Digital Media|Portfolio", "Junior Designer|Designer|Art Director|Creative Director", 55000,
    { deg: ["design", "fashion", "architecture"], bd: "Bachelor of Fine Arts", cert: "Design Portfolio Certificate", certProg: true, master: true, job: "Graphic Designer" }),
  D("fashion", "Fashion Design", "mixed", { creativity: 5, art: 4, fashion: 3 }, "Pattern Making|Textiles|Fashion History|Draping|Branding", "Studio Assistant|Fashion Designer|Senior Designer|Creative Head", 54000,
    { deg: ["fashion", "design"], bd: "Bachelor of Fine Arts", cert: "Pattern Making Certificate", certProg: true }),
  D("music", "Music", "talent", { music: 6, creativity: 4 }, "Theory|Performance|Composition|Ear Training|Music Production", "Session Musician|Professional Musician|Lead Artist|Headliner", 38000,
    { deg: ["music"], bd: "Bachelor of Music", cert: "Music Performance Diploma", certProg: true, master: true, job: "Professional Musician" }),
  D("film", "Film & Media", "talent", { creativity: 5, communication: 4, art: 3 }, "Cinematography|Screenwriting|Editing|Media Theory|Directing", "Production Assistant|Editor|Director|Executive Producer", 52000,
    { deg: ["film", "journalism", "design"], bd: "Bachelor of Fine Arts", cert: "Film Production Certificate", certProg: true, master: true, job: "Film Editor" }),
  D("acting", "Performing Arts", "talent", { communication: 4, creativity: 4, dance: 2 }, "Acting Technique|Voice|Movement|Stagecraft|Script Analysis", "Extra|Working Actor|Lead Actor|Star", 36000,
    { deg: ["acting"], bd: "Bachelor of Fine Arts", cert: "Acting Conservatory Diploma", certProg: true, job: "Actor" }),
  D("photography", "Photography", "talent", { photography: 4, art: 3 }, "Camera Craft|Lighting|Editing|Portrait Work|Photojournalism", "Assistant Photographer|Photographer|Senior Photographer|Studio Owner", 40000,
    { deg: ["photography", "film", "design"], bd: "Bachelor of Fine Arts", cert: "Photography Certificate", certProg: true, job: "Photographer" }),

  // ================= SERVICE, SPORT, OTHER =================
  D("hospitality", "Hospitality & Tourism", "mixed", { communication: 4, languages: 3, business: 2 }, "Guest Relations|Events|Tourism Geography|Revenue Management|Service Design", "Front Desk Agent|Supervisor|Hotel Manager|Regional Director", 40000,
    { deg: ["hospitality", "business"], bd: "Bachelor of Arts", cert: "Hospitality Service Certificate", certProg: true, assoc: true }),
  D("retail", "Retail & Service", "open", { communication: 1 }, "Customer Service|Cash Handling|Stock|Teamwork|Product Knowledge", "Associate|Shift Lead|Store Manager|Regional Manager", 26000, { minAge: 14, job: "Retail Associate" }),
  D("callcentre", "Customer Service", "open", { communication: 2 }, "Phone Etiquette|CRM Software|Complaint Handling|Product Knowledge|Teamwork", "Customer Service Rep|Senior Rep|Team Leader|Contact Centre Manager", 30000, { minAge: 17 }),
  D("cleaning", "Cleaning & Facilities", "open", {}, "Safety|Cleaning Methods|Equipment|Scheduling|Teamwork", "Cleaner|Team Leader|Supervisor|Facilities Manager", 24000, { minAge: 15, job: "Cleaner" }),
  D("warehouse", "Warehouse & Stock", "open", { logic: 1 }, "Picking & Packing|Forklift Safety|Inventory|Teamwork|Shipping", "Warehouse Associate|Forklift Operator|Shift Supervisor|Warehouse Manager", 31000, { minAge: 16 }),
  D("delivery", "Driving & Logistics", "open", { logic: 1 }, "Road Safety|Navigation|Logistics|Customer Handling|Vehicle Care", "Driver|Senior Driver|Dispatch Lead|Fleet Manager", 32000, { minAge: 18, job: "Delivery Driver" }),
  D("sportsci", "Sports Science", "mixed", { science: 4, communication: 3, athletics: 3 }, "Biomechanics|Nutrition|Coaching|Exercise Physiology|Sports Psychology", "Gym Instructor|Coach|Head Coach|Director of Performance", 50000,
    { deg: ["sportsci", "physio", "biology"], bd: "Bachelor of Science", cert: "Personal Trainer Certificate", certProg: true, master: true, job: "Sports Coach" }),
  D("streamer", "Streaming & Esports", "talent", { gaming: 6, communication: 3, creativity: 2 }, "Game Mastery|Audience Building|Production|Branding|Teamplay", "Hobby Streamer|Partnered Streamer|Pro Player|Esports Star", 30000, { minAge: 14, nodegree: true }),
  D("chess", "Chess", "talent", { chess: 4, logic: 5 }, "Openings|Endgames|Tactics|Strategy|Psychology", "Club Player|Titled Player|Chess Master|Grandmaster", 28000, { minAge: 10, nodegree: true, job: "Professional Chess Player" }),
];

// ---- derived views ----
export const DOMAIN_BY_KEY = Object.fromEntries(DOMAINS.map((d) => [d.key, d]));
// Domains that are not really a "degree" (no degree programme at all)
export const hasDegree = (d) => !d.nodegree && d.path !== "open" && d.path !== "trade";

// ---- hobbies, clubs and lessons ----
const A = (key, name, kind, gains, stats, cost, minAge, o = {}) => ({ key, name, kind, gains, stats, cost, minAge, ...o });
export const ACTIVITY_LEX = [
  A("guitar", "Guitar lessons", "music", { music: .5, creativity: .1 }, { happiness: 3 }, 600, 6),
  A("piano", "Piano lessons", "music", { music: .55, logic: .1 }, { happiness: 2, smarts: 1 }, 700, 5),
  A("violin", "Violin lessons", "music", { music: .55, logic: .1 }, { happiness: 2, smarts: 1 }, 700, 5),
  A("drumming", "Drum lessons", "music", { music: .5 }, { happiness: 3, fitness: 1 }, 550, 7),
  A("choir", "Community choir", "music", { music: .35, communication: .15 }, { happiness: 4 }, 120, 6),
  A("band", "Garage band", "music", { music: .45, creativity: .25 }, { happiness: 4, reputation: 1 }, 300, 12, { skillReq: { music: 2 } }),
  A("orchestra", "Youth orchestra", "music", { music: .5, leadership: .1 }, { happiness: 3, reputation: 1 }, 250, 8, { skillReq: { music: 2 } }),
  A("painting", "Art studio class", "art", { art: .5, creativity: .25 }, { happiness: 3, stress: -2 }, 500, 5),
  A("pottery", "Pottery workshop", "art", { art: .35, creativity: .3 }, { happiness: 3, stress: -4 }, 380, 8),
  A("photo", "Photography club", "club", { photography: .45, art: .2 }, { happiness: 3 }, 250, 10),
  A("dance", "Dance studio", "art", { dance: .5, creativity: .2 }, { fitness: 3, happiness: 3 }, 650, 4),
  A("gaming", "Gaming league", "gaming", { gaming: .55, logic: .1 }, { happiness: 3, fitness: -1 }, 150, 7),
  A("chessclub", "Chess club", "club", { chess: .5, logic: .25 }, { smarts: 1, stress: -1 }, 60, 6),
  A("debate", "Debate society", "club", { communication: .45, logic: .25, leadership: .15 }, { reputation: 1 }, 80, 11),
  A("coding", "Coding club", "club", { programming: .5, logic: .2 }, { smarts: 1 }, 100, 10),
  A("robotics", "Robotics team", "club", { programming: .3, engineering: .3, logic: .2 }, { smarts: 1, happiness: 2 }, 220, 11),
  A("science", "Science club", "club", { science: .45, logic: .2 }, { smarts: 1 }, 70, 9),
  A("mathclub", "Maths olympiad circle", "club", { mathematics: .5, logic: .25 }, { smarts: 2, stress: 1 }, 40, 10),
  A("drama", "Drama troupe", "art", { communication: .3, creativity: .3 }, { happiness: 3 }, 150, 8),
  A("improv", "Improv comedy group", "art", { communication: .35, creativity: .35 }, { happiness: 4 }, 90, 14),
  A("bookclub", "Book club", "club", { literature: .4, communication: .1 }, { smarts: 1, stress: -2 }, 20, 8),
  A("writers", "Writers' circle", "club", { writing: .4, literature: .25 }, { happiness: 2 }, 40, 12),
  A("cooking", "Cooking class", "hobby", { cooking: .5 }, { happiness: 2 }, 300, 8),
  A("baking", "Baking club", "hobby", { cooking: .45, creativity: .1 }, { happiness: 3 }, 160, 8),
  A("volunteer", "Community volunteering", "volunteering", { leadership: .25, communication: .2 }, { reputation: 3, happiness: 3 }, 0, 10),
  A("firstaid", "First-aid volunteers", "volunteering", { medicine: .3, communication: .15 }, { reputation: 2, happiness: 2 }, 30, 14),
  A("animalshelter", "Animal shelter helper", "volunteering", { agriculture: .1, communication: .1 }, { happiness: 5, stress: -3 }, 0, 9),
  A("scouts", "Scouts troop", "club", { leadership: .3, cooking: .1 }, { fitness: 2, happiness: 2 }, 80, 7, { maxAge: 17 }),
  A("studentcouncil", "Student council", "club", { leadership: .4, communication: .2 }, { reputation: 3 }, 0, 12, { maxAge: 18 }),
  A("yoga", "Yoga & mindfulness", "wellness", {}, { stress: -6, health: 2, fitness: 2 }, 400, 10),
  A("hiking", "Hiking group", "outdoors", {}, { fitness: 4, happiness: 3, stress: -3 }, 120, 8),
  A("cycling", "Cycling club", "outdoors", { athletics: .1 }, { fitness: 4, happiness: 2 }, 220, 8),
  A("climbing", "Climbing gym", "outdoors", { athletics: .15 }, { fitness: 5, stress: -2 }, 380, 9),
  A("fishing", "Fishing society", "outdoors", {}, { happiness: 3, stress: -6 }, 140, 8),
  A("gardening", "Community garden", "hobby", { agriculture: .3 }, { happiness: 2, stress: -3 }, 60, 8),
  A("woodwork", "Woodworking workshop", "hobby", { woodworking: .45, creativity: .1 }, { happiness: 2 }, 350, 12),
  A("sewing", "Sewing & fashion circle", "hobby", { fashion: .4, creativity: .2 }, { happiness: 2 }, 160, 10),
  A("language", "Language exchange meetup", "club", { languages: .5, communication: .15 }, { happiness: 1 }, 90, 10),
  A("martial", "Martial arts dojo", "sport", { boxing: .25 }, { fitness: 4, stress: -2 }, 500, 6),
  A("gym", "Gym membership", "wellness", {}, { fitness: 5, looks: 1, stress: -2 }, 450, 14),
  A("swimclub", "Swim lessons", "sport", { swimming: .4 }, { fitness: 3, happiness: 2 }, 280, 4),
  A("entrepreneur", "Young entrepreneurs club", "club", { business: .4, leadership: .2 }, { reputation: 1 }, 100, 13),
  A("investclub", "Investment club", "club", { finance: .35, business: .2 }, { smarts: 1 }, 120, 16),
  A("tutoring", "After-school tutoring", "club", { mathematics: .25, literature: .25, science: .25 }, { smarts: 2, stress: 2 }, 400, 7, { maxAge: 18 }),
  A("seniorclub", "Seniors' social club", "club", { communication: .15 }, { happiness: 5, stress: -3 }, 50, 60),
  A("birdwatch", "Birdwatching society", "outdoors", { science: .1 }, { happiness: 3, stress: -4 }, 40, 12),
  A("trivia", "Pub quiz team", "club", { logic: .15, literature: .1 }, { happiness: 3 }, 60, 18),
];
