export const rnd = () => Math.random();
export const int = (a, b) => Math.floor(a + Math.random() * (b - a + 1));
export const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
export const chance = (p) => Math.random() < p;
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const gauss = (m = 0, sd = 1) => {
  let u = 0, v = 0;
  while (!u) u = Math.random();
  while (!v) v = Math.random();
  return m + sd * Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
};
export const wpick = (items, wf = (x) => x.w ?? 1) => {
  const ws = items.map((x) => Math.max(0, wf(x)));
  let t = ws.reduce((a, b) => a + b, 0);
  if (t <= 0) return items[Math.floor(Math.random() * items.length)];
  let r = Math.random() * t;
  for (let i = 0; i < items.length; i++) { r -= ws[i]; if (r <= 0) return items[i]; }
  return items[items.length - 1];
};
export const shuffle = (a) => { const b = [...a]; for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [b[i], b[j]] = [b[j], b[i]]; } return b; };
export const uid = (p = "x") => p + Math.random().toString(36).slice(2, 9);
export const hash = (s) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); };
export const round1 = (n) => Math.round(n * 10) / 10;
export const cap = (s) => s.replace(/\b\w/g, (c) => c.toUpperCase());
