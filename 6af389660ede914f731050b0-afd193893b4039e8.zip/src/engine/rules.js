import { BASE_SKILLS, STAT_IDS, statLvl, skillLvl, EDU_LEVELS, EDU_WORD, countryOf, fmtMoney } from "./data.js";
import { clamp, round1 } from "./rng.js";
import { DOMAIN_BY_KEY } from "./lexicon.js";

// ---------- Skills ----------
export const registry = { skills: [...BASE_SKILLS] };
export const skillById = (id) => registry.skills.find((s) => s.id === id);
export const skillName = (id) => skillById(id)?.name || id;

// ---------- Degrees ----------
// A field key like "cs" becomes its readable name. Never shows a raw key.
export const fieldLabel = (key) => DOMAIN_BY_KEY[key]?.name || (key ? String(key).replace(/[_-]+/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()) : "");
export const joinList = (arr) => (arr.length <= 1 ? arr.join("") : arr.slice(0, -1).join(", ") + " or " + arr[arr.length - 1]);
// Exact match only: you hold a qualification of at least `minLevel` in one of the listed fields.
export const hasDegreeIn = (state, fields, minLevel = 3) => state.edu.done.some((d) => d.level >= minLevel && fields.includes(d.field));
export const hasAnyBachelor = (state) => state.edu.done.some((d) => d.level >= 4);
export function gpaAt(state, level) {
  if (level <= 2) { const hs = state.edu.done.find((d) => d.id === "hs"); return hs?.gpa ?? state.edu.schoolGpa ?? 0; }
  const best = state.edu.done.filter((d) => d.level >= level && d.gpa != null).sort((a, b) => b.gpa - a.gpa)[0];
  return best ? best.gpa : 0;
}

export function resolveMinAge(item, country) {
  const c = countryOf(country);
  const r = item.ageRule;
  let a = item.minAge ?? 0;
  if (r === "uni") a = Math.max(a, c.secEnd - (item.level === 3 ? 2 : 0));
  else if (r === "work") a = Math.max(a, c.workAge);
  else if (r === "school") a = Math.max(a, 3);
  return a;
}

// ---------- Requirement checking ----------
// Requirement keys: minAge maxAge edu degrees anyBachelor gpa certs skills stats cash exp anyOf
export function checkReq(state, req, ctx = {}) {
  const items = [];
  const country = state.country;
  const add = (label, ok, have, need) => items.push({ label, ok, have, need });
  if (!req) return { ok: true, items };
  if (req.minAge != null) add(`Age ${req.minAge}+`, state.age >= req.minAge, state.age, req.minAge);
  if (req.maxAge != null) add(`Age under ${req.maxAge + 1}`, state.age <= req.maxAge, state.age, req.maxAge);
  if (req.degrees && req.degrees.length) {
    const lvl = req.edu || 4;
    const names = req.degrees.map(fieldLabel);
    const held = state.edu.done.filter((d) => d.level >= lvl && req.degrees.includes(d.field));
    add(`${EDU_LEVELS[lvl] === "Doctorate" ? "Doctorate" : EDU_LEVELS[lvl]} in ${joinList(names)}`, held.length > 0, state.edu.done.filter((d) => d.level >= lvl).map((d) => d.fieldName || d.name).slice(-2).join(", ") || "none yet", "required");
  } else if (req.anyBachelor) {
    add("Any bachelor degree", hasAnyBachelor(state), state.edu.level >= 4 ? "yes" : "no degree yet", "required");
  } else if (req.edu != null && req.edu > 0) {
    add(EDU_WORD[req.edu] || EDU_LEVELS[req.edu], state.edu.level >= req.edu, state.edu.level > 0 ? EDU_LEVELS[state.edu.level] : "No qualification yet", EDU_LEVELS[req.edu]);
  }
  if (req.gpa != null) { const have = gpaAt(state, req.gpaLevel ?? (req.degrees || req.anyBachelor ? 4 : 2)); add(`GPA ${req.gpa.toFixed(1)}+`, have >= req.gpa - 1e-9, have ? have.toFixed(2) : "none", req.gpa.toFixed(1)); }
  for (const c of req.certs || []) add(c, state.edu.certs.includes(c), state.edu.certs.includes(c) ? "yes" : "no", "yes");
  for (const [id, lv] of Object.entries(req.skills || {})) add(`${skillName(id)} Lv ${Math.ceil(lv)}`, (state.skills[id] || 0) >= lv - 0.001, skillLvl(state.skills[id]), Math.ceil(lv));
  for (const [id, v] of Object.entries(req.stats || {})) add(`${id[0].toUpperCase() + id.slice(1)} Lv ${Math.ceil(v / 10)}`, state.stats[id] >= v, statLvl(state.stats[id]), Math.ceil(v / 10));
  if (req.cash) add(`Cost ${fmtMoney(req.cash * (ctx.col ?? 1), country)}`, state.money.cash >= req.cash * (ctx.col ?? 1), fmtMoney(state.money.cash, country), fmtMoney(req.cash, country));
  if (req.exp) { const have = state.expByField[req.exp.field] || 0; add(`${req.exp.years}+ yrs experience`, have >= req.exp.years, have, req.exp.years); }
  if (req.anyOf) {
    const subs = req.anyOf.map((r) => checkReq(state, r, ctx));
    const ok = subs.some((s) => s.ok);
    const best = subs.sort((a, b) => b.items.filter((i) => i.ok).length - a.items.filter((i) => i.ok).length)[0];
    items.push(...(ok ? [{ label: "One qualification route met", ok: true }] : best.items.map((i) => ({ ...i, label: "Route: " + i.label }))));
  }
  return { ok: items.every((i) => i.ok), items };
}

// ---------- Consequence validation & application ----------
const CAPS = { stat: 25, skill: 1.5, rel: 30 };
export function validateConsequence(c, state) {
  const warnings = [], clean = {};
  if (!c) return { clean, warnings };
  const known = ["stats", "skills", "money", "rel", "newNpc", "condition", "cure", "flags", "followup", "perf", "gpa", "prison", "memory", "tag", "sportXp", "job", "edu", "set", "startBusiness", "quitJob", "asset", "sportScout"];
  for (const k of Object.keys(c)) if (!known.includes(k)) warnings.push(`dropped unknown effect "${k}"`);
  if (c.stats) { clean.stats = {}; for (const [k, v] of Object.entries(c.stats)) { if (!STAT_IDS.includes(k) || typeof v !== "number") { warnings.push(`dropped stat ${k}`); continue; } clean.stats[k] = clamp(v, -CAPS.stat, CAPS.stat); } }
  if (c.skills) { clean.skills = {}; for (const [k, v] of Object.entries(c.skills)) { if (!skillById(k) || typeof v !== "number") { warnings.push(`dropped skill ${k}`); continue; } clean.skills[k] = clamp(v, -CAPS.skill, CAPS.skill); } }
  if (typeof c.money === "number") {
    let m = c.money;
    const col = countryOf(state?.country).col;
    if (state) {
      const dependent = state.age < 18 && state.housing?.id === "parents";
      if (dependent) {
        // children don't carry bills or windfalls: parents cover costs, and only small gifts / pocket money can come in
        if (m < 0) m = 0;
        else if (state.age < 6) m = 0;
        else m = Math.min(m, Math.round((state.age < 12 ? 25 : 80) * col));
      } else if (m < 0) {
        m = Math.max(m, -(state.money?.cash || 0));      // an event can take what you have, never push you into surprise debt
      } else {
        const income = state?.job?.salaryUSD || 20000;
        m = Math.min(m, Math.max(1000, income * 3 + (state?.money?.cash || 0)) * 2);
      }
    }
    if (m !== c.money) warnings.push("money change adjusted");
    clean.money = m;
  }
  if (c.rel) clean.rel = c.rel.filter((r) => r && r.target).map((r) => ({ target: String(r.target), affection: clamp(r.affection || 0, -CAPS.rel, CAPS.rel), trust: clamp(r.trust || 0, -CAPS.rel, CAPS.rel), respect: clamp(r.respect || 0, -CAPS.rel, CAPS.rel) }));
  if (c.newNpc) clean.newNpc = c.newNpc;
  if (c.condition?.name) clean.condition = { name: String(c.condition.name).slice(0, 40), sev: clamp(c.condition.sev || 1, 1, 3), chronic: !!c.condition.chronic, ill: c.condition.ill || null };
  if (c.cure) clean.cure = String(c.cure);
  if (c.flags) { clean.flags = {}; for (const [k, v] of Object.entries(c.flags)) if (/^[a-z_0-9]{2,32}$/.test(k)) clean.flags[k] = v; }
  if (c.followup && /^[a-z_0-9]{2,32}$/.test(c.followup.id || "")) clean.followup = { id: c.followup.id, inYears: clamp(Math.round(c.followup.inYears || 1), 1, 15) };
  if (typeof c.perf === "number") clean.perf = clamp(c.perf, -20, 20);
  if (typeof c.gpa === "number") clean.gpa = clamp(c.gpa, -0.5, 0.5);
  if (typeof c.prison === "number") clean.prison = clamp(Math.round(c.prison), 0, 10);
  if (c.memory) clean.memory = String(c.memory).slice(0, 160);
  if (c.tag) clean.tag = String(c.tag).slice(0, 24);
  if (c.job === "fired" || c.job === "promoted") clean.job = c.job;
  if (c.startBusiness) clean.startBusiness = true;
  if (c.quitJob) clean.quitJob = true;
  if (c.sportScout && skillById(c.sportScout)) clean.sportScout = c.sportScout;
  if (c.asset && c.asset.name) clean.asset = { name: String(c.asset.name).slice(0, 30), value: clamp(c.asset.value || 0, 0, 1e7), dep: clamp(c.asset.dep || 0.1, 0, 0.5) };
  if (c.sportXp && typeof c.sportXp === "object") { clean.sportXp = {}; for (const [k, v] of Object.entries(c.sportXp)) if (skillById(k)) clean.sportXp[k] = clamp(v, -1, 1.5); }
  return { clean, warnings };
}

export function findNpc(state, target) {
  const live = state.rels.filter((r) => r.alive && r.status !== "estranged");
  const by = (roles) => live.filter((r) => roles.includes(r.role));
  const direct = state.rels.find((r) => r.id === target);
  if (direct) return direct;
  const map = { partner: ["partner", "spouse"], mother: ["mother"], father: ["father"], parent: ["mother", "father"], sibling: ["sibling"], friend: ["friend", "classmate"], coworker: ["coworker"], child: ["child"], any: null };
  const roles = map[target];
  const list = roles === undefined ? [] : roles === null ? live : by(roles);
  return list.length ? list[Math.floor(Math.random() * list.length)] : null;
}

const sgn = (n, d = 0) => (n >= 0 ? "+" : "") + (d ? n.toFixed(d) : Math.round(n));
export function applyConsequence(state, c, log = {}) {
  const lines = [];
  if (!c) return lines;
  for (const [k, v] of Object.entries(c.stats || {})) {
    const before = state.stats[k]; state.stats[k] = clamp(before + v, 0, 100);
    const d = state.stats[k] - before;
    if (Math.abs(d) >= 0.5) lines.push({ text: `${sgn(d)} ${k[0].toUpperCase() + k.slice(1)}`, tone: (k === "stress" ? d < 0 : d > 0) ? "good" : "bad" });
  }
  for (const [k, v] of Object.entries(c.skills || {})) {
    state.skills[k] = clamp((state.skills[k] || 0) + v, 0, 10);
    lines.push({ text: `${sgn(v, 1)} ${skillName(k)}`, tone: v > 0 ? "good" : "bad" });
  }
  for (const [k, v] of Object.entries(c.sportXp || {})) { state.skills[k] = clamp((state.skills[k] || 0) + v, 0, 10); lines.push({ text: `${sgn(v, 1)} ${skillName(k)}`, tone: v > 0 ? "good" : "bad" }); }
  if (typeof c.money === "number" && c.money !== 0) {
    state.money.cash += c.money;
    if (state.money.cash < 0) { state.money.debt += -state.money.cash; state.money.cash = 0; }
    lines.push({ text: `${c.money > 0 ? "+" : "-"}${fmtMoney(Math.abs(c.money), state.country)}`, tone: c.money > 0 ? "good" : "bad" });
  }
  for (const r of c.rel || []) {
    const n = findNpc(state, r.target); if (!n) continue;
    n.affection = clamp(n.affection + r.affection, 0, 100); n.trust = clamp(n.trust + r.trust, 0, 100); n.respect = clamp(n.respect + r.respect, 0, 100);
    const t = r.affection || r.trust || r.respect;
    if (t) lines.push({ text: `${n.name.first}: ${sgn(r.affection || r.trust || r.respect)} ${r.affection ? "affection" : r.trust ? "trust" : "respect"}`, tone: t > 0 ? "good" : "bad" });
  }
  if (c.condition) {
    const ex = state.conditions.find((x) => x.name === c.condition.name);
    if (ex) ex.sev = Math.max(ex.sev, c.condition.sev); else state.conditions.push({ ...c.condition, since: state.age });
    lines.push({ text: `Condition: ${c.condition.name}`, tone: "bad" });
  }
  if (c.cure) { const n = state.conditions.length; state.conditions = state.conditions.filter((x) => x.name !== c.cure); if (state.conditions.length < n) lines.push({ text: `Recovered: ${c.cure}`, tone: "good" }); }
  for (const [k, v] of Object.entries(c.flags || {})) { if (v) state.memory.flags[k] = state.age; else delete state.memory.flags[k]; }
  if (c.followup) state.memory.followups.push({ id: c.followup.id, at: state.age + c.followup.inYears });
  if (c.perf && state.job) { state.job.perf = clamp(state.job.perf + c.perf, 0, 100); lines.push({ text: `${sgn(c.perf)} work performance`, tone: c.perf > 0 ? "good" : "bad" }); }
  if (c.gpa && state.edu.current) { state.edu.current.gpa = round1(clamp(state.edu.current.gpa + c.gpa, 0, 4) * 100) / 100; lines.push({ text: `${sgn(c.gpa, 2)} GPA`, tone: c.gpa > 0 ? "good" : "bad" }); }
  if (c.prison) { state.memory.flags.prison_until = state.age + c.prison; state.prison = c.prison; lines.push({ text: `Sentenced: ${c.prison} yr${c.prison > 1 ? "s" : ""}`, tone: "bad" }); }
  if (c.job === "fired" && state.job) { log.fired = true; }
  if (c.memory) state.memory.key.push({ age: state.age, text: c.memory, tag: c.tag || "life" });
  return lines;
}
