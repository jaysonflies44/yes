import { countryOf, fmtMoney, SPORTS, SPORT_TIERS, STAT_IDS, HOUSING, EDU_LEVELS, statLvl, skillLvl, makeName } from "./data.js";
import { pick, int, chance, gauss, clamp, wpick, uid, round1, cap } from "./rng.js";
import { Catalog } from "./catalog.js";
import { validateConsequence, applyConsequence, checkReq, resolveMinAge, skillName, findNpc, gpaAt } from "./rules.js";
import { makeNpc, mortality, occupationFor, ACADEMIC, heightAt, inheritGenes } from "./char.js";
import { pickYearlyEvents, attachChain } from "./events.js";
import { schoolsFor, scholarshipsFor, ensureLocal } from "./content.js";
import { hooks } from "./evkit.js";
import { ILLNESS_BY_ID, treatmentOptions, treatCondition, illnessOf } from "./health.js";

const col = (s) => countryOf(s.country).col;
const wage = (s) => countryOf(s.country).wage;
const M = (s, v) => fmtMoney(v, s.country);
export const add = (s, text, tone = "info", type = "life") => { s.feed.push({ text, tone, type }); s.log.push({ age: s.age, year: s.year, text, tone, type }); if (s.log.length > 600) s.log.shift(); };
const feedOnly = (s, text, tone = "info") => s.feed.push({ text, tone });

// ---------------- special consequence handlers ----------------
const BIZ_A = ["Golden", "Bright", "Urban", "Nova", "Harbor", "Copper", "Maple", "Atlas"], BIZ_B = ["Bakery", "Studio", "Tech", "Kitchen", "Logistics", "Threads", "Coffee", "Repairs"];
export function addNpc(s, spec) {
  const playerAge = s.age;
  let gender = spec.gender;
  if (!gender) gender = ["partner", "spouse"].includes(spec.role) ? (s.orientation === "gay" ? s.gender : s.orientation === "bi" ? pick(["male", "female"]) : s.gender === "male" ? "female" : "male") : pick(["male", "female"]);
  let age = Math.max(0, playerAge + (spec.ageRel ?? 0) + int(-1, 1));
  if (["partner", "spouse"].includes(spec.role)) age = Math.max(13, age);
  const n = makeNpc(spec.role, { age, gender, country: s.country, name: spec.name, playerPers: s.personality, met: playerAge, tier: s.family.tier });
  if (spec.role === "classmate" || spec.role === "friend") n.affection = int(35, 55);
  s.rels.push(n);
  add(s, `You met ${n.name.first} ${n.name.last} (${n.role}).`, "good", "relationship");
  return n;
}
function specials(s, c, lines) {
  if (c.newNpc) addNpc(s, c.newNpc);
  if (c.asset) { s.assets.push({ id: uid("as_"), ...c.asset, bought: s.age }); lines.push({ text: `Acquired ${c.asset.name}`, tone: "good" }); }
  if (c.startBusiness) {
    if (!s.business) { const inv = Math.round(5000 * col(s)); s.business = { name: `${pick(BIZ_A)} ${pick(BIZ_B)}`, invested: inv, years: 0, last: 0, total: 0 }; add(s, `You founded ${s.business.name}.`, "good", "finance"); lines.push({ text: `Founded ${s.business.name}`, tone: "good" }); }
  }
  if (c.quitJob && s.job) { endJob(s, "quit"); lines.push({ text: "You quit your job", tone: "info" }); }
  if (c.job === "fired" && s.job) { endJob(s, "fired"); lines.push({ text: "You lost your job", tone: "bad" }); }
  if (c.sportScout) s.memory.flags["scouted_" + c.sportScout] = s.age;
}
export function applyFull(s, cons) {
  const { clean } = validateConsequence(cons, s);
  const lines = applyConsequence(s, clean, {});
  specials(s, clean, lines);
  return lines;
}

// ---------------- paying for things (children are supported by their parents) ----------------
export const parentsLive = (s) => s.age < 18 && s.housing.id === "parents" && s.rels.some((r) => ["mother", "father"].includes(r.role) && r.alive);
const parentBudget = (s) => [120, 500, 2000, 8000, 40000][s.family.tier] * col(s);
// Returns {ok, by:"self"|"parents"|"free"} or {ok:false, refused|short}. Takes the money when `self` pays.
export function payFor(s, usd, { essential = false } = {}) {
  if (!(usd > 0)) return { ok: true, by: "free" };
  if (parentsLive(s) && (s.age < 14 || s.money.cash < usd)) {
    const par = s.rels.filter((r) => ["mother", "father"].includes(r.role) && r.alive);
    const aff = par.reduce((a, r) => a + r.affection, 0) / par.length;
    let p = 0.97 * Math.min(1, Math.pow(parentBudget(s) / usd, 0.6)) + (aff - 60) / 400;
    if (essential) p = Math.max(p, s.healthSystem === "universal" ? 0.99 : [0.6, 0.82, 0.95, 0.99, 0.99][s.family.tier]);
    if (chance(clamp(p, 0.05, 0.99))) return { ok: true, by: "parents" };
    return { ok: false, by: "parents", refused: true };
  }
  if (s.money.cash >= usd) { s.money.cash -= usd; return { ok: true, by: "self" }; }
  return { ok: false, by: "self", short: true };
}
export const canAskParents = (s) => parentsLive(s) && (s.age < 14 || true);

// ---------------- events ----------------
export function startEventCost(s, choice) { return choice.cost || 0; }
// An event the player cannot act on is dropped, with a note in the life log.
export function skipEvent(s, ev, why) { s.pending = s.pending.filter((e) => e.id !== ev.id); add(s, `${ev.title}: ${why}`, "info", "event"); }
export function resolveChoice(s, ev, idx) {
  const choice = ev.choices[idx];
  if (!choice) return { error: "no such choice" };
  const cost = choice.cost || 0;
  if (choice.requirements) { const r = checkReq(s, choice.requirements); if (!r.ok) return { error: "req", items: r.items }; }
  const lines = [];
  if (cost) {
    const paid = payFor(s, cost, { essential: !!choice.essential });
    if (!paid.ok && paid.refused) {
      const text = pick(["Your parents say it's too expensive right now.", "\"Not this time, sweetheart,\" your parents say.", "Your parents shake their heads. Money is tight."]);
      add(s, `${ev.title}: ${text}`, "info", "event");
      return { text, lines: [{ text: "Parents said no", tone: "bad" }], label: choice.label, declined: true };
    }
    if (!paid.ok) return { error: "afford", need: cost };
    if (paid.by === "parents") lines.push({ text: "Parents paid", tone: "good" }); else lines.push({ text: `-${M(s, cost)}`, tone: "bad" });
  }
  const out = wpick(choice.outcomes, (o) => o.weight);
  lines.push(...applyFull(s, out.consequences));
  add(s, `${ev.title}: ${out.text}`, lines.some((l) => l.tone === "bad") && !lines.some((l) => l.tone === "good") ? "bad" : lines.some((l) => l.tone === "good") ? "good" : "info", ev.category === "prompt" ? "prompt" : "event");
  const res = { text: out.text, lines, label: choice.label };
  if (ev.chain && Math.random() < 0.9) res.next = attachChain(ev, s);
  return res;
}

// ---- special event windows: doctor, job offer, university application ----
export function resolveSpecial(s, ev, p) {
  if (ev.ui === "doctor") return resolveDoctor(s, ev, p);
  if (ev.ui === "job_offer") return resolveOffer(s, ev, p);
  if (ev.ui === "university") return resolveUniversity(s, ev, p);
  return { error: "unknown" };
}
export function addCondition(s, ill) {
  let c = s.conditions.find((x) => x.name === ill.name);
  if (!c) { c = { name: ill.name, sev: ill.sev, chronic: !!ill.chronic, since: s.age, ill: ill.id }; s.conditions.push(c); }
  (s.memory.had || (s.memory.had = {}))[ill.id] = s.age;
  s.stats.health = clamp(s.stats.health - ill.sev * 5, 1, 100);
  return c;
}
export function treatNamed(s, name, optId) {
  const cond = s.conditions.find((c) => c.name === name); if (!cond) return { error: "gone" };
  const r = treatCondition(s, cond, optId, payFor);
  if (r.error) return r;
  r.lines = r.lines.map((l) => (l.money ? { ...l, text: `-${M(s, l.money)}` } : l));
  add(s, `${cond.name}: ${r.text}`, r.cured ? "good" : "info", "health");
  return r;
}
function resolveDoctor(s, ev, { opt }) {
  const ill = ILLNESS_BY_ID[ev.ill]; if (!ill) return { error: "unknown" };
  const cond = addCondition(s, ill);
  if (opt == null) return { error: "none" };
  let r = treatCondition(s, cond, opt, payFor);
  if (r.error === "afford") return { error: "afford", need: r.need };
  if (r.error && r.error !== "parents") r = treatCondition(s, cond, "rest", payFor);
  r.lines = (r.lines || []).map((l) => (l.money ? { ...l, text: `-${M(s, l.money)}` } : l));
  if (r.error === "parents") { const rr = treatCondition(s, cond, "rest", payFor); return { text: `Your parents say they can't afford that right now. ${rr.text}`, lines: [{ text: "Parents said no", tone: "bad" }, ...(rr.lines || [])], label: "Ask parents", declined: true }; }
  add(s, `${ev.title}: ${r.text}`, r.cured ? "good" : "info", "health");
  return { text: r.text, lines: r.lines, label: r.opt.label };
}
function resolveOffer(s, ev, { accept }) {
  const o = ev.offer;
  if (!accept) { add(s, `You turned down the ${o.title} job at ${o.company}.`, "info", "career"); return { text: `You politely declined the offer from ${o.company}.`, lines: [], label: "Decline" }; }
  const job = Catalog.get(o.jobId); if (!job) return { error: "unknown" };
  if (s.job) endJob(s, "left");
  s.job = { id: job.id, name: job.name, field: job.field, rung: o.rung, title: o.title, years: 0, yearsInRole: 0, salaryUSD: o.salaryUSD, perf: 55, hours: o.hours, mode: "normal", since: s.age, partTime: o.partTime, company: o.company };
  add(s, `You accepted a job as ${o.title} at ${o.company} (${M(s, o.salaryUSD)}/yr).`, "good", "career");
  return { text: `Welcome aboard! You start as ${o.title} at ${o.company}.`, lines: [{ text: `New salary ${M(s, o.salaryUSD)}`, tone: "good" }], label: "Accept" };
}
function resolveUniversity(s, ev, p) {
  if (p.skip) { add(s, "You decided not to apply to university right now.", "info", "education"); return { text: "You're putting further study on hold. You can apply any time from the Education tab, as long as you qualify.", lines: [], label: "Not now" }; }
  const r = applyToProgramme(s, p.eduId, p.instId, p.schId);
  if (r.error) return r;
  if (r.rejected) return { text: r.text, lines: [{ text: "Not accepted", tone: "bad" }], label: "Applied", rejected: true, keepOpen: true };
  return { text: r.text, lines: [{ text: "Accepted!", tone: "good" }], label: "Applied", accepted: true };
}

// ---------------- quick actions (predefined base activities) ----------------
export const PRACTICE = ["programming", "music", "art", "business", "leadership", "gaming", "writing", "photography", "languages", "trades", "finance", "chess"];
export const QUICK = [
  { id: "study", label: "Study", desc: "Boost one academic skill", max: 2, minAge: 6, pick: ACADEMIC, apply: (s, sk) => ({ sk: { [sk]: 0.3 }, sm: 0.6, st: 3 }) },
  { id: "exercise", label: "Exercise", desc: "Fitness up, stress down", max: 3, minAge: 5, apply: () => ({ ft: 3, hp: 1, st: -3 }) },
  { id: "socialize", label: "Hang out", desc: "See friends", max: 3, minAge: 3, apply: () => ({ h: 4, st: -3, rel: [["friend", 4, 2]] }) },
  { id: "relax", label: "Relax", desc: "Recharge", max: 3, minAge: 1, apply: () => ({ st: -9, h: 2 }) },
  { id: "read", label: "Read", desc: "Literature & smarts", max: 2, minAge: 4, apply: () => ({ sk: { literature: 0.25 }, sm: 0.5, st: -2 }) },
  { id: "overtime", label: "Work extra", desc: "Performance up, stress up", max: 2, minAge: 16, needJob: true, apply: () => ({ perf: 4, st: 4, m: 0 }) },
  { id: "meditate", label: "Meditate", desc: "Calm the mind", max: 2, minAge: 8, apply: () => ({ st: -7, h: 1 }) },
  { id: "cook", label: "Cook", desc: "Cooking skill", max: 2, minAge: 8, apply: () => ({ sk: { cooking: 0.3 }, h: 1, hp: 0.5 }) },
  { id: "practise", label: "Practise a skill", desc: "Train a hobby or work skill", max: 2, minAge: 8, pick: PRACTICE, apply: (s, sk) => ({ sk: { [sk]: 0.3 }, st: 2 }) },
];
export function doQuick(s, id, arg) {
  const q = QUICK.find((x) => x.id === id);
  if (s.age < q.minAge) return { error: `Available from age ${q.minAge}.` };
  if (q.needJob && !s.job) return { error: "You need a job for that." };
  const used = s.quick[id] || 0;
  if (used >= q.max) return { error: `You've done this enough this year (${q.max}x).` };
  s.quick[id] = used + 1;
  const lines = applyFull(s, q.apply(s, q.pick?.includes(arg) ? arg : q.pick?.[0]));
  return { lines, text: q.label };
}

// ---------------- aging / vitals ----------------
function baseline(s) {
  const p = s.personality;
  let b = 55 + (p.extraversion - 50) * 0.2 - (p.neuroticism - 50) * 0.25;
  if (s.money.debt > s.money.cash * 2 + 2000) b -= 5;
  if (s.stats.health < 40) b -= 10;
  const close = s.rels.filter((r) => r.alive && r.affection > 60).length; b += Math.min(8, close * 1.5);
  if (s.rels.some((r) => ["partner", "spouse"].includes(r.role) && r.alive && r.affection > 60)) b += 4;
  return clamp(b, 15, 90);
}
function vitals(s) {
  const st = s.stats, g = s.genes, a = s.age, L = s.lifestyle;
  const hTarget = 92 - Math.max(0, a - 35) * 0.65 + (st.fitness - 50) * 0.18 - Math.max(0, st.stress - 50) * 0.15 + (g.longevity - 50) * 0.1 + (L.diet - 1) * 4 + (L.sleep - 1) * 3 - s.conditions.reduce((x, c) => x + c.sev * 4 * (c.managed ? 0.5 : 1), 0);
  st.health = clamp(st.health + (hTarget - st.health) * 0.28 + gauss(0, 2), 1, 100);
  const fitMax = 55 + g.athletic * 0.45;
  st.fitness = clamp(st.fitness + (a < 25 ? 0.4 : -1.2 - Math.max(0, a - 40) * 0.08) + (L.exercise - 1) * 3 + (st.fitness > fitMax ? -3 : 0), 5, 100);
  st.looks = clamp(st.looks + (a < 20 ? 1.2 : a > 40 ? -0.6 : 0) + (L.diet - 1) * 0.6 + (st.fitness - 50) * 0.01 + gauss(0, 0.8), 5, 100);
  const sTarget = 15 + g.intellect * 0.5 + s.edu.level * 5 + ((s.skills.literature || 0) + (s.skills.logic || 0) + (s.skills.science || 0)) * 1.2;
  st.smarts = clamp(st.smarts + (sTarget - st.smarts) * 0.22 + (a > 60 ? -0.6 : 0), 1, 100);
  st.happiness = clamp(st.happiness + (baseline(s) - st.happiness) * 0.35 + gauss(0, 3), 1, 100);
  st.stress = clamp(st.stress + ((18 + s.personality.neuroticism * 0.25 + (s.job ? 8 : 0) + (s.edu.current ? 8 : 0) + (s.money.debt > 3000 ? 8 : 0)) - st.stress) * 0.35 + gauss(0, 3), 0, 100);
  st.reputation = clamp(st.reputation + (50 - st.reputation) * 0.06, 0, 100);
  s.height = heightAt(g, a);
}
function conditions(s) {
  // Illnesses mostly clear up by themselves, faster when you are young. New illnesses arrive as events (see events.js), never silently.
  const next = [];
  for (const c of s.conditions) {
    if (!c.chronic) {
      const p = (c.sev >= 3 ? 0.15 : c.sev === 2 ? 0.35 : 0.6) + (s.age < 14 ? 0.15 : 0) + (s.stats.health - 50) / 300;
      if (chance(clamp(p, 0.05, 0.9))) { add(s, `You recovered from ${c.name}.`, "good", "health"); continue; }
      s.stats.health = clamp(s.stats.health - c.sev * 1.5, 1, 100);
    } else { s.stats.health = clamp(s.stats.health - c.sev * 1.5 * (c.managed ? 0.35 : 1), 1, 100); }
    next.push(c);
  }
  s.conditions = next;
}
function npcYear(s) {
  for (const n of s.rels) {
    if (!n.alive) continue;
    n.age++;
    if (chance(mortality(n.age) * (n.role === "child" ? 0.3 : 1))) {
      n.alive = false; n.status = "deceased";
      add(s, `${n.name.first} ${n.name.last} (${n.role}) passed away at ${n.age}.`, "bad", "relationship");
      s.stats.happiness = clamp(s.stats.happiness - (n.affection > 60 ? 14 : 5), 0, 100);
      continue;
    }
    // drift
    const decay = ["mother", "father", "child", "spouse", "sibling"].includes(n.role) ? 0.5 : n.role === "partner" ? 1.5 : 3.5;
    n.affection = clamp(n.affection - decay + (n.compat > 65 ? 0.6 : 0), 0, 100);
    n.trust = clamp(n.trust - decay * 0.3, 0, 100);
    if (n.role === "child" && n.age >= 18 && n.occupation === "Student") n.occupation = occupationFor(n.age, s.family.tier);
    // life events
    if (n.age === 6) n.occupation = "Student";
    if (n.age === 18 && n.role !== "child") n.occupation = chance(0.5) ? "University student" : occupationFor(18, n.tier);
    if (n.age >= 22 && ["Student", "University student", "Between jobs"].includes(n.occupation)) { n.occupation = occupationFor(n.age, n.tier ?? 2, 0.02); if (n.occupation !== "Between jobs") feedNpc(s, n, `${n.name.first} started working as a ${n.occupation}.`); }
    if (n.age === 65 && n.occupation !== "Retired") { n.occupation = "Retired"; feedNpc(s, n, `${n.name.first} retired.`); }
    if (chance(0.06) && n.age > 22 && n.age < 65 && n.occupation !== "Retired") {
      const ev = pick([`${n.name.first} got a promotion at work.`, `${n.name.first} moved to a new home.`, `${n.name.first} is training for a marathon.`, `${n.name.first} started a night course.`, `${n.name.first} had a rough month.`, `${n.name.first} took a big holiday.`]);
      feedNpc(s, n, ev);
    }
    if (n.role === "classmate" && s.age >= (countryOf(s.country).secEnd)) { if (chance(0.5)) n.status = "estranged"; else n.role = "friend"; }
    if (n.role === "friend" && n.affection < 8) n.status = "estranged";
  }
  s.rels = s.rels.filter((n) => n.status !== "estranged" || n.affection >= 8 || chance(0.5));
  if (s.rels.length > 55) s.rels = s.rels.filter((n, i) => ["mother", "father", "sibling", "spouse", "partner", "child"].includes(n.role) || n.alive && n.affection > 25 || i > 40);
}
const feedNpc = (s, n, t) => { if (n.affection > 45 || ["mother", "father", "sibling", "child", "spouse", "partner"].includes(n.role)) { feedOnly(s, t, "info"); s.log.push({ age: s.age, year: s.year, text: t, tone: "info", type: "npc" }); } };

function socialLife(s) {
  const ext = s.personality.extraversion / 100;
  const friends = s.rels.filter((r) => r.alive && ["friend", "classmate", "coworker"].includes(r.role)).length;
  if (s.edu.inSchool && s.age >= 5) { const n = chance(0.6 + ext * 0.3) ? int(1, 2) : 0; for (let i = 0; i < n && friends + i < 14; i++) addNpc(s, { role: "classmate", ageRel: 0 }); }
  else if (s.job && chance(0.45) && friends < 14) addNpc(s, { role: "coworker", ageRel: int(-6, 8) });
  else if (s.age >= 18 && chance(0.2 + ext * 0.3) && friends < 10) addNpc(s, { role: "friend", ageRel: int(-4, 4) });
}
// ---------------- school & education ----------------
function school(s) {
  const c = countryOf(s.country), a = s.age;
  const inSchool = a >= c.schoolStart && a < c.secEnd;
  s.edu.inSchool = inSchool;
  if (a >= 3 && a < c.schoolStart) { s.skills.languages = clamp((s.skills.languages || 0) + 0.1, 0, 10); s.skills.communication = clamp((s.skills.communication || 0) + 0.1, 0, 10); }
  if (inSchool) {
    const eff = (0.6 + s.stats.smarts / 120) * (0.7 + s.personality.conscientiousness / 160) * (1 - Math.max(0, s.stats.stress - 70) / 200);
    for (const k of ACADEMIC) s.skills[k] = clamp((s.skills[k] || 0) + 0.34 * (s.genes.apt[k] || 1) * eff, 0, 10);
    s.edu.schoolGpa = round1(clamp(2 + s.stats.smarts / 45 + s.personality.conscientiousness / 120 - s.stats.stress / 160 + gauss(0, 0.2), 0.5, 4) * 100) / 100;
    if (a === c.schoolStart) add(s, `You started school in ${s.city}.`, "info", "education");
    if (a === 11 && s.edu.level < 1) { s.edu.level = 1; s.edu.done.push({ id: "primary", name: "Primary school", field: "general", level: 1, year: s.year, gpa: s.edu.schoolGpa }); add(s, "You finished primary school.", "good", "education"); }
  }
  if (a === c.secEnd && s.edu.level < 2 && a >= c.schoolStart + 8) {
    s.edu.level = 2; s.edu.done.push({ id: "hs", name: "High school diploma", field: "general", level: 2, year: s.year, gpa: s.edu.schoolGpa });
    add(s, `You graduated high school with a ${s.edu.schoolGpa.toFixed(1)} GPA.`, "good", "education"); s.stats.reputation = clamp(s.stats.reputation + 2, 0, 100);
    if (s.edu.level < 1) s.edu.level = 1;
  }
}
export function tuitionFor(s, edu, inst, sch) {
  const base = edu.tuitionUSD * countryOf(s.country).tui * (inst?.tuitionMult ?? 1);
  const cover = (sch?.coverage || 0);
  const fam = edu.level <= 4 ? s.family.support : s.family.support * 0.5;
  return Math.round(base * (1 - cover) * (1 - (s.age < 25 ? fam : 0)));
}
// Full admission check for one programme at one school. Each school type has its own qualification (see content.js).
export function eduEligibility(s, edu, inst) {
  const country = s.country;
  const a = edu.adm || {};
  const minAge = Math.max(resolveMinAge(edu, country), a.minAge || 0);
  const gpaNeed = a.gpa ? clamp(a.gpa + (inst?.gpaOff || 0), 0, 4) : 0;
  const req = { minAge, edu: a.edu || 0, skills: a.skills || {}, stats: a.stats || {} };
  if (a.degrees) req.degrees = a.degrees; else if (a.anyBachelor) req.anyBachelor = true;
  if (gpaNeed > 0) { req.gpa = Math.round(gpaNeed * 10) / 10; req.gpaLevel = a.degrees || a.anyBachelor ? Math.max(4, a.edu || 4) : 2; }
  const res = checkReq(s, req);
  // already hold this exact programme?
  if (s.edu.done.some((d) => d.id === edu.id)) res.items.unshift({ label: "Not already completed", ok: false });
  if (s.edu.current) res.items.unshift({ label: "Not already enrolled", ok: false });
  res.ok = res.items.every((i) => i.ok);
  res.minAge = minAge; res.gpaNeed = req.gpa || 0; res.tuition = tuitionFor(s, edu, inst);
  const have = a.degrees || a.anyBachelor ? gpaAt(s, Math.max(4, a.edu || 4)) : gpaAt(s, 2);
  res.margin = gpaNeed ? have - gpaNeed : 1;
  const selective = ["university", "grad", "medical", "dental", "law", "nursing", "pharmacy", "vet"].includes(inst?.kind || edu.school);
  res.odds = !selective ? 1 : clamp(0.62 + res.margin * 0.45 - ((inst?.rep || 60) - 60) / 200 + (s.stats.smarts - 50) / 400, 0.12, 0.97);
  res.oddsLabel = res.odds >= 0.85 ? "Very likely" : res.odds >= 0.65 ? "Likely" : res.odds >= 0.4 ? "Uncertain" : "Long shot";
  return res;
}
export function enrol(s, edu, inst, sch) {
  const el = eduEligibility(s, edu, inst);
  if (!el.ok) return { error: "not eligible", el };
  s.edu.current = { id: edu.id, name: edu.name, fieldName: edu.fieldName, field: edu.field, level: edu.level, kind: edu.kind, years: edu.years, done: 0, gpa: 3, instId: inst?.id, instName: inst?.name || "Open enrollment", schId: sch?.id, schName: sch?.name, coverage: sch?.coverage || 0, tuition: tuitionFor(s, edu, inst, sch), teaches: edu.teaches || {}, grants: edu.grants || [], gpaReq: edu.gradReq?.minGpa ?? 2, gpaHist: [] };
  add(s, `You enrolled in ${edu.name} at ${inst?.name || "an online provider"}.`, "good", "education");
  return { ok: true };
}
// Apply to a programme. Meeting the requirements is necessary; getting in is then likely, not guaranteed.
export function applyToProgramme(s, eduId, instId, schId) {
  const edu = Catalog.get(eduId); const inst = instId ? Catalog.get(instId) : null;
  if (!edu) return { error: "unknown" };
  const el = eduEligibility(s, edu, inst);
  if (!el.ok) return { error: "not eligible", el };
  const applied = s.edu.applied || (s.edu.applied = {}); const key = `${eduId}|${instId || ""}`;
  if (applied[key] === s.year) return { error: "already applied", message: `You already applied to ${inst?.name || "this programme"} for ${edu.name} this year. You can reapply next year.` };
  applied[key] = s.year;
  const sch = schId ? Catalog.get(schId) : null;
  if (!chance(el.odds)) {
    s.stats.happiness = clamp(s.stats.happiness - 4, 0, 100);
    add(s, `${inst?.name || "The school"} rejected your application for ${edu.name}.`, "bad", "education");
    return { rejected: true, text: `${inst?.name || "The school"} turned you down for ${edu.name}. You can try another school now, or reapply here next year.` };
  }
  const r = enrol(s, edu, inst, sch);
  if (r.error) return r;
  return { accepted: true, text: `You got in! You're now studying ${edu.name} at ${inst?.name || "an online provider"}.` };
}
export function dropOut(s) { if (!s.edu.current) return; add(s, `You dropped out of ${s.edu.current.name}.`, "bad", "education"); s.stats.happiness = clamp(s.stats.happiness - 6, 0, 100); s.edu.current = null; }
function collegeYear(s) {
  const e = s.edu.current; if (!e) return;
  e.done += 1;
  const gpa = clamp(2.1 + s.stats.smarts / 55 + s.personality.conscientiousness / 130 - s.stats.stress / 170 + (s.job ? -0.1 : 0) + gauss(0, 0.28), 0.4, 4);
  e.gpaHist.push(gpa); e.gpa = round1((e.gpaHist.reduce((a, b) => a + b, 0) / e.gpaHist.length) * 100) / 100;
  // the programme teaches its subject: skills climb toward the level the course promises, scaled by how well you study
  const left = Math.max(1, e.years - e.done + 1); const diligence = 0.75 + Math.min(1, e.gpa / 4) * 0.35;
  for (const [k, target] of Object.entries(e.teaches || {})) { const cur = s.skills[k] || 0; if (target > cur) s.skills[k] = clamp(cur + ((target - cur) / left) * diligence + 0.1, 0, 10); }
  if (e.tuition) { s.money.cash -= e.tuition; if (s.money.cash < 0) { s.money.debt += -s.money.cash; s.money.cash = 0; } feedOnly(s, `Tuition paid: ${M(s, e.tuition)}.`, "info"); }
  if (e.schId && e.gpa < 2.8) { add(s, `You lost your scholarship (GPA ${e.gpa}).`, "bad", "education"); e.tuition = Catalog.get(e.id) ? tuitionFor(s, Catalog.get(e.id), Catalog.get(e.instId), null) : e.tuition; e.schId = null; e.coverage = 0; }
  if (e.done >= e.years) {
    if (e.gpa >= e.gpaReq) {
      s.edu.level = Math.max(s.edu.level, e.level);
      s.edu.done.push({ id: e.id, name: e.name, field: e.field, fieldName: e.fieldName, level: e.level, kind: e.kind, year: s.year, gpa: e.gpa, inst: e.instName });
      (e.grants || []).forEach((g) => { if (!s.edu.certs.includes(g)) s.edu.certs.push(g); });
      add(s, `You graduated: ${e.name} (GPA ${e.gpa.toFixed(2)}).`, "good", "education"); s.stats.happiness = clamp(s.stats.happiness + 10, 0, 100); s.stats.reputation = clamp(s.stats.reputation + 4, 0, 100);
      s.edu.current = null;
    } else { e.done = e.years - 1; add(s, `Your GPA (${e.gpa.toFixed(2)}) is below ${e.gpaReq}. You repeat the final year.`, "bad", "education"); }
  } else add(s, `${e.name}: year ${e.done}/${e.years} complete (GPA ${e.gpa.toFixed(2)}).`, "info", "education");
}

// ---------------- careers ----------------
export function jobEligibility(s, job) {
  const minAge = Math.max(job.minAge || 0, resolveMinAge(job, s.country));
  const base = checkReq(s, { minAge, certs: job.requirements.certs });
  const routes = job.pathways.map((p) => ({ p, res: checkReq(s, p.req) }));
  const passing = routes.filter((r) => r.res.ok).sort((a, b) => b.p.rung - a.p.rung);
  const best = passing[0] || routes.sort((a, b) => b.res.items.filter((i) => i.ok).length - a.res.items.filter((i) => i.ok).length)[0];
  const ok = base.ok && passing.length > 0 && !(s.job && s.job.id === job.id) && !s.edu.current?.full;
  const driveBlock = job.field === "delivery" && s.age < countryOf(s.country).driveAge;
  return { ok: ok && !driveBlock, base, routes, best, rung: passing[0]?.p.rung ?? null, minAge, driveBlock };
}
const CO_A = ["Northwind", "Bluepeak", "Harbor & Co", "Summit", "Evergreen", "Crestline", "Ironbridge", "Lumen", "Redwood", "Silverline", "Atlas", "Oakfield", "Pioneer", "Beacon", "Granite"];
const CO_B = { cs: "Software", medicine: "Hospital", nursing: "Health Trust", retail: "Stores", culinary: "Kitchens", delivery: "Logistics", law: "Law Partners", finance: "Capital", teaching: "School", default: "Group" };
export const pickCompany = (s, job) => `${pick(CO_A)} ${CO_B[job.field] || CO_B.default}`;
export function applyForJob(s, job) {
  const el = jobEligibility(s, job);
  if (!el.ok) return { error: "not eligible", el };
  const rung = el.rung ?? 0;
  const topSk = Object.keys(job.requirements.skills || {});
  const sk = topSk.length ? topSk.reduce((a, k) => a + (s.skills[k] || 0), 0) / topSk.length : 3;
  const p = clamp(0.45 + (sk - 3) * 0.04 + (s.stats.reputation - 50) / 250 + (s.personality.extraversion - 50) / 400 + (s.stats.looks - 50) / 500 - (s.stats.stress > 80 ? 0.1 : 0), 0.15, 0.92);
  if (!chance(p)) { s.stats.happiness = clamp(s.stats.happiness - 3, 0, 100); return { rejected: true, chance: p }; }
  if (s.job) endJob(s, "left");
  const r = job.ladder[Math.min(rung, job.ladder.length - 1)];
  const partTime = s.age < 18 && job.field !== "streamer";
  s.job = { id: job.id, name: job.name, field: job.field, rung, title: r.title, years: 0, yearsInRole: 0, salaryUSD: Math.round(r.salaryUSD * wage(s) * (partTime ? 0.35 : 1) * (0.92 + Math.random() * 0.16)), perf: 55, hours: partTime ? 15 : job.hours, mode: "normal", since: s.age, partTime, company: pickCompany(s, job) };
  add(s, `You were hired as ${r.title} (${M(s, s.job.salaryUSD)}/yr).`, "good", "career");
  return { ok: true, title: r.title };
}
// A real offer from the job catalog that this character genuinely qualifies for. Returns null if nothing suitable.
export function makeJobOffer(s, { better = false, partTime = null } = {}) {
  const jobs = Catalog.list("career").filter((j) => !(s.job && s.job.id === j.id));
  const opts = [];
  for (const j of jobs) {
    const el = jobEligibility(s, j); if (!el.ok) continue;
    const rung = Math.min(el.rung ?? 0, j.ladder.length - 1); const r = j.ladder[rung];
    const pt = s.age < 18 && j.field !== "streamer";
    if (partTime != null && pt !== partTime) continue;
    const sal = Math.round(r.salaryUSD * wage(s) * (pt ? 0.35 : 1) * (0.95 + Math.random() * 0.15) / 100) * 100;
    if (better && s.job && sal < s.job.salaryUSD * 1.06) continue;
    const fit = Object.keys(j.requirements.skills || {}).reduce((a, k) => a + (s.skills[k] || 0), 0);
    opts.push({ j, rung, r, sal, pt, w: 1 + fit * 0.2 + (s.job && j.field === s.job.field ? 2 : 0) });
  }
  if (!opts.length) return null;
  const c = wpick(opts, (x) => x.w);
  return { jobId: c.j.id, rung: c.rung, title: c.r.title, company: pickCompany(s, c.j), salaryUSD: c.sal, hours: c.pt ? 15 : c.j.hours, partTime: c.pt, field: c.j.fieldName };
}
export function endJob(s, why) {
  if (!s.job) return;
  s.jobHistory.push({ title: s.job.title, years: s.job.years, field: s.job.field, from: s.job.since, to: s.age, why });
  add(s, why === "fired" ? `You were fired from ${s.job.title}.` : why === "quit" ? `You quit your job as ${s.job.title}.` : why === "retired" ? `You retired from ${s.job.title}.` : `You left your job as ${s.job.title}.`, why === "fired" ? "bad" : "info", "career");
  if (why === "fired") { s.stats.happiness = clamp(s.stats.happiness - 10, 0, 100); s.stats.reputation = clamp(s.stats.reputation - 4, 0, 100); }
  s.job = null;
}
export function promotionStatus(s) {
  const j = s.job; if (!j) return null;
  const job = Catalog.get(j.id); if (!job) return null;
  const next = job.ladder[j.rung + 1]; if (!next) return { top: true };
  const req = { skills: next.reqSkills };
  const sk = checkReq(s, req);
  const items = [{ label: `${next.reqYears}+ yrs in role`, ok: j.yearsInRole >= next.reqYears, have: j.yearsInRole, need: next.reqYears }, { label: `Performance ${next.reqPerf}+`, ok: j.perf >= next.reqPerf, have: Math.round(j.perf), need: next.reqPerf }, ...sk.items];
  return { next, items, ok: items.every((i) => i.ok) };
}
export function askPromotion(s) {
  const ps = promotionStatus(s); if (!ps || ps.top) return { error: "Nothing higher to ask for." };
  if (!ps.ok) return { error: "not ready", ps };
  if (chance(0.55 + (s.job.perf - 60) / 150)) { promote(s, ps.next); return { ok: true }; }
  s.job.perf = clamp(s.job.perf - 3, 0, 100); return { rejected: true };
}
function promote(s, next) { const job = Catalog.get(s.job.id); s.job.rung++; s.job.title = next.title; s.job.yearsInRole = 0; s.job.salaryUSD = Math.round(next.salaryUSD * wage(s) * (s.job.partTime ? 0.35 : 1)); add(s, `Promoted to ${next.title} (${M(s, s.job.salaryUSD)}/yr).`, "good", "career"); s.stats.happiness = clamp(s.stats.happiness + 8, 0, 100); s.stats.reputation = clamp(s.stats.reputation + 3, 0, 100); }
function workYear(s) {
  const j = s.job; if (!j) return 0;
  j.years++; j.yearsInRole++; s.expByField[j.field] = (s.expByField[j.field] || 0) + 1;
  const job = Catalog.get(j.id);
  const sk = job ? Object.keys(job.requirements.skills || {}) : []; const avg = sk.length ? sk.reduce((a, k) => a + (s.skills[k] || 0), 0) / sk.length : 4;
  for (const k of sk) s.skills[k] = clamp((s.skills[k] || 0) + 0.25, 0, 10);
  const eff = { coast: -8, normal: 0, hard: 9 }[j.mode];
  const target = 45 + avg * 3 + (s.personality.conscientiousness - 50) * 0.3 - Math.max(0, s.stats.stress - 55) * 0.4 + eff + gauss(0, 5);
  j.perf = clamp(j.perf + (target - j.perf) * 0.45, 0, 100);
  if (j.mode === "hard") s.stats.stress = clamp(s.stats.stress + 6, 0, 100);
  if (j.mode === "coast") s.stats.stress = clamp(s.stats.stress - 3, 0, 100);
  const gross = j.salaryUSD * (1 + (j.mode === "hard" ? 0.03 : 0)); s.peakSalary = Math.max(s.peakSalary, j.salaryUSD);
  if (job) {
    const ps = promotionStatus(s);
    if (ps && !ps.top && ps.ok && chance(0.55)) promote(s, ps.next);
    else if (ps && !ps.top && j.yearsInRole >= ps.next.reqYears && !ps.ok && chance(0.4)) feedOnly(s, `A promotion to ${ps.next.title} needs: ${ps.items.filter((i) => !i.ok).map((i) => i.label).join(", ")}.`, "warn");
  }
  if (chance(0.025 + (j.perf < 35 ? 0.15 : 0)) && j.yearsInRole > 0 && !j.partTime) { s.job.__fired = true; }
  return gross;
}

// ---------------- sports ----------------
export function sportEligibility(s, opp) {
  const res = checkReq(s, opp.requirements);
  const sp = SPORTS.find((x) => x.id === opp.sport);
  if (opp.tier >= 2) { const prev = s.sport.history.filter((h) => h.sport === opp.sport && h.tier >= opp.tier - 1).length || (s.sport.team && s.sport.team.sport === opp.sport && s.sport.team.tier >= opp.tier - 1 ? 1 : 0); res.items.push({ label: `Experience at tier ${opp.tier - 1}+`, ok: prev > 0 || (s.skills[opp.sport] || 0) >= opp.requirements.skills[opp.sport] + 2, have: prev ? "yes" : "no", need: "yes" }); res.ok = res.items.every((i) => i.ok); }
  if (s.sport.team && s.sport.team.oppId === opp.id) { res.items.unshift({ label: "Not already on this team", ok: false }); res.ok = false; }
  return res;
}
export function tryout(s, opp) {
  const el = sportEligibility(s, opp); if (!el.ok) return { error: "not eligible", el };
  const need = opp.requirements.skills[opp.sport];
  const p = clamp(0.55 + ((s.skills[opp.sport] || 0) - need) * 0.1 + (s.stats.fitness - opp.requirements.stats.fitness) / 200 + (s.genes.athletic - 50) / 400, 0.1, 0.95);
  if (!chance(p)) { s.stats.happiness = clamp(s.stats.happiness - 4, 0, 100); return { rejected: true }; }
  if (s.sport.team) leaveTeam(s, "moved on");
  s.sport.team = { oppId: opp.id, name: opp.name, sport: opp.sport, tier: opp.tier, years: 0, wins: 0, seasons: [] };
  add(s, `You joined ${opp.name}.`, "good", "sport"); return { ok: true };
}
export function leaveTeam(s, why = "left") { const t = s.sport.team; if (!t) return; s.sport.history.push({ sport: t.sport, tier: t.tier, name: t.name, years: t.years, to: s.age }); add(s, `You ${why === "retired" ? "retired from" : "left"} ${t.name}.`, "info", "sport"); s.sport.team = null; }
function sportYear(s) {
  const t = s.sport.team; if (!t) return 0;
  const opp = Catalog.get(t.oppId); t.years++;
  const g = s.genes.athletic;
  s.skills[t.sport] = clamp((s.skills[t.sport] || 0) + (0.4 + t.tier * 0.06) * (0.75 + g / 140), 0, 10);
  s.stats.fitness = clamp(s.stats.fitness + 2.5, 0, 100);
  if (opp && s.age > opp.requirements.maxAge) { leaveTeam(s, "retired"); return 0; }
  const strength = (s.skills[t.sport] || 0) * 9 + s.stats.fitness * 0.4 + g * 0.25 + gauss(0, 11) - t.tier * 3 - (opp?.popularity >= 8 ? t.tier * 2 : 0);
  const rank = strength > 100 ? "Champions" : strength > 85 ? "Finalists" : strength > 65 ? "Playoffs" : strength > 45 ? "Mid-table" : "Bottom";
  t.seasons.push(rank); if (rank === "Champions") t.wins++;
  const tone = rank === "Champions" || rank === "Finalists" ? "good" : rank === "Bottom" ? "bad" : "info";
  add(s, `${t.name}: season finished as ${rank}.`, tone, "sport");
  if (rank === "Champions") { s.sport.awards.push({ age: s.age, text: `${t.name} champions`, sport: t.sport, tier: t.tier }); s.stats.reputation = clamp(s.stats.reputation + 4 + t.tier, 0, 100); s.stats.happiness = clamp(s.stats.happiness + 8, 0, 100); }
  if (strength > 115 && chance(0.4)) { s.sport.awards.push({ age: s.age, text: `Most Valuable Player (${SPORTS.find((x) => x.id === t.sport).name})`, sport: t.sport, tier: t.tier }); add(s, "You were named MVP!", "good", "sport"); }
  if (chance(0.06 + t.tier * 0.02 - (s.stats.fitness - 50) / 1000)) { s.conditions.push({ name: "Sports injury", sev: 1, chronic: false, since: s.age }); s.stats.health = clamp(s.stats.health - 8, 0, 100); add(s, "You picked up a sports injury.", "bad", "sport"); }
  const pay = (opp?.salaryUSD || 0) * Math.sqrt(wage(s)); s.sport.careerEarn += pay;
  if (pay) return pay;
  if (t.tier <= 2 && !parentsLive(s)) { s.money.cash -= Math.round(250 * col(s)); if (s.money.cash < 0) { s.money.debt -= s.money.cash; s.money.cash = 0; } }
  return 0;
}

// ---------------- activities ----------------
export function activityEligibility(s, a) { const r = checkReq(s, a.requirements); if (s.activities.length >= 4) { r.items.push({ label: "Free time slot (max 4)", ok: false }); r.ok = false; } if (s.activities.some((x) => x.id === a.id)) { r.items.push({ label: "Not already joined", ok: false }); r.ok = false; } return r; }
export function joinActivity(s, a) { const el = activityEligibility(s, a); if (!el.ok) return { error: "not eligible", el }; s.activities.push({ id: a.id, name: a.name, joined: s.age, years: 0 }); add(s, `You joined ${a.name}.`, "good", "activity"); return { ok: true }; }
export function leaveActivity(s, id) { const a = s.activities.find((x) => x.id === id); s.activities = s.activities.filter((x) => x.id !== id); if (a) add(s, `You quit ${a.name}.`, "info", "activity"); }
function activityYear(s) {
  let cost = 0;
  for (const m of [...s.activities]) {
    const a = Catalog.get(m.id); if (!a) continue; m.years++;
    if (a.requirements.maxAge && s.age > a.requirements.maxAge) { leaveActivity(s, m.id); continue; }
    for (const [k, v] of Object.entries(a.gains || {})) s.skills[k] = clamp((s.skills[k] || 0) + v * (0.8 + (s.genes.apt[k] || 1) * 0.3), 0, 10);
    for (const [k, v] of Object.entries(a.stats || {})) s.stats[k] = clamp(s.stats[k] + v, 0, 100);
    cost += a.costUSD;
    if (a.kind === "club" || a.kind === "volunteering") { const f = s.rels.filter((r) => r.alive && ["friend", "classmate"].includes(r.role)); if (chance(0.4) && f.length < 25) addNpc(s, { role: "friend", ageRel: 0 }); }
  }
  if (cost && !parentsLive(s)) { s.money.cash -= cost; if (s.money.cash < 0) { s.money.debt -= s.money.cash; s.money.cash = 0; } }   // parents pay for a child's clubs
}

// ---------------- money ----------------
export const netWorth = (s) => Math.round(s.money.cash + s.assets.reduce((a, x) => a + x.value, 0) + (s.housing.value || 0) - s.housing.loan - s.money.debt + (s.business ? s.business.invested : 0));
export function annualExpenses(s) {
  const c = countryOf(s.country);
  if (s.age < 18 && s.housing.id === "parents") return 0;
  const living = (s.age < 18 ? 0 : 9000) * c.col; const rent = s.housing.rentUSD * c.col; const mort = s.housing.loan * 0.0645;
  const health = s.healthSystem === "private" ? 1200 * c.col * (1 + s.age / 60) : s.healthSystem === "mixed" ? 500 * c.col : 150 * c.col;
  const kids = s.rels.filter((r) => r.role === "child" && r.alive && r.age < 18).length * 4500 * c.col;
  return Math.round((s.age < 18 ? 0 : living + rent + health + mort + kids));
}
function moneyYear(s, jobGross, sportPay) {
  const c = countryOf(s.country);
  if (s.age < c.workAge) { jobGross = 0; sportPay = 0; }   // children do not earn salaries
  let income = jobGross + sportPay;
  if (s.business) { const b = s.business; b.years++; const profit = b.invested * gauss(0.1 + (s.skills.business || 0) * 0.02, 0.28); b.last = Math.round(profit); b.total += b.last; income += profit; s.stats.stress = clamp(s.stats.stress + 3, 0, 100); if (b.total < -b.invested * 0.7 && b.years > 2) { add(s, `${b.name} went bankrupt.`, "bad", "finance"); s.business = null; } else add(s, `${b.name} made ${b.last >= 0 ? "a profit of" : "a loss of"} ${M(s, Math.abs(b.last))}.`, b.last >= 0 ? "good" : "bad", "finance"); }
  let pension = 0;
  if (s.retired) { pension = Math.max(s.peakSalary, 12000 * c.wage * 3) * (c.health === "universal" ? 0.5 : 0.35) * (c.tax < 0.15 ? 0.7 : 1); income += pension; }
  const allowance = s.age >= 8 && s.age < 18 ? Math.round([15, 40, 80, 160, 300][s.family.tier] * c.col * (s.age / 14)) : 0; income += allowance;
  const tax = (income - allowance) * c.tax * (income > 120000 ? 1.15 : 1);
  const exp = annualExpenses(s);
  const interest = s.money.cash > 0 ? s.money.cash * 0.02 : 0;
  const debtInt = s.money.debt * 0.08;
  const net = income - tax - exp + interest - debtInt;
  s.money.cash += net; s.lifetimeEarn += income;
  if (s.money.cash > 0 && s.money.debt > 0) { const pay = Math.min(s.money.cash * 0.6, s.money.debt); if (pay > 0 && s.age >= 18 && s.money.cash - pay > exp * 0.5) { s.money.cash -= pay; s.money.debt -= pay; } }
  if (s.money.cash < 0) { s.money.debt += -s.money.cash; s.money.cash = 0; }
  if (s.housing.loan > 0) { s.housing.loan = Math.max(0, s.housing.loan - (s.housing.loan * 0.0645 - s.housing.loan * 0.05)); }
  s.housing.value = Math.round((s.housing.value || 0) * 1.03);
  s.assets.forEach((a) => (a.value = Math.round(a.value * (1 - a.dep))));
  s.assets = s.assets.filter((a) => a.value > 20);
  s.yearMoney = { income: Math.round(income), tax: Math.round(tax), expenses: Math.round(exp), net: Math.round(net), allowance: Math.round(allowance), pension: Math.round(pension) };
  if (s.age >= 14 && income > 0) add(s, `Money: earned ${M(s, income)}, spent ${M(s, exp + tax)} (tax incl.), net ${net >= 0 ? "+" : "-"}${M(s, Math.abs(net))}.`, net >= 0 ? "good" : "bad", "finance");
}
export function setHousing(s, id) {
  const h = HOUSING.find((x) => x.id === id); if (!h || id === s.housing.id) return { error: "Already there." };
  if (s.age < (h.minAge || 0)) return { error: `You must be ${h.minAge}+ for that.` };
  if (s.age < 18 && id !== "parents") return { error: "Minors can't live alone." };
  if (h.buy) {
    const price = Math.round(h.buy * col(s)); const down = Math.round(price * 0.2);
    if (s.money.cash < down) return { error: `You need a ${M(s, down)} deposit (20%).`, need: down };
    if ((s.job?.salaryUSD || 0) * 4 < price - down && !s.business) return { error: "The bank says your income is too low for this mortgage." };
    s.money.cash -= down; s.housing = { id, rentUSD: 0, value: price, loan: price - down }; add(s, `You bought a ${h.name.split(" ")[0].toLowerCase()} for ${M(s, price)}.`, "good", "finance");
  } else {
    if (s.housing.value && s.housing.id !== "parents") { s.money.cash += s.housing.value - s.housing.loan; }
    s.housing = { id, rentUSD: h.rent, value: 0, loan: 0 }; add(s, `You moved into: ${h.name}.`, "info", "finance");
  }
  return { ok: true };
}
export function takeLoan(s, usd) { if (s.age < 18) return { error: "Too young." }; const lim = Math.max(2000, (s.job?.salaryUSD || 0) * 2); if (s.money.debt + usd > lim) return { error: `Credit limit is ${M(s, lim)}.` }; s.money.cash += usd; s.money.debt += usd; add(s, `You took a ${M(s, usd)} loan.`, "info", "finance"); return { ok: true }; }
export function repay(s, usd) { const p = Math.min(usd, s.money.cash, s.money.debt); if (p <= 0) return { error: "Nothing to repay." }; s.money.cash -= p; s.money.debt -= p; add(s, `You repaid ${M(s, p)} of debt.`, "good", "finance"); return { ok: true }; }
export function sellAsset(s, id) { const a = s.assets.find((x) => x.id === id); if (!a) return; s.money.cash += a.value; s.assets = s.assets.filter((x) => x.id !== id); add(s, `Sold ${a.name} for ${M(s, a.value)}.`, "info", "finance"); }
export function closeBusiness(s) { if (!s.business) return; s.money.cash += Math.max(0, s.business.invested * 0.6); add(s, `You sold ${s.business.name}.`, "info", "finance"); s.business = null; }

// ---------------- health ----------------
export const checkupCost = (s) => Math.round((s.healthSystem === "universal" ? 40 : s.healthSystem === "mixed" ? 120 : 250) * col(s));
export const therapyCost = (s) => Math.round((s.healthSystem === "universal" ? 60 : 160) * col(s));
export function visitDoctor(s) {
  const cost = checkupCost(s); const paid = payFor(s, cost, { essential: true });
  if (!paid.ok) return paid.refused ? { error: "parents", message: "Your parents say they can't cover a check-up right now." } : { error: "afford", need: cost };
  s.stats.health = clamp(s.stats.health + 5, 0, 100);
  add(s, `Check-up${paid.by === "parents" ? " (your parents paid)" : ""}: the doctor says you're doing ${s.stats.health > 70 ? "well" : "okay"}.`, "good", "health"); return { ok: true, cost, by: paid.by };
}
export function therapy(s) {
  const cost = therapyCost(s); const paid = payFor(s, cost, { essential: true });
  if (!paid.ok) return paid.refused ? { error: "parents", message: "Your parents say therapy isn't in the budget right now." } : { error: "afford", need: cost };
  s.stats.stress = clamp(s.stats.stress - 15, 0, 100); s.stats.happiness = clamp(s.stats.happiness + 4, 0, 100); add(s, "A therapy session helped.", "good", "health"); return { ok: true, cost };
}

// ---------------- relationships ----------------
export const REL_ACTIONS = [
  { id: "time", label: "Spend time", roles: "all" }, { id: "talk", label: "Deep talk", roles: "all" }, { id: "gift", label: "Give a gift", roles: "all" },
  { id: "argue", label: "Argue", roles: "all" }, { id: "money", label: "Ask for money", roles: ["mother", "father", "sibling", "friend", "spouse", "partner"] },
  { id: "askout", label: "Ask out", roles: ["friend", "classmate", "coworker"] }, { id: "propose", label: "Propose", roles: ["partner"] }, { id: "child", label: "Try for a baby", roles: ["partner", "spouse"] },
  { id: "breakup", label: "Break up", roles: ["partner"] }, { id: "divorce", label: "Divorce", roles: ["spouse"] }, { id: "cutoff", label: "Cut off", roles: ["friend", "classmate", "coworker", "ex"] },
];
export function relAction(s, id, action) {
  const n = s.rels.find((r) => r.id === id); if (!n || !n.alive) return { error: "Not available." };
  const bud = (s.quick._rel || 0); const free = ["breakup", "divorce", "cutoff"].includes(action);
  if (!free && bud >= 6) return { error: "You've used your energy for people this year (6 interactions). Age up for more." };
  if (!free) s.quick._rel = bud + 1;
  const A = (a, t = 0, r = 0) => { n.affection = clamp(n.affection + a, 0, 100); n.trust = clamp(n.trust + t, 0, 100); n.respect = clamp(n.respect + r, 0, 100); };
  const cn = n.name.first;
  switch (action) {
    case "time": A(int(4, 8) * (n.compat > 60 ? 1.2 : 0.9), 2); s.stats.happiness = clamp(s.stats.happiness + 2, 0, 100); return { text: `You spent quality time with ${cn}.`, tone: "good" };
    case "talk": A(2, int(4, 8), 2); return { text: `You had an honest talk with ${cn}. Trust grew.`, tone: "good" };
    case "gift": { const c = Math.round(40 * col(s)); if (s.money.cash < c) return { error: `A gift costs ${M(s, c)}.` }; s.money.cash -= c; A(int(5, 9), 1); return { text: `${cn} loved the gift.`, tone: "good" }; }
    case "argue": A(-int(6, 12), -4, n.personality.agreeableness > 60 ? -3 : 2); s.stats.stress = clamp(s.stats.stress + 4, 0, 100); return { text: `You argued with ${cn}.`, tone: "bad" };
    case "money": { if (n.trust < 40) return { text: `${cn} doesn't trust you enough to lend money.`, tone: "bad" }; const amt = Math.round(150 * col(s) * (n.tier + 1) / 2); if (chance(0.55 + n.affection / 300)) { s.money.cash += amt; A(-3, -3, -2); return { text: `${cn} gave you ${M(s, amt)}.`, tone: "good" }; } A(-4, -2); return { text: `${cn} said no.`, tone: "bad" }; }
    case "askout": {
      if (s.age < 13 || n.age < 13) return { error: "Too young for dating." }; if (Math.abs(n.age - s.age) > 8 && (n.age < 18 || s.age < 18)) return { error: "That age gap isn't appropriate." };
      const p = clamp(0.2 + n.affection / 250 + n.compat / 300 + (s.stats.looks - 50) / 300, 0.05, 0.85);
      if (chance(p)) { n.role = "partner"; n.affection = clamp(n.affection + 12, 0, 100); add(s, `${cn} said yes! You're dating.`, "good", "relationship"); return { text: `${cn} said yes!`, tone: "good", log: true }; }
      A(-6); s.stats.happiness = clamp(s.stats.happiness - 4, 0, 100); return { text: `${cn} turned you down.`, tone: "bad" };
    }
    case "propose": {
      if (s.age < 18 || n.age < 18) return { error: "You both need to be adults." };
      const ring = Math.round(1500 * col(s)); if (s.money.cash < ring) return { error: `A ring costs ${M(s, ring)}.` };
      s.money.cash -= ring;
      if (n.affection >= 65 && n.trust >= 50 && chance(0.8)) { n.role = "spouse"; n.affection = clamp(n.affection + 10, 0, 100); s.stats.happiness = clamp(s.stats.happiness + 15, 0, 100); add(s, `You married ${cn} ${n.name.last}!`, "good", "relationship"); s.memory.key.push({ age: s.age, text: `Married ${cn}.`, tag: "marriage" }); return { text: `${cn} said yes. You're married!`, tone: "good", log: true }; }
      A(-8, -4); s.stats.happiness = clamp(s.stats.happiness - 8, 0, 100); return { text: `${cn} said not yet.`, tone: "bad" };
    }
    case "child": {
      if (s.age < 18 || n.age < 18) return { error: "You both need to be adults." }; if (s.gender === n.gender && s.orientation !== "bi") return { error: "You could adopt instead (not available yet)." };
      const mom = s.gender === "female" ? s : n.gender === "female" ? n : null;
      if (n.gender === s.gender) return { error: "Adoption isn't modelled yet." };
      const momAge = mom === s ? s.age : n.age; if (momAge > 46) return { error: "Pregnancy isn't likely at that age." };
      if (n.affection < 50) return { text: `${cn} isn't ready for a child.`, tone: "bad" };
      if (!chance(0.35)) return { text: "Not this time. Keep trying?", tone: "info" };
      const g = pick(["male", "female"]); const pg = n.genes; const sg = s.genes;
      const father = s.gender === "male" ? { genes: sg } : { genes: pg }; const mother = s.gender === "female" ? { genes: sg } : { genes: pg };
      const baby = makeNpc("child", { age: 0, gender: g, country: s.country, last: countryOf(s.country).code === "ET" ? (s.gender === "male" ? s.name.first : n.name.first) : (s.gender === "male" ? s.name.last : n.name.last), genes: inheritGenes(father.genes, mother.genes, g), basePers: s.personality, tier: s.family.tier, met: s.age });
      baby.occupation = "Baby"; s.rels.push(baby); s.stats.happiness = clamp(s.stats.happiness + 10, 0, 100); s.stats.stress = clamp(s.stats.stress + 6, 0, 100);
      add(s, `You and ${cn} welcomed a ${g === "male" ? "son" : "daughter"}: ${baby.name.first}!`, "good", "relationship"); s.memory.key.push({ age: s.age, text: `Had a child, ${baby.name.first}.`, tag: "child" });
      return { text: `${baby.name.first} was born!`, tone: "good", log: true };
    }
    case "breakup": n.role = "ex"; n.affection = clamp(n.affection - 30, 0, 100); s.stats.happiness = clamp(s.stats.happiness - 8, 0, 100); add(s, `You broke up with ${cn}.`, "bad", "relationship"); return { text: "You broke up.", tone: "bad", log: true };
    case "divorce": { const cost = Math.round(4000 * col(s)); s.money.cash = Math.max(0, s.money.cash - cost); n.role = "ex"; n.affection = clamp(n.affection - 40, 0, 100); s.stats.happiness = clamp(s.stats.happiness - 12, 0, 100); add(s, `You divorced ${cn}.`, "bad", "relationship"); return { text: "Divorced.", tone: "bad", log: true }; }
    case "cutoff": n.status = "estranged"; n.affection = 0; add(s, `You cut ${cn} out of your life.`, "info", "relationship"); return { text: "Cut off.", tone: "info", log: true };
  }
}

// ---------------- the yearly cycle ----------------
export function advanceYear(s) {
  s.age++; s.year++; s.prompts = 5; ensureLocal(s); s.quick = {}; s.feed = []; s.pending = [];
  const c = countryOf(s.country);
  if (s.prison > 0) { s.prison--; if (s.prison === 0) add(s, "You were released from prison.", "info", "life"); }
  vitals(s); school(s); collegeYear(s);
  let gross = 0, sportPay = 0;
  if (s.job && s.prison <= 0) { gross = workYear(s); if (s.job.__fired) { endJob(s, "fired"); gross = 0; } }
  else if (s.job) { endJob(s, "fired"); }
  if (s.age >= c.retire && !s.retired && s.job) { endJob(s, "retired"); s.retired = true; add(s, "You retired. Welcome to the golden years.", "info", "career"); }
  if (s.age >= c.retire + 3 && !s.retired) { s.retired = true; }
  sportPay = sportYear(s); activityYear(s); conditions(s); npcYear(s); socialLife(s); moneyYear(s, gross, sportPay);
  if (s.age >= 18 && s.housing.id === "parents" && s.age >= 24 && chance(0.2)) feedOnly(s, "Your parents hint it might be time to get your own place.", "warn");
  if (s.age === 18) add(s, "You're an adult now. New doors have opened.", "good", "life");
  if (s.age === c.driveAge) add(s, `You're now old enough to drive in ${c.name}.`, "info", "life");
  if (s.age === c.drinkAge) add(s, `You're now old enough to drink alcohol in ${c.name}.`, "info", "life");
  // mortality
  const hpF = s.stats.health < 25 ? 3 : s.stats.health < 45 ? 1.6 : 1; const lgF = 1.25 - s.genes.longevity / 200; const cdF = 1 + s.conditions.reduce((x, k) => x + (k.sev >= 2 ? 0.5 : 0.1), 0);
  if (chance(mortality(s.age) * hpF * lgF * cdF)) {
    s.alive = false; const worst = s.conditions.sort((a, b) => b.sev - a.sev)[0];
    s.cause = s.age < 3 ? "a childhood illness" : s.age < 40 && chance(0.4) ? "an accident" : worst && worst.sev >= 2 ? worst.name.toLowerCase() : "natural causes";
    add(s, `You died at ${s.age} from ${s.cause}.`, "bad", "life");
    return s;
  }
  // this year's events
  s.pending = pickYearlyEvents(s, s.age < 3 ? 1 : s.age < 6 ? 2 : 3);
  return s;
}

hooks.makeJobOffer = makeJobOffer;

// Older saves used random catalog ids; map them onto the stable ids used now.
export function migrateSave(s) {
  if (s.v >= 2) return s;
  if (s.job) { const j = Catalog.get(`job:${s.job.field}`); if (j) s.job.id = j.id; }
  s.activities = (s.activities || []).map((a) => { const m = Catalog.list("activity").find((x) => x.name === a.name); return m ? { ...a, id: m.id } : a; }).filter((a) => Catalog.get(a.id));
  if (s.edu.current) { const m = Catalog.list("education").find((x) => x.field === s.edu.current.field && x.level === s.edu.current.level); s.edu.current.id = m ? m.id : s.edu.current.id; s.edu.current.teaches = s.edu.current.teaches || {}; delete s.edu.current.requirements; }
  s.edu.applied = s.edu.applied || {};
  s.memory.had = s.memory.had || {};
  s.sport.team = s.sport.team && Catalog.get(s.sport.team.oppId) ? s.sport.team : null;
  delete s.boards;
  s.v = 2;
  return s;
}
