import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useG, Panel, ReqList, Pill, Money, Empty } from "./kit.jsx";
import { Catalog } from "../engine/catalog.js";
import { activityEligibility, joinActivity, leaveActivity } from "../engine/sim.js";
import { skillName, registry } from "../engine/rules.js";

export function ActivitiesPage() {
  const { s, act, focus, clearFocus, toast, setWarn } = useG();
  const [open, setOpen] = useState(null);
  useEffect(() => { if (focus && Catalog.get(focus)?.type === "activity") { setOpen(focus); clearFocus(); } }, [focus]);
  const list = Catalog.list("activity").map((x) => ({ x, el: activityEligibility(s, x) })).sort((p, q) => (q.el.ok - p.el.ok) || p.x.name.localeCompare(q.x.name)).map((p) => p.x);
  return (
    <div className="space-y-4">
      <Panel title={`Your commitments (${s.activities.length}/4)`}>
        {s.activities.length === 0 ? <Empty>No hobbies or clubs yet. Join one below.</Empty> : (
          <ul className="space-y-2">{s.activities.map((m) => { const a = Catalog.get(m.id); return (
            <li key={m.id} className="flex items-center justify-between gap-3 rounded-lg border border-border p-3"><span><span className="block text-base font-medium">{m.name}</span><span className="text-sm text-muted-foreground">{m.years} yr · {a ? Object.keys(a.gains).map(skillName).join(", ") || "wellbeing" : ""}</span></span><Button type="button" size="sm" variant="outline" onClick={() => act((n) => leaveActivity(n, m.id))}>Quit</Button></li>); })}</ul>
        )}
      </Panel>
      <Panel title="Clubs, lessons and hobbies">
        {list.length === 0 ? <Empty>Nothing available.</Empty> : (
          <div className="grid gap-3 @2xl:grid-cols-2">{list.map((a) => { const el = activityEligibility(s, a); return (
            <button key={a.id} type="button" onClick={() => setOpen(a.id)} className="rounded-xl border border-border p-4 text-left transition-colors hover:border-primary">
              <div className="flex items-start justify-between gap-2"><p className="text-base font-semibold">{a.name}</p><Pill tone={el.ok ? "good" : "bad"}>{el.ok ? "Open" : "Locked"}</Pill></div>
              <p className="mt-1 text-sm text-muted-foreground capitalize">{a.kind} · <Money usd={a.costUSD} />/yr</p>
            </button>); })}</div>
        )}
      </Panel>
      {open && <ActDetail id={open} close={() => setOpen(null)} />}
    </div>
  );
}
function ActDetail({ id, close }) {
  const { s, act, toast, setWarn } = useG(); const a = Catalog.get(id); if (!a) return null; const el = activityEligibility(s, a);
  const join = () => { if (!el.ok) return setWarn({ title: "You can't join yet", message: "You're missing:", items: el.items.filter((i) => !i.ok) }); act((n) => joinActivity(n, a)); toast.success(`Joined ${a.name}`); close(); };
  return (
    <Dialog open onOpenChange={(o) => !o && close()}>
      <DialogContent className="max-w-lg"><DialogHeader><Pill tone="primary" className="w-fit capitalize">{a.kind}</Pill><DialogTitle className="font-display text-2xl">{a.name}</DialogTitle><DialogDescription className="text-base">{a.desc}</DialogDescription></DialogHeader>
        <ReqList items={el.items} />
        <div className="grid grid-cols-2 gap-2 text-base"><div className="rounded-lg bg-foreground/5 p-3"><p className="text-sm text-muted-foreground">Trains</p>{Object.keys(a.gains).map(skillName).join(", ") || "Wellbeing"}</div><div className="rounded-lg bg-foreground/5 p-3"><p className="text-sm text-muted-foreground">Cost</p><Money usd={a.costUSD} />/yr</div></div>
        <Button type="button" onClick={join} className="h-12 text-base">Join</Button>
      </DialogContent>
    </Dialog>
  );
}
