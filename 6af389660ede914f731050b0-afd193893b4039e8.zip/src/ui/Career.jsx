import { useEffect, useState } from "react";
import { Briefcase, TrendingUp, Clock } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Switch } from "@/components/ui/switch";
import { useG, Panel, Bar, ReqList, Pill, Money, Empty } from "./kit.jsx";
import { Catalog } from "../engine/catalog.js";
import { jobEligibility, applyForJob, endJob, promotionStatus, askPromotion } from "../engine/sim.js";
import { countryOf, fmtMoney } from "../engine/data.js";
import { cn } from "@/lib/utils";

export function CareerPage() {
  const { s, act, focus, clearFocus, setWarn, toast } = useG();
  const [open, setOpen] = useState(null); const [q, setQ] = useState(""); const [onlyOk, setOnlyOk] = useState(false);
  useEffect(() => { if (focus && Catalog.get(focus)?.type === "career") { setOpen(focus); clearFocus(); } }, [focus]);
  const all = Catalog.list("career");
  const list = all.map((job) => ({ job, el: jobEligibility(s, job) }))
    .filter(({ job, el }) => (!q || (job.name + " " + job.fieldName + " " + job.ladder.map((r) => r.title).join(" ")).toLowerCase().includes(q.toLowerCase())) && (!onlyOk || el.ok))
    .sort((a, b) => (b.el.ok - a.el.ok) || a.job.name.localeCompare(b.job.name));
  const j = s.job; const ps = j ? promotionStatus(s) : null; const wage = countryOf(s.country).wage;
  const setMode = (m) => m && act((n) => { n.job.mode = m; });
  const doPromo = () => { const r = act((n) => askPromotion(n)); if (r.error === "not ready") return setWarn({ title: "Not ready for a promotion", message: "Your boss says you're missing:", items: r.ps.items }); if (r.error) return setWarn({ title: "Nothing higher", message: r.error }); r.ok ? toast.success("Promoted!") : toast.error("Your boss said not yet."); };
  return (
    <div className="space-y-4">
      {j ? (
        <Panel title="Current job" className="border-primary/40">
          <div className="flex items-start justify-between gap-3"><div><p className="font-display text-2xl font-bold leading-tight">{j.title}</p><p className="text-sm text-muted-foreground">{j.company ? `${j.company} · ` : ""}{j.name} · {j.hours} h/week{j.partTime ? " · part-time" : ""} · {j.years} yr{j.years !== 1 ? "s" : ""}</p></div><div className="text-right"><Money usd={j.salaryUSD} className="text-xl font-semibold" /><p className="text-sm text-muted-foreground">per year, before tax</p></div></div>
          <div className="mt-4"><div className="mb-1 flex justify-between text-sm"><span>Performance</span><span className="font-mono">{Math.round(j.perf)}</span></div><Bar value={j.perf} tone={j.perf > 65 ? "good" : j.perf > 40 ? "warn" : "bad"} h="h-3" /></div>
          <div className="mt-4"><p className="mb-2 text-sm text-muted-foreground">Work style</p><ToggleGroup type="single" value={j.mode} onValueChange={setMode} variant="outline" className="w-full">{[["coast", "Coast"], ["normal", "Steady"], ["hard", "Go hard"]].map(([v, l]) => <ToggleGroupItem key={v} value={v} className="h-11 flex-1">{l}</ToggleGroupItem>)}</ToggleGroup></div>
          {ps && !ps.top && <div className="mt-4 rounded-lg bg-foreground/5 p-3"><p className="mb-2 text-sm text-muted-foreground"><TrendingUp className="mr-1 inline size-4" />Next: {ps.next.title} (<Money usd={ps.next.salaryUSD * wage} />)</p><ReqList items={ps.items} /></div>}
          {ps?.top && <p className="mt-4 text-sm text-muted-foreground">You've reached the top of this ladder.</p>}
          <div className="mt-4 flex gap-2"><Button type="button" onClick={doPromo} className="flex-1">Ask for promotion</Button><Button type="button" variant="outline" onClick={() => { act((n) => endJob(n, "quit")); toast("You quit."); }}>Quit</Button></div>
        </Panel>
      ) : (
        <Panel title="Career"><p className="text-base text-muted-foreground">{s.retired ? "You're retired and living off savings and pension." : s.age < 14 ? "Too young to work. Focus on school and play." : "No job right now. Browse the job market below. Green means you already qualify."}</p></Panel>
      )}
      {s.jobHistory.length > 0 && <Panel title="Work history"><ul className="space-y-1 text-base">{s.jobHistory.slice(-6).reverse().map((h, i) => <li key={i} className="flex justify-between"><span>{h.title}</span><span className="text-muted-foreground">age {h.from}–{h.to} · {h.why}</span></li>)}</ul></Panel>}
      <Panel title="Job market" action={<label className="flex items-center gap-2 text-sm text-muted-foreground"><Switch checked={onlyOk} onCheckedChange={setOnlyOk} />Qualified only</label>}>
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search jobs, fields or titles…" className="mb-3 h-11" aria-label="Search jobs" />
        {s.age < 14 && <p className="mb-3 rounded-lg bg-foreground/5 p-3 text-sm text-muted-foreground">You can browse every job and see what it takes, but you are too young to apply.</p>}
        {list.length === 0 ? <Empty>No jobs match that.</Empty> : (
          <div className="grid gap-3 @2xl:grid-cols-2">
            {list.map(({ job, el }) => (
              <button key={job.id} type="button" onClick={() => setOpen(job.id)} className="rounded-xl border border-border p-4 text-left transition-colors hover:border-primary">
                <div className="flex items-start justify-between gap-2"><p className="text-base font-semibold leading-snug">{job.name}</p><Pill tone={el.ok ? "good" : "bad"}>{el.ok ? "Qualified" : "Not yet"}</Pill></div>
                <p className="mt-1 text-sm text-muted-foreground">{job.fieldName} · <Money usd={job.salaryRange[0] * wage} />–<Money usd={job.salaryRange[1] * wage} /></p>
              </button>))}
          </div>
        )}
      </Panel>
      <JobDetail id={open} close={() => setOpen(null)} />
    </div>
  );
}

function JobDetail({ id, close }) {
  const { s, act, setWarn, toast } = useG();
  const job = id ? Catalog.get(id) : null;
  if (!job) return null;
  const el = jobEligibility(s, job); const wage = countryOf(s.country).wage;
  const apply = () => {
    if (!el.ok) {
      const items = el.base.ok ? el.best.res.items : [...el.base.items.filter((i) => !i.ok), ...el.best.res.items.filter((i) => !i.ok)];
      return setWarn({ title: "You don't qualify yet", message: el.driveBlock ? `Driving jobs need a licence, from age ${countryOf(s.country).driveAge} here.` : `${job.name} needs one of the qualification routes below. Closest route: "${el.best.p.label}".`, items });
    }
    const r = act((n) => applyForJob(n, job)); close();
    if (r.rejected) toast.error("They went with another candidate."); else toast.success(`Hired as ${r.title}!`);
  };
  return (
    <Dialog open onOpenChange={(o) => !o && close()}>
      <DialogContent className="max-h-[92vh] max-w-xl overflow-y-auto">
        <DialogHeader>
          <div className="flex flex-wrap gap-2"><Pill tone="primary">{job.fieldName}</Pill><Pill><Clock className="mr-1 size-3" />{job.hours} h/wk</Pill><Pill>Age {el.minAge}+</Pill></div>
          <DialogTitle className="font-display text-2xl leading-tight">{job.name}</DialogTitle>
          <DialogDescription className="text-base">{job.desc}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="flex justify-between rounded-lg bg-foreground/5 p-3 text-base"><span>Salary range in {countryOf(s.country).name}</span><span className="font-mono"><Money usd={job.salaryRange[0] * wage} /> – <Money usd={job.salaryRange[1] * wage} /></span></div>
          <div><p className="mb-2 text-sm font-medium text-muted-foreground">Ways in (any one of these routes works)</p>
            <div className="space-y-2">{el.routes.map((r, i) => <div key={i} className={cn("rounded-lg border p-3", r.res.ok ? "border-good/50 bg-good/5" : "border-border")}><p className="mb-2 flex items-center justify-between text-base"><span>{r.p.label}</span><Pill>{r.p.rung === 0 ? "Starts as " + job.ladder[0].title : "Starts as " + job.ladder[Math.min(r.p.rung, 3)].title}</Pill></p><ReqList items={r.res.items} /></div>)}</div></div>
          <div><p className="mb-2 text-sm font-medium text-muted-foreground">Career ladder</p>
            <ol className="space-y-2">{job.ladder.map((r, i) => <li key={i} className="flex items-center justify-between rounded-lg border border-border p-3 text-base"><span><span className="text-muted-foreground">{i + 1}.</span> {r.title}</span><span className="text-right font-mono text-sm"><Money usd={r.salaryUSD * wage} /><span className="block text-muted-foreground">{r.reqYears ? `${r.reqYears}+ yrs · perf ${r.reqPerf}` : "entry"}</span></span></li>)}</ol></div>
          <Button type="button" onClick={apply} className="h-12 w-full text-base"><Briefcase className="size-5" /> Apply</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
