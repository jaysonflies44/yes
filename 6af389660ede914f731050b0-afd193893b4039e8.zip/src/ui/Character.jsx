import { useG, Panel, Bar, Portrait, Pill, STAT_TONE } from "./kit.jsx";
import { appearance } from "../engine/char.js";
import { registry } from "../engine/rules.js";
import { PERSONALITY, SKILL_CATS, countryOf, EDU_LEVELS, skillLvl, nameOf } from "../engine/data.js";
import { SPORTS } from "../engine/data.js";

const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
export function CharacterPage() {
  const { s } = useG();
  const ap = appearance(s); const g = s.genes; const c = countryOf(s.country);
  const gene = [
    ["Height", `${g.height} cm potential`, ap.height, g.height, `${ap.height} cm now`],
    ["Athletic ability", g.athletic, s.stats.fitness, 100, `Fitness ${Math.round(s.stats.fitness)}`],
    ["Intellect", g.intellect, s.stats.smarts, 100, `Smarts ${Math.round(s.stats.smarts)}`],
    ["Looks", g.looks, s.stats.looks, 100, `Looks ${Math.round(s.stats.looks)}`],
    ["Creativity", g.creative, ((s.skills.creativity || 0) + (s.skills.art || 0) + (s.skills.music || 0)) * 10 / 3, 100, "Creative skills"],
    ["Longevity", g.longevity, s.stats.health, 100, `Health ${Math.round(s.stats.health)}`],
  ];
  const carried = [g.eye.includes("U") && "blue eyes", g.eye.includes("G") && "green eyes", g.hair.includes("L") && "blonde hair", g.hair.includes("R") && "red hair"].filter(Boolean);
  const CORE = ["literature", "mathematics", "logic", "science", "languages", "communication", "leadership", "business", "creativity", "art", "music", "cooking", "programming", "gaming"];
  const skills = registry.skills.filter((k) => (s.skills[k.id] || 0) > 0 || CORE.includes(k.id));
  return (
    <div className="space-y-4">
      <Panel>
        <div className="flex flex-col gap-4 @xl:flex-row">
          <Portrait p={s} age={s.age} mood={s.stats.happiness} size={140} className="shrink-0 self-center" />
          <div className="flex-1 space-y-3">
            <div><h2 className="font-display text-3xl font-bold leading-tight">{nameOf(s)}</h2><p className="text-base text-muted-foreground">{s.gender === "male" ? "Male" : "Female"}, {s.age} · {c.name} · born {MONTHS[s.birth.m - 1]} {s.birth.d} ({s.birth.zodiac})</p></div>
            <div className="flex flex-wrap gap-2"><Pill>Born in {s.hometown}</Pill><Pill>Lives in {s.city}</Pill><Pill>{ap.eye} eyes</Pill><Pill>{ap.hair} {ap.texture} hair</Pill><Pill>{ap.tone} skin</Pill><Pill>{ap.build} build</Pill><Pill>{EDU_LEVELS[s.edu.level]}</Pill></div>
          </div>
        </div>
      </Panel>
      <div className="grid gap-4 @2xl:grid-cols-2">
        <Panel title="Genetic potential vs developed">
          <p className="mb-3 text-sm text-muted-foreground">Genes cap what you can become. Habits, school and training decide how much you reach.</p>
          <div className="space-y-4">
            {gene.map(([name, pot, now, max, label]) => (
              <div key={name}>
                <div className="mb-1 flex justify-between text-sm"><span>{name}</span><span className="font-mono text-muted-foreground">{typeof pot === "number" ? `potential ${pot}` : pot} · {label}</span></div>
                <div className="relative"><Bar value={Math.min(now, max)} max={max} tone="primary" h="h-3" /><span className="absolute top-0 h-3 w-0.5 bg-foreground" style={{ left: `${typeof pot === "number" ? (name === "Height" ? 100 : pot) : 100}%` }} /></div>
              </div>
            ))}
          </div>
          {carried.length > 0 && <p className="mt-4 text-sm text-muted-foreground">Hidden genes you carry: {carried.join(", ")}. Your children may show them.</p>}
        </Panel>
        <Panel title="Personality">
          <div className="space-y-3">{PERSONALITY.map((t) => <div key={t.id}><div className="mb-1 flex justify-between text-sm"><span>{t.name}</span><span className="font-mono text-muted-foreground">{s.personality[t.id]}</span></div><Bar value={s.personality[t.id]} tone="bloom" /></div>)}</div>
          <p className="mt-4 text-sm text-muted-foreground">Personality shifts event odds: outgoing people win more social gambles, anxious ones panic on rollercoasters.</p>
        </Panel>
      </div>
      <Panel title="Skills">
        <div className="space-y-5">
          {SKILL_CATS.map((cat) => {
            const list = skills.filter((k) => k.cat === cat); if (!list.length) return null;
            return (
              <div key={cat}>
                <p className="mb-2 font-mono text-sm uppercase tracking-widest text-muted-foreground">{cat}</p>
                <div className="grid gap-x-6 gap-y-3 @xl:grid-cols-2">
                  {list.map((k) => (
                    <div key={k.id}><div className="mb-1 flex items-center justify-between text-sm"><span>{k.name}</span><span className="font-mono text-muted-foreground">Lv {skillLvl(s.skills[k.id])}</span></div><Bar value={(s.skills[k.id] || 0)} max={10} tone={cat === "sport" ? "primary" : cat === "creative" ? "bloom" : cat === "social" ? "warn" : "info"} /></div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </Panel>
    </div>
  );
}
