import { useMemo, useState, useEffect } from "react";
import { Dices, Play, Trash2, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select";
import { COUNTRIES, countryOf, makeName, PERSONALITY, fmtMoney, nameOf } from "../engine/data.js";
import { randomDraft, createLife, appearance, npcLabel } from "../engine/char.js";
import { pick } from "../engine/rng.js";
import { Panel, Portrait, Pill } from "./kit.jsx";
import { db } from "../engine/db.js";

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
export function Create({ onStart, onLoad, saves, onDelete }) {
  const [d, setD] = useState(() => randomDraft());
  const [nonce, setNonce] = useState(0);
  const preview = useMemo(() => createLife(d), [d.country, d.city, d.gender, nonce]); // parents + genetics preview
  const up = (p) => setD((x) => ({ ...x, ...p }));
  const reroll = () => { setD(randomDraft()); setNonce((n) => n + 1); };
  const setCountry = (code) => { const c = countryOf(code); const nm = makeName(code, d.gender); up({ country: code, city: c.cities[0], first: nm.first, middle: nm.middle, last: nm.last }); };
  const setGender = (g) => { if (!g) return; const nm = makeName(d.country, g); up({ gender: g, first: nm.first, middle: nm.middle }); };
  const c = countryOf(d.country);
  const ap = appearance(preview);
  return (
    <div className="@container mx-auto max-w-5xl px-4 py-8 @3xl:py-16">
      <header className="mb-8">
        <p className="font-mono text-sm uppercase tracking-widest text-primary">Lifeline</p>
        <h1 className="font-display text-5xl font-bold leading-[0.95] tracking-tight @3xl:text-7xl">Pick a start.<br /><span className="text-primary">Live the rest.</span></h1>
        <p className="mt-3 max-w-xl text-base text-muted-foreground">Birth to old age. Real degrees, real jobs, and real entry requirements for every school, from community college to medical school.</p>
      </header>
      {saves.length > 0 && (
        <Panel title="Continue a life" className="mb-6">
          <div className="grid gap-2 @xl:grid-cols-2">
            {saves.map((sv) => (
              <div key={sv.id} className="flex items-center justify-between gap-2 rounded-lg border border-border p-3">
                <button type="button" onClick={() => onLoad(sv)} className="flex-1 text-left">
                  <p className="font-medium">{sv.name}</p>
                  <p className="text-sm text-muted-foreground">Age {sv.age} · {sv.country} · {sv.alive ? "alive" : "deceased"}</p>
                </button>
                <Button type="button" size="icon" variant="ghost" onClick={() => onDelete(sv.id)} aria-label="Delete save"><Trash2 className="size-4" /></Button>
              </div>
            ))}
          </div>
        </Panel>
      )}
      <div className="grid gap-4 @3xl:grid-cols-[1.1fr_1fr]">
        <Panel title="Who are you?" action={<Button type="button" variant="outline" size="sm" onClick={reroll}><Dices className="size-4" /> Randomize</Button>}>
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-2">
              {["first", "middle", "last"].map((k) => <label key={k} className="text-sm text-muted-foreground">{k[0].toUpperCase() + k.slice(1)}<Input value={d[k]} onChange={(e) => up({ [k]: e.target.value })} className="mt-1 h-11 text-base text-foreground" /></label>)}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <label className="text-sm text-muted-foreground">Nationality / birth country
                <NativeSelect value={d.country} onChange={(e) => setCountry(e.target.value)} className="mt-1 w-full">{COUNTRIES.map((x) => <NativeSelectOption key={x.code} value={x.code}>{x.name}</NativeSelectOption>)}</NativeSelect>
              </label>
              <label className="text-sm text-muted-foreground">City of birth
                <NativeSelect value={d.city} onChange={(e) => up({ city: e.target.value })} className="mt-1 w-full">{c.cities.map((x) => <NativeSelectOption key={x} value={x}>{x}</NativeSelectOption>)}</NativeSelect>
              </label>
            </div>
            <div className="grid grid-cols-[1fr_1fr_1fr] items-end gap-3">
              <div><p className="mb-1 text-sm text-muted-foreground">Gender</p>
                <ToggleGroup type="single" value={d.gender} onValueChange={setGender} variant="outline" className="w-full"><ToggleGroupItem value="male" className="h-11 flex-1">Male</ToggleGroupItem><ToggleGroupItem value="female" className="h-11 flex-1">Female</ToggleGroupItem></ToggleGroup></div>
              <label className="text-sm text-muted-foreground">Birth month<NativeSelect value={d.month} onChange={(e) => up({ month: +e.target.value })} className="mt-1 w-full">{MONTHS.map((m, i) => <NativeSelectOption key={m} value={i + 1}>{m}</NativeSelectOption>)}</NativeSelect></label>
              <label className="text-sm text-muted-foreground">Day<NativeSelect value={d.day} onChange={(e) => up({ day: +e.target.value })} className="mt-1 w-full">{Array.from({ length: 28 }, (_, i) => <NativeSelectOption key={i} value={i + 1}>{i + 1}</NativeSelectOption>)}</NativeSelect></label>
            </div>
            <div>
              <p className="mb-2 text-sm text-muted-foreground">Personality</p>
              <div className="space-y-3">
                {PERSONALITY.map((t) => (
                  <div key={t.id} className="grid grid-cols-[110px_1fr_32px] items-center gap-3 text-sm"><span>{t.name}</span>
                    <Slider value={[d.personality[t.id]]} min={5} max={95} step={1} onValueChange={([v]) => up({ personality: { ...d.personality, [t.id]: v } })} /><span className="font-mono text-muted-foreground">{d.personality[t.id]}</span></div>
                ))}
              </div>
            </div>
          </div>
        </Panel>
        <div className="space-y-4">
          <Panel title="Your inherited start">
            <div className="flex gap-4">
              <Portrait p={preview} age={0} size={96} />
              <div className="text-sm text-muted-foreground">
                <p className="text-base text-foreground">{preview.genes.height}cm potential height</p>
                <p>{ap.eye} eyes · {ap.hair} {ap.texture} hair · {ap.tone} skin</p>
                <p>Family wealth: {["struggling", "modest", "comfortable", "wealthy", "elite"][preview.family.tier]}</p>
                <p>Born {MONTHS[d.month - 1]} {d.day} · {preview.birth.zodiac}</p>
              </div>
            </div>
          </Panel>
          <Panel title="Your family">
            <div className="space-y-2">
              {preview.rels.map((r) => (
                <div key={r.id} className="flex items-center justify-between gap-3 text-base"><span><span className="text-muted-foreground">{npcLabel(r)}:</span> {nameOf(r, d.country)}</span><span className="text-sm text-muted-foreground">{r.age >= 18 ? r.occupation : `age ${r.age}`}</span></div>
              ))}
            </div>
          </Panel>
          <Button type="button" onClick={() => onStart(d, preview)} className="h-14 w-full text-lg font-semibold"><Play className="size-5" /> Be born</Button>
        </div>
      </div>
    </div>
  );
}
