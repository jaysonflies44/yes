import { Award } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useG, Panel, Bar, Pill, Money } from "./kit.jsx";
import { ProgrammeBrowser } from "./Programmes.jsx";
import { applyToProgramme, dropOut } from "../engine/sim.js";
import { EDU_LEVELS, countryOf } from "../engine/data.js";

export function EducationPage() {
  const { s, act, toast } = useG();
  const cur = s.edu.current; const c = countryOf(s.country);
  const apply = (edu, inst, sch) => act((n) => applyToProgramme(n, edu.id, inst?.id, sch?.id));
  return (
    <div className="space-y-4">
      <Panel title="Education">
        <div className="grid grid-cols-3 gap-3 text-center">
          <div><p className="font-display text-2xl font-bold">{EDU_LEVELS[s.edu.level].split(" ")[0]}</p><p className="text-sm text-muted-foreground">highest level</p></div>
          <div><p className="font-display text-2xl font-bold">{s.edu.done.filter((d) => d.level >= 3).length}</p><p className="text-sm text-muted-foreground">programmes</p></div>
          <div><p className="font-display text-2xl font-bold">{s.edu.certs.length}</p><p className="text-sm text-muted-foreground">licences and certificates</p></div>
        </div>
        {s.edu.inSchool && <p className="mt-4 rounded-lg bg-info/10 p-3 text-base text-info">You're in compulsory school ({c.name}: ages {c.schoolStart} to {c.secEnd - 1}). GPA this year: {s.edu.schoolGpa.toFixed(2)}. University and college applications open at {c.secEnd}; trade schools take students from {c.secEnd - 2}.</p>}
      </Panel>
      {cur && (
        <Panel title="Currently enrolled" className="border-primary/40">
          <p className="font-display text-xl font-semibold">{cur.name}</p>
          <p className="text-sm text-muted-foreground">{cur.instName}{cur.schName ? ` · ${cur.schName}` : ""}</p>
          <div className="my-3"><Bar value={cur.done} max={cur.years} tone="primary" h="h-3" /><p className="mt-1 text-sm text-muted-foreground">Year {cur.done}/{cur.years} · GPA {cur.gpaHist.length ? cur.gpa.toFixed(2) : "–"} (need {cur.gpaReq}) · tuition <Money usd={cur.tuition} />/yr</p></div>
          <Button type="button" variant="outline" onClick={() => { act((n) => dropOut(n)); toast("You dropped out."); }}>Drop out</Button>
        </Panel>
      )}
      <Panel title="Schools and programmes">
        <ProgrammeBrowser onApply={apply} />
        <p className="mt-3 text-sm text-muted-foreground">Each type of school has its own entry qualification. Missed out? You can reapply the next year, or try another school.</p>
      </Panel>
      {s.edu.done.length > 0 && (
        <Panel title="Qualifications earned">
          <ul className="space-y-2">{s.edu.done.map((d, i) => <li key={i} className="flex items-center justify-between gap-2 text-base"><span><Award className="mr-2 inline size-4 text-primary" />{d.name}{d.inst ? ` · ${d.inst}` : ""}</span><span className="font-mono text-sm text-muted-foreground">{d.year} · GPA {d.gpa?.toFixed?.(2)}</span></li>)}</ul>
          {s.edu.certs.length > 0 && <div className="mt-3 flex flex-wrap gap-2">{s.edu.certs.map((c2) => <Pill key={c2} tone="info">{c2}</Pill>)}</div>}
        </Panel>
      )}
    </div>
  );
}
