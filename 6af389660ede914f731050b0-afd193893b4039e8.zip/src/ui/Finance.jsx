import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useG, Panel, Pill, Money, Empty } from "./kit.jsx";
import { HOUSING, countryOf, fmtMoney } from "../engine/data.js";
import { netWorth, annualExpenses, setHousing, takeLoan, repay, sellAsset, closeBusiness } from "../engine/sim.js";
import { cn } from "@/lib/utils";

function Spark({ data }) {
  if (!data || data.length < 2) return <p className="text-sm text-muted-foreground">Your net worth chart appears after a few years.</p>;
  const vs = data.map((d) => d.v), mn = Math.min(0, ...vs), mx = Math.max(1, ...vs); const W = 300, H = 70;
  const pts = data.map((d, i) => `${(i / (data.length - 1)) * W},${H - ((d.v - mn) / (mx - mn || 1)) * (H - 6) - 3}`).join(" ");
  return <svg viewBox={`0 0 ${W} ${H}`} className="h-20 w-full" preserveAspectRatio="none"><polyline points={pts} fill="none" stroke="var(--color-primary)" strokeWidth="2.5" vectorEffect="non-scaling-stroke" strokeLinejoin="round" /></svg>;
}
export function FinancePage() {
  const { s, act, toast, setWarn } = useG(); const c = countryOf(s.country);
  const [amt, setAmt] = useState(1000);
  const exp = annualExpenses(s); const nw = netWorth(s); const ym = s.yearMoney;
  const house = (id) => { const r = act((n) => setHousing(n, id)); if (r.error) setWarn({ title: "Can't move", message: r.error }); else toast.success("Housing updated"); };
  const loan = () => { const r = act((n) => takeLoan(n, amt / c.rate)); r.error ? setWarn({ title: "Loan declined", message: r.error }) : toast("Loan approved"); };
  const pay = () => { const r = act((n) => repay(n, amt / c.rate)); r.error ? setWarn({ title: "Can't repay", message: r.error }) : toast.success("Repaid"); };
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-3">
        {[["Cash", s.money.cash, ""], ["Debt", s.money.debt, "text-bad"], ["Net worth", nw, nw < 0 ? "text-bad" : "text-primary"]].map(([l, v, cl]) => <div key={l} className="rounded-xl border border-border bg-card p-4"><p className="text-sm text-muted-foreground">{l}</p><p className={cn("font-display text-xl font-bold @md:text-3xl", cl)}><Money usd={v} /></p></div>)}
      </div>
      <Panel title="Net worth over your life"><Spark data={s.nw} /></Panel>
      <Panel title={`Money in ${c.name}`}>
        <div className="grid gap-2 text-base @xl:grid-cols-2">
          <p className="flex justify-between"><span className="text-muted-foreground">Currency</span><span>{c.cur} ({c.sym})</span></p>
          <p className="flex justify-between"><span className="text-muted-foreground">Wage level vs US</span><span>{Math.round(c.wage * 100)}%</span></p>
          <p className="flex justify-between"><span className="text-muted-foreground">Cost of living</span><span>{Math.round(c.col * 100)}%</span></p>
          <p className="flex justify-between"><span className="text-muted-foreground">Income tax (avg)</span><span>{Math.round(c.tax * 100)}%</span></p>
          <p className="flex justify-between"><span className="text-muted-foreground">Healthcare</span><span className="capitalize">{c.health}</span></p>
          <p className="flex justify-between"><span className="text-muted-foreground">Tuition level</span><span>{Math.round(c.tui * 100)}%</span></p>
        </div>
        {s.age < 14 && <p className="mt-4 rounded-lg bg-foreground/5 p-3 text-base text-muted-foreground">Your parents cover everything while you are young. You only get a little pocket money.</p>}
        {ym && s.age >= 14 && <div className="mt-4 rounded-lg bg-foreground/5 p-3 text-base"><p className="mb-2 text-sm text-muted-foreground">Last year</p><p className="flex justify-between"><span>Income</span><Money usd={ym.income} /></p><p className="flex justify-between"><span>Tax</span><Money usd={-ym.tax} /></p><p className="flex justify-between"><span>Living, housing, health</span><Money usd={-ym.expenses} /></p><p className="mt-1 flex justify-between border-t border-border pt-1 font-medium"><span>Net</span><Money usd={ym.net} className={ym.net < 0 ? "text-bad" : "text-good"} /></p></div>}
      </Panel>
      <Panel title="Housing" action={<Pill>{HOUSING.find((h) => h.id === s.housing.id).name}</Pill>}>
        <div className="grid gap-2 @2xl:grid-cols-2">
          {HOUSING.map((h) => (
            <button key={h.id} type="button" disabled={h.id === s.housing.id} onClick={() => house(h.id)} className={cn("rounded-xl border p-3 text-left disabled:opacity-100", h.id === s.housing.id ? "border-primary bg-primary/10" : "border-border hover:border-primary")}>
              <p className="text-base font-medium">{h.name}</p><p className="text-sm text-muted-foreground">{h.buy ? <>Price <Money usd={h.buy * c.col} /> (20% down)</> : h.rent ? <><Money usd={h.rent * c.col} />/yr rent</> : "Free"}{h.minAge ? ` · age ${h.minAge}+` : ""}</p>
            </button>
          ))}
        </div>
        {s.housing.value > 0 && <p className="mt-3 text-sm text-muted-foreground">Home value <Money usd={s.housing.value} /> · mortgage left <Money usd={s.housing.loan} /></p>}
      </Panel>
      <Panel title="Loans">
        <div className="flex gap-2"><Input type="number" value={amt} onChange={(e) => setAmt(Math.max(0, +e.target.value))} className="h-12 flex-1 text-base" aria-label={`Amount in ${c.cur}`} /><Button type="button" onClick={loan} className="h-12">Borrow</Button><Button type="button" variant="outline" onClick={pay} className="h-12">Repay</Button></div>
        <p className="mt-2 text-sm text-muted-foreground">Amount in {c.cur}. Debt costs 8% interest a year and drags happiness.</p>
      </Panel>
      {s.business && <Panel title="Your business"><p className="font-display text-xl font-bold">{s.business.name}</p><p className="text-sm text-muted-foreground">Invested <Money usd={s.business.invested} /> · {s.business.years} yr · last year <Money usd={s.business.last} className={s.business.last < 0 ? "text-bad" : "text-good"} /></p><Button type="button" variant="outline" className="mt-3" onClick={() => act((n) => closeBusiness(n))}>Sell / close</Button></Panel>}
      <Panel title="Assets">{s.assets.length === 0 ? <Empty>No assets. Try “buy a car” on Home.</Empty> : <ul className="space-y-2">{s.assets.map((a) => <li key={a.id} className="flex items-center justify-between gap-2 rounded-lg border border-border p-3"><span className="text-base">{a.name}<span className="block text-sm text-muted-foreground">loses {Math.round(a.dep * 100)}% a year</span></span><span className="flex items-center gap-2"><Money usd={a.value} /><Button type="button" size="sm" variant="outline" onClick={() => act((n) => sellAsset(n, a.id))}>Sell</Button></span></li>)}</ul>}</Panel>
      <p className="text-center text-sm text-muted-foreground">Yearly baseline costs about <Money usd={exp} />.</p>
    </div>
  );
}
