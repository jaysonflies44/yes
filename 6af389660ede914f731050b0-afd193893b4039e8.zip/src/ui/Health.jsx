import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Button } from "@/components/ui/button";
import { useG, Panel, Bar, Pill, Empty, STAT_TONE, Money, FxLines } from "./kit.jsx";
import { DoctorPanel } from "./Special.jsx";
import { visitDoctor, therapy, treatNamed, checkupCost, therapyCost, parentsLive } from "../engine/sim.js";
import { illnessOf } from "../engine/health.js";
import { fmtMoney, countryOf } from "../engine/data.js";

export function HealthPage() {
  const { s, act, toast, setWarn } = useG(); const c = countryOf(s.country);
  const [treat, setTreat] = useState(null); const [result, setResult] = useState(null);
  const dep = parentsLive(s);
  const set = (k, v) => v !== "" && v != null && act((n) => { n.lifestyle[k] = +v; });
  const run = (fn, ok) => { const r = act((n) => fn(n)); r.error === "parents" ? setWarn({ title: "Your parents said no", message: r.message }) : r.error ? setWarn({ title: "You can't afford it", message: `That costs ${fmtMoney(r.need, s.country)} and you have ${fmtMoney(s.money.cash, s.country)}.` }) : toast.success(ok); };
  const choose = (optId) => {
    const name = treat.name;
    const r = act((n) => treatNamed(n, name, optId));
    if (r.error === "afford") { setTreat(null); return setWarn({ title: "You can't afford that", message: `That costs ${fmtMoney(r.need, s.country)} and you have ${fmtMoney(s.money.cash, s.country)}. Try a cheaper option or rest at home.` }); }
    if (r.error === "parents") { setTreat(null); return setWarn({ title: "Your parents said no", message: "They can't pay for that right now. Try a cheaper option." }); }
    if (r.error) return setTreat(null);
    setResult({ text: r.text, lines: r.lines });
  };
  const close = () => { setTreat(null); setResult(null); };
  const ls = [["diet", "Diet", ["Junk", "Normal", "Clean"]], ["exercise", "Exercise", ["Couch", "Regular", "Intense"]], ["sleep", "Sleep", ["Poor", "Okay", "Great"]]];
  const live = treat ? s.conditions.find((k) => k.name === treat.name) : null;
  return (
    <div className="space-y-4">
      <Panel title="Body and mind">
        <div className="space-y-4">{[["health", "Health"], ["fitness", "Fitness"], ["stress", "Stress"], ["happiness", "Happiness"]].map(([k, l]) => <div key={k}><div className="mb-1 flex justify-between text-sm"><span>{l}</span><span className="font-mono text-muted-foreground">{Math.round(s.stats[k])}</span></div><Bar value={s.stats[k]} tone={STAT_TONE[k]} h="h-3" /></div>)}</div>
        <p className="mt-4 text-sm text-muted-foreground">Healthcare in {c.name} is {c.health === "universal" ? "mostly state-funded" : c.health === "mixed" ? "a public/private mix" : "largely private, so treatment costs real money"}. Genetic longevity: {s.genes.longevity}/100.</p>
      </Panel>
      <Panel title="Conditions">
        {s.conditions.length === 0 ? <Empty>No active conditions. Nice.</Empty> : (
          <ul className="space-y-2">{s.conditions.map((k) => { const ill = illnessOf(k); return (
            <li key={k.name} className="rounded-lg border border-border p-3 text-base">
              <div className="flex items-center justify-between gap-2"><span>{k.name}<span className="block text-sm text-muted-foreground">since age {k.since}{k.managed ? " · being managed" : ""}</span></span><span className="flex gap-2"><Pill tone={k.chronic ? "warn" : "info"}>{k.chronic ? "long-term" : "treatable"}</Pill><Pill tone={k.sev >= 2 ? "bad" : "muted"}>severity {k.sev}</Pill></span></div>
              {ill?.desc && <p className="mt-1 text-sm text-muted-foreground">{ill.desc}</p>}
              <Button type="button" size="sm" className="mt-2" onClick={() => { setResult(null); setTreat(k); }}>{dep ? "See a doctor (parents pay)" : "Get treatment"}</Button>
            </li>); })}</ul>
        )}
      </Panel>
      <Panel title="Lifestyle (applies every year)">
        <div className="space-y-4">{ls.map(([k, l, opts]) => <div key={k}><p className="mb-2 text-sm text-muted-foreground">{l}</p><ToggleGroup type="single" value={String(s.lifestyle[k])} onValueChange={(v) => set(k, v)} variant="outline" className="w-full">{opts.map((o, i) => <ToggleGroupItem key={o} value={String(i)} className="h-11 flex-1">{o}</ToggleGroupItem>)}</ToggleGroup></div>)}</div>
      </Panel>
      <Panel title="Care">
        <div className="grid gap-2 @xl:grid-cols-2"><Button type="button" onClick={() => run(visitDoctor, "Check-up done")} className="h-12" variant="secondary">Routine check-up {dep ? <span className="opacity-70">(parents)</span> : <Money usd={checkupCost(s)} className="opacity-70" />}</Button><Button type="button" onClick={() => run(therapy, "Therapy helped")} className="h-12" variant="secondary">Therapy session {dep ? <span className="opacity-70">(parents)</span> : <Money usd={therapyCost(s)} className="opacity-70" />}</Button></div>
      </Panel>
      <Dialog open={!!treat} onOpenChange={(o) => !o && close()}>
        <DialogContent className="max-h-[90vh] max-w-lg overflow-y-auto">
          <DialogHeader><DialogTitle className="font-display text-2xl">Treatment</DialogTitle><DialogDescription className="text-base">Pick how you want to deal with it.</DialogDescription></DialogHeader>
          {result ? (
            <div className="space-y-3 rounded-xl border border-primary/30 bg-primary/5 p-4"><p className="text-base">{result.text}</p><FxLines lines={result.lines} /><Button type="button" className="h-12 w-full text-base" onClick={close}>Done</Button></div>
          ) : live ? <DoctorPanel cond={live} onChoose={choose} /> : null}
        </DialogContent>
      </Dialog>
    </div>
  );
}
