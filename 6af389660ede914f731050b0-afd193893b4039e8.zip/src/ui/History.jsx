import { useState } from "react";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { useG, Panel, Empty } from "./kit.jsx";
import { cn } from "@/lib/utils";

const TYPES = [["all", "All"], ["education", "Education"], ["career", "Career"], ["relationship", "People"], ["finance", "Money"], ["prompt", "Outings"], ["event", "Events"], ["activity", "Hobbies"], ["sport", "Sport"], ["health", "Health"]];
export function HistoryPage() {
  const { s } = useG(); const [f, setF] = useState("all");
  const rows = s.log.filter((l) => f === "all" || l.type === f).slice().reverse();
  const byAge = rows.reduce((m, l) => { (m[l.age] ||= []).push(l); return m; }, {});
  return (
    <div className="space-y-4">
      {s.memory.key.length > 0 && <Panel title="Key moments"><ul className="space-y-1 text-base">{s.memory.key.slice(-6).reverse().map((m, i) => <li key={i}><span className="font-mono text-sm text-muted-foreground">age {m.age}</span> {m.text}</li>)}</ul></Panel>}
      <Panel title="Life log">
        <ToggleGroup type="single" value={f} onValueChange={(v) => v && setF(v)} variant="outline" className="mb-4 flex-wrap justify-start">{TYPES.map(([v, l]) => <ToggleGroupItem key={v} value={v} className="h-9 px-3">{l}</ToggleGroupItem>)}</ToggleGroup>
        {rows.length === 0 ? <Empty>No entries.</Empty> : (
          <div className="space-y-5">{Object.entries(byAge).sort((a, b) => b[0] - a[0]).map(([age, list]) => (
            <div key={age} className="grid grid-cols-[48px_1fr] gap-3"><p className="font-display text-2xl font-bold text-primary">{age}</p>
              <ul className="space-y-2 border-l border-border pl-4">{list.map((l, i) => <li key={i} className={cn("text-base", l.tone === "bad" ? "text-bad" : l.tone === "good" ? "text-foreground" : "text-foreground/70")}>{l.text}</li>)}</ul></div>
          ))}</div>
        )}
      </Panel>
    </div>
  );
}
