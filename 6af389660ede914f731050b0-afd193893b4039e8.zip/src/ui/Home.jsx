import { useEffect, useRef, useState } from "react";
import { Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select";
import { useG, Bar, Panel, STAT_TONE, Pill, Empty } from "./kit.jsx";
import { Input } from "@/components/ui/input";
import { listIntents } from "../engine/events.js";
import { STATS, LIFE_STAGE, STAGE_HUE, countryOf, fmtMoney, ZODIAC } from "../engine/data.js";
import { QUICK, doQuick } from "../engine/sim.js";
import { ACADEMIC } from "../engine/char.js";
import { skillName } from "../engine/rules.js";
import { cn } from "@/lib/utils";

export function Ribbon({ age }) {
  const ref = useRef(null);
  useEffect(() => { const el = ref.current; if (el) el.scrollTo({ left: Math.max(0, age * 12 - el.clientWidth / 2), behavior: "smooth" }); }, [age]);
  return (
    <div ref={ref} className="overflow-x-auto pb-1 [scrollbar-width:none]" aria-label="Life ribbon">
      <div className="flex h-14 items-end gap-[4px]" style={{ width: 101 * 12 }}>
        {Array.from({ length: 101 }, (_, i) => {
          const lit = i <= age, now = i === age;
          return <div key={i} title={`Age ${i}`} className={cn("relative w-2 shrink-0 rounded-t-sm transition-all duration-500", now && "animate-pulse")} style={{ height: now ? 56 : i % 10 === 0 ? 34 : i % 5 === 0 ? 26 : 18, background: now ? "var(--color-primary)" : lit ? `oklch(0.72 0.14 ${STAGE_HUE(i)})` : "color-mix(in oklch, var(--color-foreground) 12%, transparent)" }}>{i % 10 === 0 && <span className="absolute -bottom-5 left-0 font-mono text-[11px] text-muted-foreground">{i}</span>}</div>;
        })}
      </div>
    </div>
  );
}

export function HomePage() {
  const { s, act, submitPrompt, go } = useG();
  const [find, setFind] = useState("");
  const [picks, setPicks] = useState({});
  const [last, setLast] = useState(null);
  const run = (id) => { const r = act((n) => doQuick(n, id, picks[id])); if (r.error) return setLast({ tone: "bad", text: r.error }); setLast({ tone: "good", text: QUICK.find((q) => q.id === id).label, lines: r.lines }); };
  const used = (id) => s.quick[id] || 0;
  const ideas = listIntents(s).filter((i) => !find || i.label.toLowerCase().includes(find.toLowerCase()));
  return (
    <div className="space-y-4">
      <section className="relative overflow-hidden rounded-2xl border border-border bg-card p-4 @xl:p-6">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="font-mono text-sm uppercase tracking-widest text-muted-foreground">{LIFE_STAGE(s.age)} · {s.year}</p>
            <p className="font-display text-[88px] font-bold leading-[0.82] tracking-tighter text-primary @xl:text-[128px]">{s.age}</p>
          </div>
          <div className="pb-2 text-right text-sm text-muted-foreground"><p>{s.birth.zodiac}</p><p>{s.height ?? "–"} cm</p><p>{s.job ? s.job.title : s.edu.current ? "Student" : s.retired ? "Retired" : s.edu.inSchool ? "At school" : "Unemployed"}</p></div>
        </div>
        <div className="mt-4 pb-5"><Ribbon age={s.age} /></div>
      </section>

      {s.pending.length > 0 && (
        <button type="button" onClick={() => window.dispatchEvent(new Event("open-events"))} className="flex w-full items-center justify-between rounded-xl border border-bad/40 bg-bad/10 p-4 text-left">
          <span className="text-base font-medium"><Zap className="mr-2 inline size-4 text-bad" />{s.pending.length} event{s.pending.length > 1 ? "s" : ""} waiting for a decision</span>
          <Pill tone="primary">Open</Pill>
        </button>
      )}

      <Panel title="Do something this year" action={<span className="flex gap-1" aria-label={`${s.prompts} outings left`}>{Array.from({ length: 5 }, (_, i) => <span key={i} className={cn("size-3 rounded-full", i < s.prompts ? "bg-primary" : "bg-foreground/15")} />)}</span>}>
        {s.age < 2 ? <Empty>You're a baby. Your family makes the plans for now. Age up!</Empty> : (
          <div className="space-y-3">
            <Input value={find} onChange={(e) => setFind(e.target.value)} placeholder="Search ideas…" className="h-11 text-base" aria-label="Search ideas" />
            <div className="flex max-h-56 flex-wrap gap-2 overflow-y-auto">
              {ideas.length === 0 ? <p className="text-sm text-muted-foreground">Nothing matches that.</p> : ideas.map((i) => <button key={i.id} type="button" onClick={() => submitPrompt(i.id)} className="rounded-full border border-border px-3 py-2 text-sm transition-colors hover:border-primary hover:text-primary">{i.label}</button>)}
            </div>
            <p className="text-sm text-muted-foreground">Each outing becomes a short scene with choices. {s.age < 18 ? "Anything that costs money is something you ask your parents for." : "Anything with a price needs cash in your pocket."}</p>
          </div>
        )}
      </Panel>

      <Panel title="This year">
        {s.feed.length === 0 ? <Empty>Nothing yet. Age up to start living.</Empty> : (
          <ul className="space-y-2">
            {s.feed.map((f, i) => <li key={i} className="flex gap-3 text-base"><span className={cn("mt-2 size-2 shrink-0 rounded-full", f.tone === "good" ? "bg-good" : f.tone === "bad" ? "bg-bad" : f.tone === "warn" ? "bg-warn" : "bg-foreground/30")} /><span className="text-foreground/90">{f.text}</span></li>)}
          </ul>
        )}
      </Panel>

      <div className="grid gap-4 @2xl:grid-cols-2">
        <Panel title="Vitals">
          <div className="space-y-3">
            {STATS.map((st) => (
              <div key={st.id}>
                <div className="mb-1 flex justify-between text-sm"><span>{st.name}</span><span className="font-mono text-muted-foreground">{Math.round(s.stats[st.id])}</span></div>
                <Bar value={s.stats[st.id]} tone={STAT_TONE[st.id]} />
              </div>
            ))}
          </div>
        </Panel>
        <Panel title="Quick actions" action={<span className="text-sm text-muted-foreground">free · limited per year</span>}>
          {s.age < 4 ? <Empty>You're too little for this. Age up.</Empty> : (
            <div className="grid grid-cols-2 gap-2">
              {QUICK.filter((q) => s.age >= q.minAge && (!q.needJob || s.job)).map((q) => (
                <div key={q.id} className={cn("rounded-lg border border-border p-3", used(q.id) >= q.max && "opacity-50")}>
                  <button type="button" disabled={used(q.id) >= q.max} onClick={() => run(q.id)} className="w-full text-left"><p className="text-base font-medium">{q.label}</p><p className="text-sm text-muted-foreground">{q.desc}</p></button>
                  {q.pick && <NativeSelect value={picks[q.id] || q.pick[0]} onChange={(e) => setPicks({ ...picks, [q.id]: e.target.value })} className="mt-2 w-full">{q.pick.map((k) => <NativeSelectOption key={k} value={k}>{skillName(k)}</NativeSelectOption>)}</NativeSelect>}
                  <p className="mt-1 font-mono text-sm text-muted-foreground">{q.max - used(q.id)}/{q.max} left</p>
                </div>
              ))}
            </div>
          )}
          {last && <div className={cn("mt-3 rounded-lg p-3 text-sm", last.tone === "bad" ? "bg-bad/10 text-bad" : "bg-good/10 text-good")}>{last.text}{last.lines && ": " + last.lines.map((l) => l.text).join(", ")}</div>}
        </Panel>
      </div>
    </div>
  );
}
