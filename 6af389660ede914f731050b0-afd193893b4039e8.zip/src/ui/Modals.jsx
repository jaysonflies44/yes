import { useState, useEffect } from "react";
import { AlertTriangle, Skull, Sparkles, ArrowRight, Lock } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useG, ReqList, FxLines, Money, Portrait, Pill } from "./kit.jsx";
import { checkReq } from "../engine/rules.js";
import { resolveChoice, resolveSpecial, skipEvent, parentsLive } from "../engine/sim.js";
import { DoctorPanel, JobOfferPanel, UniversityPanel, eventCondition } from "./Special.jsx";
import { netWorth } from "../engine/sim.js";
import { fmtMoney, nameOf, countryOf } from "../engine/data.js";

export function WarnModal({ warn, close }) {
  return (
    <Dialog open={!!warn} onOpenChange={(o) => !o && close()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <div className="mb-2 flex size-12 items-center justify-center rounded-full bg-warn/15 text-warn"><AlertTriangle className="size-6" /></div>
          <DialogTitle className="font-display text-xl">{warn?.title}</DialogTitle>
          <DialogDescription className="text-base text-foreground/80">{warn?.message}</DialogDescription>
        </DialogHeader>
        {warn?.items && <ReqList items={warn.items} />}
        <Button type="button" onClick={close} className="mt-2 h-12 w-full text-base">Got it</Button>
      </DialogContent>
    </Dialog>
  );
}

export function EventModal() {
  const { s, act, setWarn } = useG();
  const [shown, setShown] = useState(null); // {ev, res}
  const ev = shown ? shown.ev : s.pending[0];
  const [closed, setClosed] = useState(false);
  useEffect(() => { const f = () => setClosed(false); window.addEventListener("open-events", f); return () => window.removeEventListener("open-events", f); }, []);
  const open = !!ev && !closed && s.alive;
  const dependent = parentsLive(s);
  // One entry point for every kind of event: plain choices (index) and special windows (payload object).
  const resolve = (payload) => {
    const cur = s.pending[0];
    const out = act((n) => {
      const e = n.pending[0];
      const r = e.ui ? resolveSpecial(n, e, payload) : resolveChoice(n, e, payload);
      if (r.error === "afford") { skipEvent(n, e, "you couldn't afford it, so it passed you by."); return r; }
      if (r.error) return r;
      if (!r.keepOpen) { n.pending.shift(); if (r.next) n.pending.unshift(r.next); }
      return r;
    });
    if (out.error === "afford") { setShown(null); return setWarn({ title: "You can't afford that", message: `That costs ${fmtMoney(out.need, s.country)} but you only have ${fmtMoney(s.money.cash, s.country)}. The moment passes and life carries on without it.` }); }
    if (out.error === "req") return setWarn({ title: "You don't qualify", message: "You don't meet the requirements for that choice.", items: out.items });
    if (out.error) return out;
    if (out.keepOpen) return out;
    setShown({ ev: cur, res: out });
    return out;
  };
  const cont = () => { setShown(null); setClosed(false); };
  const tag = ev?.ui === "doctor" ? "Health" : ev?.ui === "job_offer" ? "Job offer" : ev?.ui === "university" ? "Education" : ev?.category === "prompt" ? "Your idea" : ev?.category === "callback" ? "Callback" : ev?.category === "chain" ? "Follow-up" : "Life event";
  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) { shown ? cont() : setClosed(true); } }}>
      <DialogContent className="max-h-[90vh] max-w-lg overflow-y-auto">
        {ev && (
          <>
            <DialogHeader>
              <div className="flex items-center gap-2"><Pill tone="primary">{tag}</Pill>{!shown && s.pending.length > 1 && <Pill>{s.pending.length - 1} more waiting</Pill>}</div>
              <DialogTitle className="mt-2 font-display text-2xl leading-tight">{ev.title}</DialogTitle>
              <DialogDescription className="text-base leading-relaxed text-foreground/85">{ev.text}</DialogDescription>
            </DialogHeader>
            {shown ? (
              <div className="space-y-3 rounded-xl border border-primary/30 bg-primary/5 p-4">
                <p className="text-sm text-muted-foreground">You chose: {shown.res.label}</p>
                <p className="text-base">{shown.res.text}</p>
                <FxLines lines={shown.res.lines} />
                <Button type="button" onClick={cont} className="h-12 w-full text-base">{shown.res.next ? "Something else happens" : s.pending.length ? "Next event" : "Continue"} <ArrowRight className="size-4" /></Button>
              </div>
            ) : ev.ui === "doctor" ? (
              <DoctorPanel cond={eventCondition(ev)} onChoose={(opt) => resolve({ opt })} />
            ) : ev.ui === "job_offer" ? (
              <JobOfferPanel offer={ev.offer} onAnswer={(accept) => resolve({ accept })} />
            ) : ev.ui === "university" ? (
              <UniversityPanel ev={ev} onSkip={() => resolve({ skip: true })} onApply={(edu, inst, sch) => resolve({ eduId: edu.id, instId: inst?.id, schId: sch?.id })} />
            ) : (
              <div className="space-y-2">
                {ev.choices.map((c, i) => {
                  const rq = c.requirements ? checkReq(s, c.requirements) : null; const locked = rq && !rq.ok; const poor = !dependent && (c.cost || 0) > s.money.cash;
                  return (
                    <button key={i} type="button" onClick={() => resolve(i)} className="group flex w-full items-center justify-between gap-3 rounded-xl border border-border bg-card p-4 text-left transition-colors hover:border-primary hover:bg-primary/5">
                      <span className="text-base font-medium">{c.label}</span>
                      <span className="flex shrink-0 items-center gap-2">
                        {locked && <Lock className="size-4 text-bad" />}
                        {c.cost > 0 && <span className={`text-right font-mono text-sm ${poor ? "text-bad" : "text-muted-foreground"}`}>{dependent ? <>Ask parents<span className="block text-xs">≈ {fmtMoney(c.cost, s.country)}</span></> : fmtMoney(c.cost, s.country)}</span>}
                      </span>
                    </button>
                  );
                })}
                <button type="button" onClick={() => setClosed(true)} className="w-full py-2 text-sm text-muted-foreground hover:text-foreground">Decide later</button>
              </div>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

export function DeathModal({ onNew }) {
  const { s } = useG();
  const kids = s.rels.filter((r) => r.role === "child").length;
  const best = s.edu.done.filter((d) => d.level >= 3).sort((a, b) => b.level - a.level)[0];
  const rows = [["Net worth", fmtMoney(netWorth(s), s.country)], ["Lifetime earnings", fmtMoney(s.lifetimeEarn, s.country, { compact: true })], ["Education", best ? best.name : s.edu.level >= 2 ? "High school" : "Early years"], ["Career", s.jobHistory.length ? `${s.jobHistory.length} job${s.jobHistory.length > 1 ? "s" : ""}, last: ${s.jobHistory[s.jobHistory.length - 1].title}` : "None"], ["Children", kids], ["Sport awards", s.sport.awards.length]];
  return (
    <Dialog open={!s.alive}>
      <DialogContent className="max-h-[92vh] max-w-lg overflow-y-auto" onInteractOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <div className="mx-auto mb-2 flex size-14 items-center justify-center rounded-full bg-foreground/10"><Skull className="size-7" /></div>
          <DialogTitle className="text-center font-display text-3xl">{nameOf(s)}</DialogTitle>
          <DialogDescription className="text-center text-base">Died at {s.age} from {s.cause}. Born in {s.hometown}, {countryOf(s.country).name}.</DialogDescription>
        </DialogHeader>
        <dl className="divide-y divide-border rounded-xl border border-border">
          {rows.map(([k, v]) => <div key={k} className="flex justify-between gap-4 px-4 py-3 text-base"><dt className="text-muted-foreground">{k}</dt><dd className="text-right font-medium">{v}</dd></div>)}
        </dl>
        <p className="text-center text-sm text-muted-foreground">Your next life starts fresh, with the same world waiting.</p>
        <Button type="button" onClick={onNew} className="h-12 text-base"><Sparkles className="size-4" /> Begin a new life</Button>
      </DialogContent>
    </Dialog>
  );
}
