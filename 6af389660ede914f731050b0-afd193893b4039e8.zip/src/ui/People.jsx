import { useState } from "react";
import { Heart } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useG, Panel, Bar, Pill, Empty, Portrait } from "./kit.jsx";
import { npcLabel } from "../engine/char.js";
import { REL_ACTIONS, relAction } from "../engine/sim.js";
import { PERSONALITY, nameOf, eyeColor, hairColor } from "../engine/data.js";

const GROUPS = [["Family", ["mother", "father", "sibling", "child"]], ["Partner", ["partner", "spouse"]], ["Friends", ["friend", "classmate"]], ["Work", ["coworker"]], ["Exes", ["ex"]]];
export function PeoplePage() {
  const { s } = useG(); const [sel, setSel] = useState(null);
  const person = sel ? s.rels.find((r) => r.id === sel) : null;
  const live = s.rels.filter((r) => r.status !== "estranged");
  return (
    <div className="space-y-4">
      <Panel><p className="text-base text-muted-foreground">You have <b className="text-foreground">{s.rels.filter((r) => r.alive && r.status !== "estranged").length}</b> people in your life. They age, work, fall in love and die whether you call or not. Relationships drift when ignored. <span className="font-mono">{Math.max(0, 6 - (s.quick._rel || 0))}</span> interactions left this year.</p></Panel>
      {GROUPS.map(([label, roles]) => {
        const list = live.filter((r) => roles.includes(r.role)); if (!list.length) return null;
        return (
          <Panel key={label} title={label}>
            <div className="grid gap-2 @2xl:grid-cols-2">
              {list.map((r) => (
                <button key={r.id} type="button" onClick={() => setSel(r.id)} className={`flex items-center gap-3 rounded-xl border border-border p-3 text-left transition-colors hover:border-primary ${r.alive ? "" : "opacity-50"}`}>
                  <Portrait p={r} age={r.age} size={48} />
                  <div className="min-w-0 flex-1"><p className="truncate text-base font-medium">{nameOf(r, s.country)}</p><p className="truncate text-sm text-muted-foreground">{npcLabel(r)} · {r.alive ? `${r.age}` : "deceased"} · {r.occupation}</p><Bar value={r.affection} tone={r.affection > 60 ? "good" : r.affection > 30 ? "warn" : "bad"} h="h-1.5" className="mt-2" /></div>
                </button>
              ))}
            </div>
          </Panel>
        );
      })}
      <Sheet open={!!person} onOpenChange={(o) => !o && setSel(null)}>
        <SheetContent side="right" className="w-full overflow-y-auto sm:max-w-md">
          {person && <PersonView r={person} />}
        </SheetContent>
      </Sheet>
    </div>
  );
}
function PersonView({ r }) {
  const { s, act, toast } = useG();
  const [msg, setMsg] = useState(null);
  const run = (a) => { const res = act((n) => relAction(n, r.id, a)); if (res?.error) setMsg({ tone: "bad", text: res.error }); else { setMsg(res); if (res.tone === "good") toast.success(res.text); else toast(res.text); } };
  const acts = REL_ACTIONS.filter((a) => (a.roles === "all" || a.roles.includes(r.role)) && r.alive);
  return (
    <>
      <SheetHeader>
        <div className="flex items-center gap-3"><Portrait p={r} age={r.age} size={64} /><div><SheetTitle className="font-display text-2xl">{nameOf(r, s.country)}</SheetTitle><SheetDescription className="text-base">{npcLabel(r)} · {r.alive ? `age ${r.age}` : "passed away"} · {r.occupation}</SheetDescription></div></div>
      </SheetHeader>
      <div className="space-y-5 px-4 pb-8">
        <div className="space-y-3">
          {[["Affection", r.affection, "bloom"], ["Trust", r.trust, "info"], ["Respect", r.respect, "warn"], ["Compatibility", r.compat, "good"]].map(([l, v, t]) => <div key={l}><div className="mb-1 flex justify-between text-sm"><span>{l}</span><span className="font-mono text-muted-foreground">{Math.round(v)}</span></div><Bar value={v} tone={t} /></div>)}
        </div>
        <div className="rounded-lg bg-foreground/5 p-3 text-base"><p className="text-sm text-muted-foreground">Current goal</p>{r.goal}</div>
        <div><p className="mb-2 text-sm text-muted-foreground">Personality</p><div className="flex flex-wrap gap-2">{PERSONALITY.map((t) => <Pill key={t.id}>{r.personality[t.id] > 60 ? "high " : r.personality[t.id] < 40 ? "low " : "mid "}{t.name.toLowerCase()}</Pill>)}</div></div>
        <p className="text-sm text-muted-foreground">{eyeColor(r.genes.eye)} eyes · {hairColor(r.genes.hair)} hair · {r.genes.height} cm adult height. Met at age {r.met}.</p>
        {msg && <div className={`rounded-lg p-3 text-base ${msg.tone === "bad" ? "bg-bad/10 text-bad" : msg.tone === "good" ? "bg-good/10 text-good" : "bg-foreground/10"}`}>{msg.text}</div>}
        <div className="grid grid-cols-2 gap-2">{acts.map((a) => <Button key={a.id} type="button" variant={["breakup", "divorce", "cutoff", "argue"].includes(a.id) ? "outline" : "secondary"} onClick={() => run(a.id)} className="h-12">{a.id === "propose" && <Heart className="size-4" />}{a.label}</Button>)}</div>
      </div>
    </>
  );
}
