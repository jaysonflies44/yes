import { useMemo, useState } from "react";
import { GraduationCap, AlertTriangle } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { useG, ReqList, Pill, Money, Empty } from "./kit.jsx";
import { Catalog } from "../engine/catalog.js";
import { SCHOOL_KINDS, KIND, schoolsFor, scholarshipsFor, schoolKind } from "../engine/content.js";
import { eduEligibility, tuitionFor } from "../engine/sim.js";
import { checkReq } from "../engine/rules.js";
import { SPORTS, countryOf } from "../engine/data.js";
import { cn } from "@/lib/utils";

// Browse schools by type, see each programme's entry qualification, pick a school and apply.
// `onApply(edu, inst, sch)` is supplied by the caller and returns the engine's result ({accepted} | {rejected, text} | {error}).
export function ProgrammeBrowser({ kinds, initial, onApply, onAccepted }) {
  const { s } = useG();
  const list = kinds ? SCHOOL_KINDS.filter((k) => kinds.includes(k.id)) : SCHOOL_KINDS;
  const [kind, setKind] = useState(list.some((k) => k.id === initial) ? initial : list[0].id);
  const [q, setQ] = useState(""); const [onlyOk, setOnlyOk] = useState(false); const [open, setOpen] = useState(null);
  const all = useMemo(() => Catalog.list("education"), []);
  const byKind = useMemo(() => Object.fromEntries(list.map((k) => [k.id, all.filter((e) => schoolsFor(s.country, e).some((i) => i.kind === k.id))])), [s.country]);
  const shown = (byKind[kind] || []).map((e) => ({ e, el: eduEligibility(s, e, null) }))
    .filter(({ e, el }) => (!q || (e.name + " " + e.fieldName).toLowerCase().includes(q.toLowerCase())) && (!onlyOk || el.ok))
    .sort((a, b) => (b.el.ok - a.el.ok) || a.e.name.localeCompare(b.e.name));
  const k = schoolKind(kind);
  return (
    <div className="space-y-3">
      <ToggleGroup type="single" value={kind} onValueChange={(v) => v && setKind(v)} variant="outline" className="flex-wrap justify-start">
        {list.map((x) => <ToggleGroupItem key={x.id} value={x.id} className="h-10 px-3">{x.short} <span className="ml-1 font-mono text-xs text-muted-foreground">{byKind[x.id]?.length ?? 0}</span></ToggleGroupItem>)}
      </ToggleGroup>
      <p className="rounded-lg bg-foreground/5 p-3 text-sm text-muted-foreground"><span className="font-medium text-foreground">{k.label}.</span> {k.blurb}</p>
      <div className="flex items-center gap-3">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search programmes…" className="h-10 flex-1" aria-label="Search programmes" />
        <label className="flex items-center gap-2 text-sm text-muted-foreground"><Switch checked={onlyOk} onCheckedChange={setOnlyOk} />Eligible only</label>
      </div>
      {shown.length === 0 ? <Empty>No programmes match.</Empty> : (
        <div className="grid gap-3 @2xl:grid-cols-2">
          {shown.slice(0, 60).map(({ e, el }) => {
            const miss = el.items.filter((i) => !i.ok);
            return (
              <button key={e.id} type="button" onClick={() => setOpen(e.id)} className="rounded-xl border border-border p-4 text-left transition-colors hover:border-primary">
                <div className="flex items-start justify-between gap-2"><p className="text-base font-semibold leading-snug">{e.name}</p><Pill tone={el.ok ? "good" : "bad"}>{el.ok ? "Eligible" : `${miss.length} missing`}</Pill></div>
                <p className="mt-1 text-sm text-muted-foreground">{KIND[e.kind]} · {e.years} yr{e.years > 1 ? "s" : ""} · from age {el.minAge} · <Money usd={e.tuitionUSD * countryOf(s.country).tui} />/yr</p>
              </button>
            );
          })}
        </div>
      )}
      {open && <ProgrammeDetail id={open} kind={kind} close={() => setOpen(null)} onApply={onApply} onAccepted={() => { setOpen(null); onAccepted?.(); }} />}
    </div>
  );
}

function ProgrammeDetail({ id, kind, close, onApply, onAccepted }) {
  const { s, setWarn, toast } = useG();
  const edu = Catalog.get(id);
  const insts = useMemo(() => schoolsFor(s.country, edu).filter((i) => i.kind === kind), [id, kind]);
  const [instId, setInstId] = useState(insts[0]?.id); const [schId, setSchId] = useState(null); const [note, setNote] = useState(null);
  if (!edu) return null;
  const inst = Catalog.get(instId);
  const el = eduEligibility(s, edu, inst);
  const schs = inst ? scholarshipsFor(inst, edu) : [];
  const schElig = (sc) => {
    if (sc.kind === "athletic") return { ok: SPORTS.some((x) => (s.skills[x.id] || 0) >= 6) && s.stats.fitness >= 60, why: "Needs a sport skill Lv 6+ and Fitness Lv 6+" };
    if (sc.kind === "need") return { ok: s.money.cash < 3000 * countryOf(s.country).col && s.family.tier <= 1, why: "For students with limited funds and family income" };
    const r = checkReq(s, sc.requirements); return { ok: r.ok, why: "Needs a GPA of " + sc.requirements.gpa.toFixed(1) + "+" };
  };
  const sch = schs.find((x) => x.id === schId);
  const price = tuitionFor(s, edu, inst, sch);
  const apply = () => {
    if (!el.ok) {
      const reasons = el.items.filter((i) => !i.ok);
      return setWarn({ title: "You don't qualify yet", message: s.age < el.minAge ? `You're ${s.age}, but this programme starts at ${el.minAge} in ${countryOf(s.country).name}.` : `${inst?.name || "This school"} wants more before you can apply:`, items: reasons });
    }
    const r = onApply(edu, inst, sch);
    if (r?.error) return setWarn({ title: "Can't apply", message: r.message || "Something doesn't add up. Check the requirements.", items: r.el?.items.filter((i) => !i.ok) });
    if (r?.rejected) return setNote({ tone: "bad", text: r.text });
    if (r?.accepted) { toast.success(r.text); onAccepted(); }
  };
  return (
    <Dialog open onOpenChange={(o) => !o && close()}>
      <DialogContent className="max-h-[92vh] max-w-xl overflow-y-auto">
        <DialogHeader>
          <div className="flex flex-wrap gap-2"><Pill tone="primary">{KIND[edu.kind]}</Pill><Pill>{edu.years} yr{edu.years > 1 ? "s" : ""}</Pill><Pill>{schoolKind(edu.school)?.short}</Pill></div>
          <DialogTitle className="font-display text-2xl leading-tight">{edu.name}</DialogTitle>
          <DialogDescription className="text-base">{edu.desc}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          {insts.length > 0 && (
            <div><p className="mb-2 text-sm font-medium text-muted-foreground">School</p>
              <div className="grid gap-2">{insts.map((i) => { const e2 = eduEligibility(s, edu, i); return (
                <button key={i.id} type="button" onClick={() => { setInstId(i.id); setSchId(null); setNote(null); }} className={cn("flex items-center justify-between gap-3 rounded-lg border p-3 text-left", instId === i.id ? "border-primary bg-primary/10" : "border-border")}>
                  <span><span className="block text-base">{i.name}</span><span className="text-sm text-muted-foreground">{i.city} · reputation {i.rep} · tuition ×{i.tuitionMult}{i.gpaOff > 0.05 ? " · higher cut-off" : i.gpaOff < -0.05 ? " · lower cut-off" : ""}</span></span>
                  {e2.ok && <Pill tone={e2.odds >= 0.65 ? "good" : "warn"}>{e2.oddsLabel}</Pill>}
                </button>); })}</div>
            </div>
          )}
          <div><p className="mb-2 text-sm font-medium text-muted-foreground">Entry requirements at {inst?.name || "this school"}</p><ReqList items={el.items} /></div>
          {!el.ok && <div className="flex gap-3 rounded-xl border border-warn/40 bg-warn/10 p-3 text-base text-warn"><AlertTriangle className="mt-1 size-5 shrink-0" /><p>{s.age < el.minAge ? `Minimum age here is ${el.minAge}; you're ${s.age}.` : "You don't qualify yet."} Red items show what you're missing. You can reapply any time you qualify.</p></div>}
          {el.ok && <p className="text-sm text-muted-foreground">You meet the requirements. Admission is still competitive: <span className="font-medium text-foreground">{el.oddsLabel.toLowerCase()}</span> at this school. If you're turned down you can reapply next year.</p>}
          <div><p className="mb-2 text-sm font-medium text-muted-foreground">You will study</p><div className="flex flex-wrap gap-2">{edu.subjects.map((x) => <Pill key={x}>{x}</Pill>)}</div></div>
          <div className="grid grid-cols-2 gap-3 text-base"><div className="rounded-lg bg-foreground/5 p-3"><p className="text-sm text-muted-foreground">To graduate</p>GPA {edu.gradReq.minGpa}+{edu.gradReq.projects ? " and a final project" : ""}</div><div className="rounded-lg bg-foreground/5 p-3"><p className="text-sm text-muted-foreground">Leads to</p>{edu.careers.slice(0, 2).join(", ")}</div></div>
          {edu.grants?.length > 0 && <p className="text-sm text-muted-foreground">Qualifies you for: {edu.grants.join(", ")}</p>}
          {schs.length > 0 && (
            <div><p className="mb-2 text-sm font-medium text-muted-foreground">Scholarships</p>
              <div className="grid gap-2">{schs.map((sc) => { const e2 = schElig(sc); return (
                <button key={sc.id} type="button" disabled={!e2.ok} onClick={() => setSchId(schId === sc.id ? null : sc.id)} className={cn("rounded-lg border p-3 text-left disabled:opacity-60", schId === sc.id ? "border-primary bg-primary/10" : "border-border")}>
                  <span className="flex items-center justify-between"><span className="text-base">{sc.name}</span><Pill tone={e2.ok ? "good" : "bad"}>{Math.round(sc.coverage * 100)}% off</Pill></span>
                  <span className="text-sm text-muted-foreground">{e2.ok ? `You qualify. Keep GPA ${sc.keepGpa}+.` : e2.why}</span>
                </button>); })}</div>
            </div>
          )}
          <div className="flex items-center justify-between rounded-xl bg-foreground/5 p-4"><span className="text-base">Tuition per year{s.age < 25 && s.family.support > 0 ? " (after family help)" : ""}</span><span className="font-display text-2xl font-bold"><Money usd={price} /></span></div>
          {note && <div className={cn("rounded-xl border p-3 text-base", note.tone === "bad" ? "border-bad/40 bg-bad/10 text-bad" : "border-good/40 bg-good/10 text-good")}>{note.text}</div>}
          <Button type="button" onClick={apply} className="h-12 w-full text-base"><GraduationCap className="size-5" /> Apply</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
