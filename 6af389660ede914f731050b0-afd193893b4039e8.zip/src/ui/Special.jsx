import { useState } from "react";
import { Stethoscope, Pill as PillIcon, Hospital, BedDouble, ArrowRight, Briefcase, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useG, Pill, Money } from "./kit.jsx";
import { treatmentOptions, ILLNESS_BY_ID, illnessOf } from "../engine/health.js";
import { parentsLive } from "../engine/sim.js";
import { ProgrammeBrowser } from "./Programmes.jsx";
import { fmtMoney } from "../engine/data.js";
import { cn } from "@/lib/utils";

const ICON = { rest: BedDouble, otc: PillIcon, doctor: Stethoscope, specialist: Hospital };
const oddsText = (p, chronic) => (chronic ? "Keeps it under control" : p == null ? "" : p >= 0.85 ? "Very likely to cure" : p >= 0.65 ? "Likely to cure" : p >= 0.4 ? "Might help" : "Unlikely to cure");

// The treatment window: shared by the sick-event and by the Treat button on the Health tab.
export function DoctorPanel({ cond, onChoose, busy }) {
  const { s } = useG();
  const ill = illnessOf(cond);
  const opts = treatmentOptions(s, cond);
  const dep = parentsLive(s);
  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-border bg-foreground/5 p-4">
        <div className="flex flex-wrap items-center gap-2"><p className="font-display text-xl font-semibold">{cond.name}</p><Pill tone={cond.sev >= 3 ? "bad" : cond.sev === 2 ? "warn" : "muted"}>{cond.sev >= 3 ? "serious" : cond.sev === 2 ? "moderate" : "mild"}</Pill><Pill tone={cond.chronic ? "warn" : "info"}>{cond.chronic ? "long-term" : ill?.kind === "injury" ? "injury" : "treatable"}</Pill></div>
        {ill?.desc && <p className="mt-2 text-base text-foreground/80">{ill.desc}</p>}
        <p className="mt-2 text-sm text-muted-foreground">{dep ? "You're a child, so your parents decide whether to pay. Serious cases almost always get treated." : s.healthSystem === "universal" ? "Healthcare here is mostly state-funded, so visits are cheap." : s.healthSystem === "mixed" ? "Public and private care both exist, so costs vary." : "Healthcare here is largely private, so treatment costs real money."}</p>
      </div>
      <div className="space-y-2">
        {opts.map((o) => {
          const Icon = ICON[o.id] || Stethoscope; const poor = !dep && o.cost > s.money.cash;
          return (
            <button key={o.id} type="button" disabled={busy} onClick={() => onChoose(o.id)} className="group flex w-full items-center gap-3 rounded-xl border border-border bg-card p-4 text-left transition-colors hover:border-primary hover:bg-primary/5">
              <Icon className="size-5 shrink-0 text-primary" />
              <span className="min-w-0 flex-1"><span className="block text-base font-medium">{o.label}</span><span className="block text-sm text-muted-foreground">{o.desc}{oddsText(o.chance, cond.chronic) ? ` · ${oddsText(o.chance, cond.chronic)}` : ""}</span></span>
              <span className={cn("shrink-0 font-mono text-sm", poor ? "text-bad" : "text-muted-foreground")}>{o.cost === 0 ? "Free" : dep ? <>Ask parents<span className="block text-xs">≈ {fmtMoney(o.cost, s.country)}</span></> : fmtMoney(o.cost, s.country)}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
export const eventCondition = (ev) => { const ill = ILLNESS_BY_ID[ev.ill]; return { name: ill.name, sev: ill.sev, chronic: ill.chronic, ill: ill.id }; };

// Job offer: your current job and the new one side by side.
export function JobOfferPanel({ offer, onAnswer }) {
  const { s } = useG();
  const cur = s.job; const diff = cur ? Math.round(((offer.salaryUSD - cur.salaryUSD) / cur.salaryUSD) * 100) : null;
  const Card = ({ title, tone, job, salary, sub, hours, tag }) => (
    <div className={cn("flex-1 rounded-xl border p-4", tone === "offer" ? "border-primary/60 bg-primary/5" : "border-border bg-foreground/5")}>
      <p className="text-xs uppercase tracking-widest text-muted-foreground">{title}</p>
      <p className="mt-1 font-display text-xl font-semibold leading-tight">{job}</p>
      <p className="text-sm text-muted-foreground">{sub}</p>
      <p className="mt-3 font-display text-2xl font-bold"><Money usd={salary} /></p>
      <p className="text-sm text-muted-foreground">per year · {hours} h/week{tag ? ` · ${tag}` : ""}</p>
    </div>
  );
  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row">
        {cur ? <Card title="Your job now" job={cur.title} sub={cur.company || cur.name} salary={cur.salaryUSD} hours={cur.hours} tag={cur.partTime ? "part-time" : ""} /> : <div className="flex flex-1 items-center justify-center rounded-xl border border-dashed border-border p-4 text-center text-muted-foreground">You don't have a job right now.</div>}
        <Card title="The offer" tone="offer" job={offer.title} sub={`${offer.company} · ${offer.field}`} salary={offer.salaryUSD} hours={offer.hours} tag={offer.partTime ? "part-time" : ""} />
      </div>
      {diff != null && <p className={cn("rounded-lg p-3 text-center text-base", diff >= 0 ? "bg-good/10 text-good" : "bg-bad/10 text-bad")}>{diff >= 0 ? `+${diff}%` : `${diff}%`} compared with your current pay</p>}
      <div className="grid grid-cols-2 gap-2">
        <Button type="button" onClick={() => onAnswer(true)} className="h-12 text-base"><Check className="size-5" /> Accept</Button>
        <Button type="button" variant="outline" onClick={() => onAnswer(false)} className="h-12 text-base"><X className="size-5" /> Decline</Button>
      </div>
      {cur && <p className="text-center text-sm text-muted-foreground">Accepting means leaving your current job.</p>}
    </div>
  );
}

// University / college / professional school application, inside an event.
export function UniversityPanel({ ev, onApply, onSkip }) {
  return (
    <div className="space-y-4">
      <ProgrammeBrowser kinds={ev.kinds} initial={ev.kinds.includes("university") ? "university" : ev.kinds[0]} onApply={onApply} />
      <Button type="button" variant="outline" onClick={onSkip} className="h-12 w-full text-base">Not right now</Button>
    </div>
  );
}
