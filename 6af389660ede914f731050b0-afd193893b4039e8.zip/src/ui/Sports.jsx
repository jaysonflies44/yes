import { useEffect, useState } from "react";
import { Trophy, Medal } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useG, Panel, Bar, ReqList, Pill, Money, Empty } from "./kit.jsx";
import { Catalog } from "../engine/catalog.js";
import { SPORTS, SPORT_TIERS, countryOf, skillLvl } from "../engine/data.js";
import { sportEligibility, tryout, leaveTeam, doQuick } from "../engine/sim.js";
import { sportsFor } from "../engine/content.js";
import { clamp } from "../engine/rng.js";
import { cn } from "@/lib/utils";

export function SportsPage() {
  const { s, act, focus, clearFocus, toast, setWarn } = useG();
  const [sport, setSport] = useState(null); const [open, setOpen] = useState(null);
  useEffect(() => { if (focus && SPORTS.some((x) => x.id === focus)) { setSport(focus); clearFocus(); } }, [focus]);
  const c = countryOf(s.country); const team = s.sport.team;
  const opps = sportsFor(s.country, s.city);
  const shown = sport ? opps.filter((o) => o.sport === sport) : opps;
  const train = (id) => { const r = act((n) => { if ((n.quick["train_" + id] || 0) >= 2) return { error: "You've trained this sport twice already this year." }; if (n.age < 5) return { error: "Too young." }; n.quick["train_" + id] = (n.quick["train_" + id] || 0) + 1; n.skills[id] = clamp((n.skills[id] || 0) + 0.35, 0, 10); n.stats.fitness = clamp(n.stats.fitness + 2, 0, 100); n.stats.stress = clamp(n.stats.stress + 2, 0, 100); return { ok: true }; }); r.error ? setWarn({ title: "Can't train", message: r.error }) : toast(`Trained ${SPORTS.find((x) => x.id === id).name}`); };
  return (
    <div className="space-y-4">
      {team && (
        <Panel title="Your team" className="border-primary/40">
          <div className="flex items-start justify-between gap-3"><div><p className="font-display text-xl font-bold">{team.name}</p><p className="text-sm text-muted-foreground">{SPORT_TIERS[team.tier - 1].name} · {team.years} season{team.years !== 1 ? "s" : ""} · {team.wins} title{team.wins !== 1 ? "s" : ""}</p></div><Button type="button" size="sm" variant="outline" onClick={() => act((n) => leaveTeam(n))}>Leave</Button></div>
          {team.seasons.length > 0 && <div className="mt-3 flex flex-wrap gap-2">{team.seasons.slice(-6).map((r, i) => <Pill key={i} tone={r === "Champions" || r === "Finalists" ? "good" : r === "Bottom" ? "bad" : "muted"}>{r}</Pill>)}</div>}
        </Panel>
      )}
      <Panel title="Your sports" action={<span className="text-sm text-muted-foreground">tap to filter teams</span>}>
        <div className="grid grid-cols-2 gap-2 @2xl:grid-cols-4">
          {SPORTS.map((sp, i) => (
            <div key={sp.id} className={cn("rounded-xl border p-3", sport === sp.id ? "border-primary bg-primary/5" : "border-border")}>
              <button type="button" onClick={() => setSport(sport === sp.id ? null : sp.id)} className="w-full text-left"><p className="text-base font-semibold">{sp.name}</p><p className="font-mono text-sm text-muted-foreground">Lv {skillLvl(s.skills[sp.id])} · popularity {c.sports[i]}/10</p><Bar value={s.skills[sp.id] || 0} max={10} className="mt-2" /></button>
              <Button type="button" size="sm" variant="secondary" className="mt-2 w-full" disabled={s.age < sp.minAge} onClick={() => train(sp.id)}>{s.age < sp.minAge ? `Age ${sp.minAge}+` : "Train"}</Button>
            </div>
          ))}
        </div>
      </Panel>
      <Panel title={sport ? `${SPORTS.find((x) => x.id === sport).name} teams in ${s.city}` : "Teams, academies and leagues"}>
        {shown.length === 0 ? <Empty>No teams listed.</Empty> : (
          <div className="grid gap-3 @2xl:grid-cols-2">{shown.sort((a, b) => a.tier - b.tier).map((o) => { const el = sportEligibility(s, o); return (
            <button key={o.id} type="button" onClick={() => setOpen(o.id)} className="rounded-xl border border-border p-4 text-left transition-colors hover:border-primary">
              <div className="flex items-start justify-between gap-2"><p className="text-base font-semibold leading-snug">{o.name}</p><Pill tone={el.ok ? "good" : "bad"}>{el.ok ? "Try out" : "Locked"}</Pill></div>
              <p className="mt-1 text-sm text-muted-foreground">Tier {o.tier}: {o.tierName}{o.salaryUSD ? <> · <Money usd={o.salaryUSD} />/yr</> : ""}</p>
            </button>); })}</div>
        )}
      </Panel>
      {s.sport.awards.length > 0 && <Panel title="Trophy cabinet"><ul className="space-y-2">{s.sport.awards.map((a, i) => <li key={i} className="flex items-center gap-2 text-base"><Medal className="size-4 text-warn" />{a.text}<span className="ml-auto font-mono text-sm text-muted-foreground">age {a.age}</span></li>)}</ul></Panel>}
      {s.sport.careerEarn > 0 && <p className="text-center text-sm text-muted-foreground">Career sports earnings: <Money usd={s.sport.careerEarn} /></p>}
      {open && <OppDetail id={open} close={() => setOpen(null)} />}
    </div>
  );
}
function OppDetail({ id, close }) {
  const { s, act, toast, setWarn } = useG(); const o = Catalog.get(id); if (!o) return null; const el = sportEligibility(s, o);
  const go = () => { if (!el.ok) return setWarn({ title: "You're not ready for this team", message: "Scouts say you're missing:", items: el.items.filter((i) => !i.ok) }); const r = act((n) => tryout(n, o)); close(); r.rejected ? toast.error("You didn't make the cut. Train and retry.") : toast.success(`You made ${o.name}!`); };
  return (
    <Dialog open onOpenChange={(x) => !x && close()}>
      <DialogContent className="max-w-lg"><DialogHeader><Pill tone="primary" className="w-fit">Tier {o.tier}: {o.tierName}</Pill><DialogTitle className="font-display text-2xl">{o.name}</DialogTitle><DialogDescription className="text-base">{o.desc}</DialogDescription></DialogHeader>
        <ReqList items={el.items} />
        <p className="text-sm text-muted-foreground">Seasons bring competitions, awards and injuries. Higher tiers pay{o.salaryUSD ? <> about <Money usd={o.salaryUSD} /> a year here</> : " nothing yet"}, and recruiters watch the best.</p>
        <Button type="button" onClick={go} className="h-12 text-base"><Trophy className="size-5" /> Try out</Button>
      </DialogContent>
    </Dialog>
  );
}
