import { createContext, useContext } from "react";
import { Check, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { fmtMoney, eyeColor, hairColor } from "../engine/data.js";

export const G = createContext(null);
export const useG = () => useContext(G);

const TONE = { primary: "bg-primary", good: "bg-good", bad: "bg-bad", warn: "bg-warn", info: "bg-info", bloom: "bg-bloom" };
export const STAT_TONE = { happiness: "warn", health: "good", smarts: "info", looks: "bloom", fitness: "primary", reputation: "info", stress: "bad" };

export function Bar({ value, max = 100, tone = "primary", className, h = "h-2" }) {
  return (
    <div className={cn("w-full overflow-hidden rounded-full bg-foreground/10", h, className)}>
      <div className={cn("h-full rounded-full transition-all duration-700", TONE[tone])} style={{ width: `${Math.max(2, Math.min(100, (value / max) * 100))}%` }} />
    </div>
  );
}
export function Panel({ title, action, children, className, tone }) {
  return (
    <section className={cn("rounded-xl border border-border bg-card p-4", className)}>
      {(title || action) && (
        <header className="mb-3 flex items-center justify-between gap-2">
          {title && <h3 className="font-display text-base font-semibold tracking-tight">{title}</h3>}
          {action}
        </header>
      )}
      {children}
    </section>
  );
}
export function Chip({ ok, children, className }) {
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full border px-2 py-1 text-sm", ok ? "border-good/40 bg-good/10 text-good" : "border-bad/40 bg-bad/10 text-bad", className)}>
      {ok ? <Check className="size-3" /> : <X className="size-3" />}
      {children}
    </span>
  );
}
export function ReqList({ items }) {
  return <div className="flex flex-wrap gap-2">{items.map((i, k) => <Chip key={k} ok={i.ok}>{i.label}{i.have != null && i.have !== "" && !i.ok ? ` (you: ${i.have})` : "" /*patch6*/}</Chip>)}</div>;
}
export const Pill = ({ children, tone = "muted", className }) => (
  <span className={cn("inline-flex items-center rounded-full px-2 py-1 text-sm", tone === "muted" ? "bg-foreground/10 text-foreground/80" : tone === "primary" ? "bg-primary text-primary-foreground" : tone === "good" ? "bg-good/15 text-good" : tone === "bad" ? "bg-bad/15 text-bad" : tone === "warn" ? "bg-warn/15 text-warn" : "bg-info/15 text-info", className)}>{children}</span>
);
export const Money = ({ usd, className }) => {
  const { s } = useG();
  return <span className={cn("font-mono", className)}>{fmtMoney(usd, s.country)}</span>;
};
export const Empty = ({ children }) => <p className="rounded-lg border border-dashed border-border p-6 text-center text-base text-muted-foreground">{children}</p>;
export const Tone = ({ tone, children }) => <span className={cn(tone === "good" ? "text-good" : tone === "bad" ? "text-bad" : tone === "warn" ? "text-warn" : "text-muted-foreground")}>{children}</span>;
export const FxLines = ({ lines }) => (
  <div className="flex flex-wrap gap-2">
    {lines.map((l, i) => <span key={i} className={cn("rounded-full px-2 py-1 font-mono text-sm", l.tone === "good" ? "bg-good/15 text-good" : l.tone === "bad" ? "bg-bad/15 text-bad" : "bg-foreground/10")}>{l.text}</span>)}
  </div>
);

// ---------- genetics-driven portrait ----------
const HAIR = { black: "oklch(0.2 0.01 60)", brown: "oklch(0.36 0.06 50)", blonde: "oklch(0.8 0.12 90)", red: "oklch(0.52 0.15 40)" };
const EYE = { brown: "oklch(0.35 0.07 50)", green: "oklch(0.55 0.12 150)", blue: "oklch(0.6 0.12 240)" };
export function Portrait({ p, age, mood = 70, size = 96, className }) {
  const g = p.genes; const skin = `oklch(${0.9 - (g.skin / 100) * 0.52} ${0.04 + (g.skin / 100) * 0.03} 55)`;
  const hc = age >= 68 ? "oklch(0.88 0.005 90)" : age >= 52 ? "oklch(0.6 0.01 90)" : HAIR[hairColor(g.hair)];
  const ec = EYE[eyeColor(g.eye)];
  const female = p.gender === "female"; const kid = age < 12 ? 1.12 : age < 18 ? 1.04 : 1;
  const long = female && age > 3; const curl = g.curl > 66;
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} className={className} role="img" aria-label="Character portrait">
      <rect width="100" height="100" rx="22" fill="oklch(0.28 0.05 285)" />
      <path d="M12 100c2-22 18-32 38-32s36 10 38 32z" fill={age < 18 ? "oklch(0.72 0.14 230)" : "oklch(0.55 0.1 285)"} />
      {long && <path d={curl ? "M24 52c-6 14-4 26 4 32h44c8-6 10-18 4-32z" : "M26 46c-4 16-2 30 2 38h44c4-8 6-22 2-38z"} fill={hc} />}
      <rect x="44" y="58" width="12" height="12" rx="4" fill={skin} />
      <ellipse cx="50" cy="42" rx={21 * kid} ry={24 * kid} fill={skin} />
      <path d={curl ? "M27 40c-4-16 6-26 23-26s27 10 23 26c-3-8-9-12-23-12S30 32 27 40z" : "M28 40c-2-18 8-26 22-26s24 8 22 26c-4-9-10-13-22-13S32 31 28 40z"} fill={hc} />
      {curl && <><circle cx="29" cy="30" r="6" fill={hc} /><circle cx="71" cy="30" r="6" fill={hc} /><circle cx="50" cy="15" r="7" fill={hc} /></>}
      <ellipse cx="41" cy="44" rx="3.6" ry={age < 3 ? 4 : 3.2} fill="white" /><ellipse cx="59" cy="44" rx="3.6" ry={age < 3 ? 4 : 3.2} fill="white" />
      <circle cx="41" cy="44.4" r="2.1" fill={ec} /><circle cx="59" cy="44.4" r="2.1" fill={ec} />
      <path d={`M42 ${55 + (mood < 35 ? 2 : 0)}q8 ${mood > 60 ? 7 : mood > 35 ? 3 : -3} 16 0`} stroke="oklch(0.4 0.08 25)" strokeWidth="2" fill="none" strokeLinecap="round" />
      {age >= 60 && <path d="M35 36q4-3 8 0M57 36q4-3 8 0" stroke="oklch(0.5 0.03 60)" strokeWidth="1" fill="none" />}
    </svg>
  );
}
